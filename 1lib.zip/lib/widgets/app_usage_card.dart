import 'package:flutter/material.dart';

import '../models/app_usage_model.dart';
import '../screens/app_usage_details_screen.dart';

class AppUsageCard extends StatelessWidget {
  final AppUsageModel app;
  final VoidCallback? onTap;

  const AppUsageCard({
    super.key,
    required this.app,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,

      child: InkWell(
        onTap: onTap ??
            () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      AppUsageDetailsScreen(
                    app: app,
                  ),
                ),
              );
            },

        borderRadius:
            BorderRadius.circular(18),

        child: Container(
          margin:
              const EdgeInsets.only(
            bottom: 12,
          ),

          padding:
              const EdgeInsets.all(14),

          decoration: BoxDecoration(
            color: Colors.white,

            borderRadius:
                BorderRadius.circular(18),

            border: Border.all(
              color:
                  const Color(0xFFEAE6F7),
            ),

            boxShadow: [
              BoxShadow(
                color:
                    const Color(0xFF7357D9)
                        .withValues(
                  alpha: 0.05,
                ),
                blurRadius: 12,
                offset:
                    const Offset(0, 5),
              ),
            ],
          ),

          child: Row(
            children: [
              _buildAppIcon(),

              const SizedBox(
                width: 13,
              ),

              Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,

                  children: [
                    Text(
                      app.appName,

                      maxLines: 1,

                      overflow:
                          TextOverflow.ellipsis,

                      style:
                          const TextStyle(
                        fontSize: 14,
                        fontWeight:
                            FontWeight.w800,
                        color:
                            Color(0xFF252238),
                      ),
                    ),

                    const SizedBox(
                      height: 5,
                    ),

                    Text(
                      app.formattedDuration,

                      style:
                          const TextStyle(
                        fontSize: 12,
                        fontWeight:
                            FontWeight.w600,
                        color:
                            Color(0xFF7357D9),
                      ),
                    ),

                    const SizedBox(
                      height: 7,
                    ),

                    ClipRRect(
                      borderRadius:
                          BorderRadius.circular(
                        10,
                      ),

                      child:
                          LinearProgressIndicator(
                        value:
                            _progressValue,

                        minHeight: 5,

                        backgroundColor:
                            const Color(
                          0xFFF0ECFF,
                        ),

                        valueColor:
                            const AlwaysStoppedAnimation<
                                Color>(
                          Color(0xFF7357D9),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              const SizedBox(
                width: 10,
              ),

              Column(
                crossAxisAlignment:
                    CrossAxisAlignment.end,

                children: [
                  Text(
                    '${app.launchCount}',

                    style:
                        const TextStyle(
                      fontSize: 13,
                      fontWeight:
                          FontWeight.w800,
                      color:
                          Color(0xFF403B52),
                    ),
                  ),

                  const SizedBox(
                    height: 2,
                  ),

                  const Text(
                    'opens',

                    style:
                        TextStyle(
                      fontSize: 9,
                      color:
                          Color(0xFF9A94A8),
                    ),
                  ),

                  const SizedBox(
                    height: 5,
                  ),

                  const Icon(
                    Icons
                        .chevron_right_rounded,
                    size: 22,
                    color:
                        Color(0xFFAAA4B8),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // REAL ANDROID APP ICON
  // ============================================================

  Widget _buildAppIcon() {
    final icon =
        app.iconBytes;

    if (icon != null &&
        icon.isNotEmpty) {
      return Container(
        width: 50,
        height: 50,

        decoration:
            BoxDecoration(
          borderRadius:
              BorderRadius.circular(14),

          color:
              const Color(0xFFF5F2FF),
        ),

        clipBehavior:
            Clip.antiAlias,

        child: Image.memory(
          icon,

          width: 50,
          height: 50,

          fit: BoxFit.contain,

          gaplessPlayback: true,

          errorBuilder:
              (
                context,
                error,
                stackTrace,
              ) {
            return _fallbackIcon();
          },
        ),
      );
    }

    return _fallbackIcon();
  }

  Widget _fallbackIcon() {
    return Container(
      width: 50,
      height: 50,

      decoration:
          BoxDecoration(
        color:
            const Color(0xFFF0ECFF),

        borderRadius:
            BorderRadius.circular(14),
      ),

      child: const Icon(
        Icons.apps_rounded,

        color:
            Color(0xFF7357D9),

        size: 27,
      ),
    );
  }

  // ============================================================
  // PROGRESS
  // ============================================================

  double get _progressValue {
    final minutes =
        app.totalTimeInForeground /
            60000;

    if (minutes <= 0) {
      return 0.05;
    }

    if (minutes >= 180) {
      return 1.0;
    }

    return (minutes / 180)
        .clamp(0.05, 1.0);
  }
}