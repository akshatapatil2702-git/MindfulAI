import 'package:flutter/material.dart';

class CommonButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final IconData? icon;
  final bool isLoading;

  const CommonButton({
    super.key,
    required this.text,
    required this.onPressed,
    this.icon,
    this.isLoading = false,
  });

  String _getEmoji(IconData? icon) {
    if (icon == null) return '';

    if (icon == Icons.login_rounded ||
        icon == Icons.login ||
        icon == Icons.arrow_forward_rounded) {
      return '➜';
    }

    if (icon == Icons.person_add_rounded ||
        icon == Icons.person_add) {
      return '👤';
    }

    if (icon == Icons.lock_reset_rounded ||
        icon == Icons.lock_reset) {
      return '🔑';
    }

    if (icon == Icons.save_rounded ||
        icon == Icons.save) {
      return '💾';
    }

    if (icon == Icons.check_rounded ||
        icon == Icons.check) {
      return '✓';
    }

    if (icon == Icons.logout_rounded ||
        icon == Icons.logout) {
      return '🚪';
    }

    if (icon == Icons.settings_rounded ||
        icon == Icons.settings) {
      return '⚙️';
    }

    if (icon == Icons.refresh_rounded ||
        icon == Icons.refresh) {
      return '🔄';
    }

    return '✨';
  }

  @override
  Widget build(BuildContext context) {
    final emoji = _getEmoji(icon);

    return SizedBox(
      width: double.infinity,
      height: 54,
      child: ElevatedButton(
        onPressed: isLoading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF7357D9),
          foregroundColor: Colors.white,
          disabledBackgroundColor: const Color(0xFFB9B1D6),
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
        child: isLoading
            ? const SizedBox(
                width: 23,
                height: 23,
                child: CircularProgressIndicator(
                  strokeWidth: 2.5,
                  valueColor: AlwaysStoppedAnimation<Color>(
                    Colors.white,
                  ),
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (icon != null) ...[
                    Text(
                      emoji,
                      style: const TextStyle(
                        fontSize: 20,
                      ),
                    ),
                    const SizedBox(width: 9),
                  ],
                  Text(
                    text,
                    style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}