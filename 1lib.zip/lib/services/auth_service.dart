import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthService {
  AuthService._();

  static final AuthService instance = AuthService._();

  final FirebaseAuth _auth = FirebaseAuth.instance;

  User? get currentUser => _auth.currentUser;

  Stream<User?> get authStateChanges => _auth.authStateChanges();

  // ============================================================
  // EMAIL + PASSWORD LOGIN
  // ============================================================

  Future<UserCredential> login({
    required String email,
    required String password,
  }) async {
    return await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
  }

  // ============================================================
  // REGISTER WITH EMAIL + PASSWORD
  // ============================================================

  Future<UserCredential> register({
    required String name,
    required String email,
    required String password,
  }) async {
    final credential = await _auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );

    await credential.user?.updateDisplayName(
      name.trim(),
    );

    await credential.user?.reload();

    return credential;
  }

  // ============================================================
  // FORGOT PASSWORD
  // ============================================================

  Future<void> sendPasswordResetEmail(
    String email,
  ) async {
    await _auth.sendPasswordResetEmail(
      email: email.trim(),
    );
  }

  // ============================================================
  // GOOGLE SIGN-IN
  // ============================================================

  Future<UserCredential> signInWithGoogle() async {
    final GoogleSignIn googleSignIn =
        GoogleSignIn.instance;

    await googleSignIn.initialize();

    final GoogleSignInAccount googleUser =
        await googleSignIn.authenticate();

    final GoogleSignInAuthentication googleAuth =
        googleUser.authentication;

    final String? idToken = googleAuth.idToken;

    if (idToken == null || idToken.isEmpty) {
      throw FirebaseAuthException(
        code: 'google-id-token-missing',
        message: 'Google ID token was not received.',
      );
    }

    final OAuthCredential credential =
        GoogleAuthProvider.credential(
      idToken: idToken,
    );

    return await _auth.signInWithCredential(
      credential,
    );
  }

  // ============================================================
  // LINK EMAIL + PASSWORD TO GOOGLE ACCOUNT
  // ============================================================

  Future<UserCredential> linkEmailPassword({
    required String email,
    required String password,
  }) async {
    final User? user = _auth.currentUser;

    if (user == null) {
      throw FirebaseAuthException(
        code: 'no-current-user',
        message: 'Please sign in first.',
      );
    }

    final AuthCredential credential =
        EmailAuthProvider.credential(
      email: email.trim(),
      password: password,
    );

    return await user.linkWithCredential(
      credential,
    );
  }

  // ============================================================
  // CHECK CURRENT USER PROVIDERS
  // ============================================================

  bool get hasGoogleProvider {
    final user = _auth.currentUser;

    if (user == null) {
      return false;
    }

    return user.providerData.any(
      (provider) =>
          provider.providerId == 'google.com',
    );
  }

  bool get hasPasswordProvider {
    final user = _auth.currentUser;

    if (user == null) {
      return false;
    }

    return user.providerData.any(
      (provider) =>
          provider.providerId == 'password',
    );
  }

  // ============================================================
  // LOGOUT
  // ============================================================

  Future<void> logout() async {
    try {
      await GoogleSignIn.instance.signOut();
    } catch (_) {
      // Google sign-out failure should not block Firebase logout.
    }

    await _auth.signOut();
  }

  // ============================================================
  // DELETE ACCOUNT
  // ============================================================

  Future<void> deleteAccount() async {
    await _auth.currentUser?.delete();
  }
}