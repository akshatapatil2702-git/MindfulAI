import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;

class NotificationService {
  NotificationService._();

  static final NotificationService instance =
      NotificationService._();

  final FlutterLocalNotificationsPlugin _notifications =
      FlutterLocalNotificationsPlugin();

  static const int screenTimeNotificationId = 1001;
  static const int wellbeingNotificationId = 1002;
  static const int distractionNotificationId = 1003;

  static const String _notificationsEnabledKey =
      'notifications_enabled';

  static const String _screenTimeReminderEnabledKey =
      'screen_time_reminder_enabled';

  static const String _wellbeingReminderEnabledKey =
      'wellbeing_reminder_enabled';

  static const String _distractionAlertEnabledKey =
      'distraction_alert_enabled';

  Future<void> initialize() async {
    tz.initializeTimeZones();

    const androidSettings =
        AndroidInitializationSettings('@mipmap/ic_launcher');

    const initializationSettings =
        InitializationSettings(
      android: androidSettings,
    );

    await _notifications.initialize(
      settings: initializationSettings,
    );

    await _createNotificationChannels();

    await requestNotificationsPermission();
  }

  Future<void> _createNotificationChannels() async {
    const AndroidNotificationChannel generalChannel =
        AndroidNotificationChannel(
      'mindfulai_general',
      'MindfulAI Notifications',
      description:
          'General notifications from MindfulAI',
      importance: Importance.high,
    );

    const AndroidNotificationChannel screenTimeChannel =
        AndroidNotificationChannel(
      'mindfulai_screen_time',
      'Screen Time Reminders',
      description:
          'Reminders related to screen time',
      importance: Importance.high,
    );

    const AndroidNotificationChannel wellbeingChannel =
        AndroidNotificationChannel(
      'mindfulai_wellbeing',
      'Daily Wellbeing',
      description:
          'Daily wellbeing reminders',
      importance: Importance.high,
    );

    const AndroidNotificationChannel distractionChannel =
        AndroidNotificationChannel(
      'mindfulai_distraction',
      'Distraction Alerts',
      description:
          'Alerts when screen usage becomes high',
      importance: Importance.high,
    );

    final androidPlugin =
        _notifications
            .resolvePlatformSpecificImplementation<
                AndroidFlutterLocalNotificationsPlugin>();

    if (androidPlugin != null) {
      await androidPlugin.createNotificationChannel(
        generalChannel,
      );

      await androidPlugin.createNotificationChannel(
        screenTimeChannel,
      );

      await androidPlugin.createNotificationChannel(
        wellbeingChannel,
      );

      await androidPlugin.createNotificationChannel(
        distractionChannel,
      );
    }
  }

  Future<void> requestNotificationsPermission() async {
    final androidPlugin =
        _notifications
            .resolvePlatformSpecificImplementation<
                AndroidFlutterLocalNotificationsPlugin>();

    if (androidPlugin != null) {
      await androidPlugin.requestNotificationsPermission();
    }
  }

  Future<bool> areNotificationsEnabled() async {
    final prefs =
        await SharedPreferences.getInstance();

    return prefs.getBool(
          _notificationsEnabledKey,
        ) ??
        true;
  }

  Future<void> setNotificationsEnabled(
    bool enabled,
  ) async {
    final prefs =
        await SharedPreferences.getInstance();

    await prefs.setBool(
      _notificationsEnabledKey,
      enabled,
    );

    if (!enabled) {
      await cancelAllNotifications();
    }
  }

  Future<bool> isScreenTimeReminderEnabled() async {
    final prefs =
        await SharedPreferences.getInstance();

    return prefs.getBool(
          _screenTimeReminderEnabledKey,
        ) ??
        false;
  }

  Future<void> setScreenTimeReminderEnabled(
    bool enabled,
  ) async {
    final prefs =
        await SharedPreferences.getInstance();

    await prefs.setBool(
      _screenTimeReminderEnabledKey,
      enabled,
    );

    if (enabled) {
      await scheduleScreenTimeReminder();
    } else {
      await cancelNotification(
        screenTimeNotificationId,
      );
    }
  }

  Future<bool> isWellbeingReminderEnabled() async {
    final prefs =
        await SharedPreferences.getInstance();

    return prefs.getBool(
          _wellbeingReminderEnabledKey,
        ) ??
        false;
  }

  Future<void> setWellbeingReminderEnabled(
    bool enabled,
  ) async {
    final prefs =
        await SharedPreferences.getInstance();

    await prefs.setBool(
      _wellbeingReminderEnabledKey,
      enabled,
    );

    if (enabled) {
      await scheduleDailyWellbeingReminder();
    } else {
      await cancelNotification(
        wellbeingNotificationId,
      );
    }
  }

  Future<bool> isDistractionAlertEnabled() async {
    final prefs =
        await SharedPreferences.getInstance();

    return prefs.getBool(
          _distractionAlertEnabledKey,
        ) ??
        false;
  }

  Future<void> setDistractionAlertEnabled(
    bool enabled,
  ) async {
    final prefs =
        await SharedPreferences.getInstance();

    await prefs.setBool(
      _distractionAlertEnabledKey,
      enabled,
    );

    if (!enabled) {
      await cancelNotification(
        distractionNotificationId,
      );
    }
  }

  NotificationDetails _notificationDetails({
    String channelId = 'mindfulai_general',
    String channelName = 'MindfulAI Notifications',
  }) {
    return NotificationDetails(
      android: AndroidNotificationDetails(
        channelId,
        channelName,
        channelDescription:
            'Notifications from MindfulAI',
        importance: Importance.high,
        priority: Priority.high,
        playSound: true,
      ),
    );
  }

  Future<void> showNotification({
    required int id,
    required String title,
    required String body,
  }) async {
    final enabled =
        await areNotificationsEnabled();

    if (!enabled) {
      return;
    }

    await _notifications.show(
      id: id,
      title: title,
      body: body,
      notificationDetails:
          _notificationDetails(),
    );
  }

  Future<void> scheduleNotification({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledDate,
    String channelId = 'mindfulai_general',
    String channelName = 'MindfulAI Notifications',
  }) async {
    final enabled =
        await areNotificationsEnabled();

    if (!enabled) {
      return;
    }

    final tz.TZDateTime scheduled =
        tz.TZDateTime.from(
      scheduledDate,
      tz.local,
    );

    await _notifications.zonedSchedule(
      id: id,
      title: title,
      body: body,
      scheduledDate: scheduled,
      notificationDetails:
          _notificationDetails(
        channelId: channelId,
        channelName: channelName,
      ),
      androidScheduleMode:
          AndroidScheduleMode.inexactAllowWhileIdle,
    );
  }

  Future<void> scheduleScreenTimeReminder() async {
    final enabled =
        await areNotificationsEnabled();

    if (!enabled) {
      return;
    }

    await cancelNotification(
      screenTimeNotificationId,
    );

    final now = DateTime.now();

    DateTime reminderTime = DateTime(
      now.year,
      now.month,
      now.day,
      20,
      0,
    );

    if (reminderTime.isBefore(now)) {
      reminderTime =
          reminderTime.add(
        const Duration(days: 1),
      );
    }

    await scheduleNotification(
      id: screenTimeNotificationId,
      title: 'Screen Time Reminder',
      body:
          'Take a short break and spend some time away from your screen.',
      scheduledDate: reminderTime,
      channelId: 'mindfulai_screen_time',
      channelName: 'Screen Time Reminders',
    );
  }

  Future<void> scheduleDailyWellbeingReminder() async {
    final enabled =
        await areNotificationsEnabled();

    if (!enabled) {
      return;
    }

    await cancelNotification(
      wellbeingNotificationId,
    );

    final now = DateTime.now();

    DateTime reminderTime = DateTime(
      now.year,
      now.month,
      now.day,
      9,
      0,
    );

    if (reminderTime.isBefore(now)) {
      reminderTime =
          reminderTime.add(
        const Duration(days: 1),
      );
    }

    await scheduleNotification(
      id: wellbeingNotificationId,
      title: 'Daily Wellbeing',
      body:
          'Take a moment to relax, breathe, and focus on your wellbeing.',
      scheduledDate: reminderTime,
      channelId: 'mindfulai_wellbeing',
      channelName: 'Daily Wellbeing',
    );
  }

  Future<void> scheduleCustomNotification({
    required int id,
    required String title,
    required String body,
    required DateTime scheduledDate,
  }) async {
    await scheduleNotification(
      id: id,
      title: title,
      body: body,
      scheduledDate: scheduledDate,
    );
  }

  Future<void> cancelNotification(
    int id,
  ) async {
    await _notifications.cancel(
      id: id,
    );
  }

  Future<void> cancelScreenTimeReminder() async {
    await cancelNotification(
      screenTimeNotificationId,
    );
  }

  Future<void> cancelWellbeingReminder() async {
    await cancelNotification(
      wellbeingNotificationId,
    );
  }

  Future<void> cancelDistractionAlert() async {
    await cancelNotification(
      distractionNotificationId,
    );
  }

  Future<void> cancelAllNotifications() async {
    await _notifications.cancelAll();
  }

  Future<void> showScreenTimeNotification() async {
    await showNotification(
      id: screenTimeNotificationId,
      title: 'Screen Time Reminder',
      body:
          'You have been using your screen for a while. Consider taking a short break.',
    );
  }

  Future<void> showWellbeingNotification() async {
    await showNotification(
      id: wellbeingNotificationId,
      title: 'Daily Wellbeing',
      body:
          'Take a moment to relax and focus on your wellbeing.',
    );
  }

  Future<void> showDistractionNotification({
    String? appName,
  }) async {
    final name =
        appName == null || appName.isEmpty
            ? 'an app'
            : appName;

    final enabled =
        await areNotificationsEnabled();

    if (!enabled) {
      return;
    }

    await _notifications.show(
      id: distractionNotificationId,
      title: 'Distraction Alert',
      body:
          'You have spent a lot of time on $name today. Consider taking a break.',
      notificationDetails:
          _notificationDetails(
        channelId: 'mindfulai_distraction',
        channelName: 'Distraction Alerts',
      ),
    );
  }

  Future<void> scheduleTestNotification() async {
    final testTime =
        DateTime.now().add(
      const Duration(seconds: 10),
    );

    await scheduleNotification(
      id: 9999,
      title: 'MindfulAI Test',
      body:
          'This is a test notification from MindfulAI.',
      scheduledDate: testTime,
    );
  }

  Future<void> cancelTestNotification() async {
    await cancelNotification(
      9999,
    );
  }
    // ------------------------------------------------------------
  // Compatibility methods used by existing screens
  // ------------------------------------------------------------

  Future<bool> getNotificationsEnabled() async {
    return await areNotificationsEnabled();
  }

  Future<bool> getFocusReminderEnabled() async {
    final prefs = await SharedPreferences.getInstance();

    return prefs.getBool(
          'focus_reminder_enabled',
        ) ??
        false;
  }

  Future<bool> getScreenTimeReminderEnabled() async {
    return await isScreenTimeReminderEnabled();
  }

  Future<bool> getDistractionAlertEnabled() async {
    return await isDistractionAlertEnabled();
  }

  Future<bool> getWellbeingReminderEnabled() async {
    return await isWellbeingReminderEnabled();
  }

  Future<void> setFocusReminderEnabled(
    bool enabled,
  ) async {
    final prefs = await SharedPreferences.getInstance();

    await prefs.setBool(
      'focus_reminder_enabled',
      enabled,
    );

    if (!enabled) {
      await cancelNotification(2001);
    }
  }
}