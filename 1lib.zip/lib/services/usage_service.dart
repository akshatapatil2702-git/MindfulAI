import 'package:flutter/services.dart';

class UsageService {
  UsageService._();

  static final UsageService instance =
      UsageService._();

  static const MethodChannel _channel =
      MethodChannel('mindfulai/usage');

  // ==========================================================
  // USAGE ACCESS PERMISSION
  // ==========================================================

  Future<bool> hasUsageAccess() async {
    try {
      final result = await _channel.invokeMethod<bool>(
        'hasUsageAccess',
      );

      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  // ==========================================================
  // OPEN USAGE ACCESS SETTINGS
  // ==========================================================

  Future<bool> openUsageAccessSettings() async {
    try {
      final result = await _channel.invokeMethod<bool>(
        'openUsageAccessSettings',
      );

      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  // ==========================================================
  // OPEN ACCESSIBILITY SETTINGS
  // ==========================================================

  Future<bool> openAccessibilitySettings() async {
    try {
      final result = await _channel.invokeMethod<bool>(
        'openAccessibilitySettings',
      );

      return result ?? false;
    } catch (_) {
      return false;
    }
  }

  // ==========================================================
  // GET REAL ANDROID USAGE DATA
  // ==========================================================

  Future<List<Map<String, dynamic>>> getUsageStats({
    int days = 1,
  }) async {
    try {
      final result = await _channel.invokeMethod<dynamic>(
        'getUsageStats',
        <String, dynamic>{
          'days': days,
        },
      );

      if (result == null) {
        return <Map<String, dynamic>>[];
      }

      if (result is! List) {
        return <Map<String, dynamic>>[];
      }

      final List<Map<String, dynamic>> usageList = [];

      for (final item in result) {
        if (item is! Map) {
          continue;
        }

        final map = <String, dynamic>{
          ...Map<String, dynamic>.from(item),
        };

        // Android MethodChannel may return icon bytes
        // as Uint8List or List<int>.
        final iconBytes = map['iconBytes'];

        if (iconBytes != null) {
          if (iconBytes is Uint8List) {
            map['iconBytes'] = iconBytes;
          } else if (iconBytes is List) {
            try {
              map['iconBytes'] =
                  Uint8List.fromList(
                iconBytes
                    .whereType<num>()
                    .map(
                      (value) => value.toInt(),
                    )
                    .toList(),
              );
            } catch (_) {
              map.remove('iconBytes');
            }
          }
        }

        usageList.add(map);
      }

      // Highest screen-time apps first.
      usageList.sort(
        (a, b) {
          final aTime =
              (a['totalTimeInForeground'] as num?)
                      ?.toInt() ??
                  0;

          final bTime =
              (b['totalTimeInForeground'] as num?)
                      ?.toInt() ??
                  0;

          return bTime.compareTo(aTime);
        },
      );

      return usageList;
    } catch (_) {
      return <Map<String, dynamic>>[];
    }
  }

  // ==========================================================
  // TODAY
  // ==========================================================

  Future<List<Map<String, dynamic>>>
      getTodayUsage() async {
    return getUsageStats(
      days: 1,
    );
  }

  // ==========================================================
  // WEEK
  // ==========================================================

  Future<List<Map<String, dynamic>>>
      getWeeklyUsage() async {
    return getUsageStats(
      days: 7,
    );
  }

  // ==========================================================
  // MONTH
  // ==========================================================

  Future<List<Map<String, dynamic>>>
      getMonthlyUsage() async {
    return getUsageStats(
      days: 30,
    );
  }

  // ==========================================================
  // TOTAL SCREEN TIME
  // ==========================================================

  int getTotalScreenTime(
    List<Map<String, dynamic>> apps,
  ) {
    return apps.fold<int>(
      0,
      (total, app) {
        final value =
            (app['totalTimeInForeground'] as num?)
                    ?.toInt() ??
                0;

        return total + value;
      },
    );
  }

  // ==========================================================
  // TOTAL APP LAUNCHES
  // ==========================================================

  int getTotalLaunches(
    List<Map<String, dynamic>> apps,
  ) {
    return apps.fold<int>(
      0,
      (total, app) {
        final value =
            (app['launchCount'] as num?)
                    ?.toInt() ??
                0;

        return total + value;
      },
    );
  }

  // ==========================================================
  // TOP APP
  // ==========================================================

  Map<String, dynamic>? getTopApp(
    List<Map<String, dynamic>> apps,
  ) {
    if (apps.isEmpty) {
      return null;
    }

    final sorted =
        List<Map<String, dynamic>>.from(
      apps,
    );

    sorted.sort(
      (a, b) {
        final aTime =
            (a['totalTimeInForeground'] as num?)
                    ?.toInt() ??
                0;

        final bTime =
            (b['totalTimeInForeground'] as num?)
                    ?.toInt() ??
                0;

        return bTime.compareTo(aTime);
      },
    );

    return sorted.first;
  }

  // ==========================================================
  // APP PERCENTAGE
  // ==========================================================

  double getAppPercentage(
    Map<String, dynamic> app,
    List<Map<String, dynamic>> allApps,
  ) {
    final total =
        getTotalScreenTime(allApps);

    if (total <= 0) {
      return 0;
    }

    final appTime =
        (app['totalTimeInForeground'] as num?)
                ?.toInt() ??
            0;

    return (appTime / total) * 100;
  }

  // ==========================================================
  // FORMAT DURATION
  // ==========================================================

  String formatDuration(
    int milliseconds,
  ) {
    if (milliseconds <= 0) {
      return '0m';
    }

    final duration =
        Duration(
      milliseconds: milliseconds,
    );

    final hours =
        duration.inHours;

    final minutes =
        duration.inMinutes.remainder(60);

    if (hours > 0) {
      if (minutes > 0) {
        return '${hours}h ${minutes}m';
      }

      return '${hours}h';
    }

    if (minutes > 0) {
      return '${minutes}m';
    }

    final seconds =
        duration.inSeconds;

    if (seconds > 0) {
      return '${seconds}s';
    }

    return '0m';
  }

  // ==========================================================
  // FORMAT SHORT DURATION
  // ==========================================================

  String formatShortDuration(
    int milliseconds,
  ) {
    if (milliseconds <= 0) {
      return '0m';
    }

    final duration =
        Duration(
      milliseconds: milliseconds,
    );

    final hours =
        duration.inHours;

    final minutes =
        duration.inMinutes.remainder(60);

    if (hours > 0) {
      return '${hours}h ${minutes}m';
    }

    return '${minutes}m';
  }

  // ==========================================================
  // GET ICON BYTES
  // ==========================================================

  Uint8List? getIconBytes(
    Map<String, dynamic> app,
  ) {
    final raw =
        app['iconBytes'];

    if (raw == null) {
      return null;
    }

    if (raw is Uint8List) {
      return raw;
    }

    if (raw is List) {
      try {
        return Uint8List.fromList(
          raw
              .whereType<num>()
              .map(
                (value) => value.toInt(),
              )
              .toList(),
        );
      } catch (_) {
        return null;
      }
    }

    return null;
  }

  // ==========================================================
  // SORT BY SCREEN TIME
  // ==========================================================

  List<Map<String, dynamic>> sortByUsage(
    List<Map<String, dynamic>> apps,
  ) {
    final sorted =
        List<Map<String, dynamic>>.from(
      apps,
    );

    sorted.sort(
      (a, b) {
        final aTime =
            (a['totalTimeInForeground'] as num?)
                    ?.toInt() ??
                0;

        final bTime =
            (b['totalTimeInForeground'] as num?)
                    ?.toInt() ??
                0;

        return bTime.compareTo(aTime);
      },
    );

    return sorted;
  }

  // ==========================================================
  // LIMIT TOP APPS
  // ==========================================================

  List<Map<String, dynamic>> getTopApps(
    List<Map<String, dynamic>> apps, {
    int limit = 5,
  }) {
    final sorted =
        sortByUsage(apps);

    if (sorted.length <= limit) {
      return sorted;
    }

    return sorted.take(limit).toList();
  }

  // ==========================================================
  // CATEGORY
  // ==========================================================

  String getAppCategory(
    String packageName,
    String appName,
  ) {
    final package =
        packageName.toLowerCase();

    final name =
        appName.toLowerCase();

    // Social Media
    const socialPackages = <String>[
      'com.instagram.android',
      'com.facebook.katana',
      'com.facebook.orca',
      'com.snapchat.android',
      'com.twitter.android',
      'com.x.android',
      'com.linkedin.android',
      'com.reddit.frontpage',
      'com.pinterest',
    ];

    if (socialPackages.contains(package) ||
        name.contains('instagram') ||
        name.contains('facebook') ||
        name.contains('snapchat') ||
        name == 'x' ||
        name.contains('twitter') ||
        name.contains('reddit') ||
        name.contains('linkedin')) {
      return 'Social Media';
    }

    // Communication
    const communicationPackages = <String>[
      'com.whatsapp',
      'org.telegram.messenger',
      'com.google.android.apps.messaging',
      'com.google.android.dialer',
      'com.android.contacts',
    ];

    if (communicationPackages.contains(package) ||
        name.contains('whatsapp') ||
        name.contains('telegram') ||
        name.contains('messaging') ||
        name.contains('messages') ||
        name.contains('phone') ||
        name.contains('contacts')) {
      return 'Communication';
    }

    // Entertainment
    const entertainmentPackages = <String>[
      'com.google.android.youtube',
      'com.netflix.mediaclient',
      'com.spotify.music',
      'com.amazon.avod.thirdpartyclient',
      'com.disney.disneyplus',
    ];

    if (entertainmentPackages.contains(package) ||
        name.contains('youtube') ||
        name.contains('netflix') ||
        name.contains('spotify') ||
        name.contains('prime video') ||
        name.contains('disney')) {
      return 'Entertainment';
    }

    // Productivity
    const productivityPackages = <String>[
      'com.google.android.apps.docs',
      'com.google.android.apps.sheets',
      'com.google.android.apps.slides',
      'com.microsoft.office.word',
      'com.microsoft.office.excel',
      'com.microsoft.office.powerpoint',
      'com.google.android.gm',
      'com.google.android.calendar',
    ];

    if (productivityPackages.contains(package) ||
        name.contains('docs') ||
        name.contains('sheets') ||
        name.contains('slides') ||
        name.contains('word') ||
        name.contains('excel') ||
        name.contains('powerpoint') ||
        name.contains('gmail') ||
        name.contains('calendar')) {
      return 'Productivity';
    }

    // Browser / Web
    if (package.contains('chrome') ||
        package.contains('browser') ||
        name.contains('chrome') ||
        name.contains('browser')) {
      return 'Web & Browsing';
    }

    return 'Others';
  }

  // ==========================================================
  // CATEGORY TOTALS
  // ==========================================================

  Map<String, int> getCategoryTotals(
    List<Map<String, dynamic>> apps,
  ) {
    final totals =
        <String, int>{
      'Social Media': 0,
      'Productivity': 0,
      'Entertainment': 0,
      'Communication': 0,
      'Web & Browsing': 0,
      'Others': 0,
    };

    for (final app in apps) {
      final packageName =
          app['packageName']?.toString() ??
              '';

      final appName =
          app['appName']?.toString() ??
              'Unknown App';

      final category =
          getAppCategory(
        packageName,
        appName,
      );

      final usage =
          (app['totalTimeInForeground'] as num?)
                  ?.toInt() ??
              0;

      totals[category] =
          (totals[category] ?? 0) + usage;
    }

    return totals;
  }
}