import 'dart:math' as math;

class MLService {
  MLService._();

  static final MLService instance = MLService._();

  // ============================================================
  // MindfulAI - Multinomial Logistic Regression Model
  //
  // Features:
  // 1. Total screen time       - minutes
  // 2. Social media time       - minutes
  // 3. Entertainment time     - minutes
  // 4. App launches
  //
  // Classes:
  // High, Low, Moderate
  //
  // The values below were generated from the trained model
  // using StandardScaler + Multinomial Logistic Regression.
  // ============================================================

  // StandardScaler mean values.
  static const List<double> _scalerMean = [
    208.125,
    69.70833333,
    42.58333333,
    55.875,
  ];

  // StandardScaler scale values.
  static const List<double> _scalerScale = [
    89.35897292,
    51.57315126,
    31.16610962,
    27.905066,
  ];

  // Logistic Regression classes.
  //
  // These coefficients correspond to:
  // [High, Low, Moderate]
  static const List<String> _classes = [
    'High',
    'Low',
    'Moderate',
  ];

  // Logistic Regression coefficients.
  //
  // Feature order:
  // [totalScreenTime,
  //  socialMediaTime,
  //  entertainmentTime,
  //  appLaunches]
  static const List<List<double>> _coefficients = [
    [
      0.79208806,
      0.76618812,
      0.88399455,
      0.83328086,
    ],
    [
      -1.05577167,
      -0.67086751,
      -0.62498639,
      -0.93733418,
    ],
    [
      0.26368361,
      -0.09532061,
      -0.25900816,
      0.10405332,
    ],
  ];

  // Logistic Regression intercept values.
  static const List<double> _intercepts = [
    0.54023676,
    -1.44799599,
    0.90775923,
  ];

  /// Analyzes real Android usage data using the trained
  /// Multinomial Logistic Regression model.
  ///
  /// The existing method signature is intentionally preserved
  /// so existing screens do not need to be changed.
  Map<String, dynamic> analyzeUsage({
    required int totalScreenTime,
    required int socialMediaTime,
    required int entertainmentTime,
    required int appLaunches,
  }) {
    // Android UsageStats provides time in milliseconds.
    // The training dataset uses minutes.
    final totalMinutes =
        totalScreenTime /
            Duration.millisecondsPerMinute;

    final socialMinutes =
        socialMediaTime /
            Duration.millisecondsPerMinute;

    final entertainmentMinutes =
        entertainmentTime /
            Duration.millisecondsPerMinute;

    // Features must be in exactly the same order used during training.
    final features = [
      totalMinutes,
      socialMinutes,
      entertainmentMinutes,
      appLaunches.toDouble(),
    ];

    // Standardize features using the same scaler values
    // used while training the model.
    final scaledFeatures = <double>[];

    for (int i = 0;
        i < features.length;
        i++) {
      final scale = _scalerScale[i];

      if (scale == 0) {
        scaledFeatures.add(0);
      } else {
        scaledFeatures.add(
          (features[i] -
                  _scalerMean[i]) /
              scale,
        );
      }
    }

    // Calculate model logits.
    final logits = <double>[];

    for (int classIndex = 0;
        classIndex < _classes.length;
        classIndex++) {
      double value =
          _intercepts[classIndex];

      for (int featureIndex = 0;
          featureIndex <
              scaledFeatures.length;
          featureIndex++) {
        value +=
            _coefficients[classIndex]
                    [featureIndex] *
                scaledFeatures[
                    featureIndex];
      }

      logits.add(value);
    }

    // Convert logits into probabilities using softmax.
    final probabilities =
        _softmax(logits);

    // Find the class with the highest probability.
    int predictedIndex = 0;

    for (int i = 1;
        i < probabilities.length;
        i++) {
      if (probabilities[i] >
          probabilities[
              predictedIndex]) {
        predictedIndex = i;
      }
    }

    final predictedLevel =
        _classes[predictedIndex];

    final highProbability =
        probabilities[0];

    final lowProbability =
        probabilities[1];

    final moderateProbability =
        probabilities[2];

    // Convert model probabilities into a continuous
    // distraction severity score.
    //
    // Low      = 0
    // Moderate = 50
    // High     = 100
    //
    // This keeps the existing UI's percentage-based
    // distraction score while using ML probabilities.
    final distractionScore =
        (
          (lowProbability * 0) +
          (moderateProbability * 50) +
          (highProbability * 100)
        )
            .clamp(0, 100)
            .toDouble();

    return {
      'distractionScore':
          distractionScore,

      'level':
          predictedLevel,

      'totalScreenTime':
          totalScreenTime,

      'socialMediaTime':
          socialMediaTime,

      'entertainmentTime':
          entertainmentTime,

      'appLaunches':
          appLaunches,

      // ML prediction information.
      'highProbability':
          highProbability,

      'lowProbability':
          lowProbability,

      'moderateProbability':
          moderateProbability,

      'model':
          'Multinomial Logistic Regression',
    };
  }

  /// Softmax converts Logistic Regression logits
  /// into probabilities.
  List<double> _softmax(
    List<double> logits,
  ) {
    if (logits.isEmpty) {
      return [];
    }

    // Numerical stability:
    // subtract the largest logit before exponentiation.
    final maxLogit =
        logits.reduce(math.max);

    final exponentials =
        logits
            .map(
              (logit) => math.exp(
                logit - maxLogit,
              ),
            )
            .toList();

    final sum =
        exponentials.fold<double>(
      0,
      (previous, current) =>
          previous + current,
    );

    if (sum == 0) {
      return List<double>.filled(
        logits.length,
        1 / logits.length,
      );
    }

    return exponentials
        .map(
          (value) =>
              value / sum,
        )
        .toList();
  }

  /// Returns the existing productivity score.
  ///
  /// This method is kept unchanged so HomeScreen
  /// continues working exactly as before.
  int calculateProductivityScore({
    required int totalScreenTime,
    required int productiveTime,
    required int distractingTime,
  }) {
    if (totalScreenTime <= 0) {
      return 0;
    }

    final score =
        ((productiveTime /
                    totalScreenTime) *
                100)
            .round();

    return score.clamp(0, 100);
  }

  /// Generates a short insight from the ML analysis.
  String generateInsight({
    required double distractionScore,
    required String level,
  }) {
    if (level == 'Low') {
      return 'Your digital habits look balanced today.';
    }

    if (level == 'Moderate') {
      return 'Some distracting app usage was detected today.';
    }

    return 'High distracting app usage was detected. '
        'Consider taking a focused break.';
  }
}