import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class FirebaseService {
  FirebaseService._();

  static final FirebaseService instance =
      FirebaseService._();

  final FirebaseFirestore _firestore =
      FirebaseFirestore.instance;

  final FirebaseAuth _auth =
      FirebaseAuth.instance;

  String? get currentUserId =>
      _auth.currentUser?.uid;

  /// Creates or updates the user's profile.
  Future<void> saveUserProfile({
    required String name,
    required String email,
  }) async {
    final uid = currentUserId;

    if (uid == null) return;

    await _firestore
        .collection('users')
        .doc(uid)
        .set(
      {
        'name': name.trim(),
        'email': email.trim(),
        'updatedAt':
            FieldValue.serverTimestamp(),
      },
      SetOptions(merge: true),
    );
  }

  /// Gets the current user's profile.
  Future<Map<String, dynamic>?> getUserProfile()
      async {
    final uid = currentUserId;

    if (uid == null) return null;

    final document = await _firestore
        .collection('users')
        .doc(uid)
        .get();

    if (!document.exists) {
      return null;
    }

    return document.data();
  }

  /// Saves daily app usage.
  Future<void> saveDailyUsage({
    required String date,
    required int totalScreenTime,
    required int appsUsed,
    required int appLaunches,
    required List<Map<String, dynamic>> appUsage,
  }) async {
    final uid = currentUserId;

    if (uid == null) return;

    await _firestore
        .collection('users')
        .doc(uid)
        .collection('usage')
        .doc(date)
        .set(
      {
        'date': date,
        'totalScreenTime': totalScreenTime,
        'appsUsed': appsUsed,
        'appLaunches': appLaunches,
        'appUsage': appUsage,
        'updatedAt':
            FieldValue.serverTimestamp(),
      },
      SetOptions(merge: true),
    );
  }

  /// Gets usage for a particular date.
  Future<Map<String, dynamic>?> getDailyUsage(
    String date,
  ) async {
    final uid = currentUserId;

    if (uid == null) return null;

    final document = await _firestore
        .collection('users')
        .doc(uid)
        .collection('usage')
        .doc(date)
        .get();

    if (!document.exists) {
      return null;
    }

    return document.data();
  }

  /// Gets recent usage records.
  Future<List<Map<String, dynamic>>> getRecentUsage({
    int limit = 7,
  }) async {
    final uid = currentUserId;

    if (uid == null) return [];

    final snapshot = await _firestore
        .collection('users')
        .doc(uid)
        .collection('usage')
        .orderBy(
          'date',
          descending: true,
        )
        .limit(limit)
        .get();

    return snapshot.docs.map((document) {
      return {
        'id': document.id,
        ...document.data(),
      };
    }).toList();
  }
}