import 'dart:typed_data';

class AppUsageModel {
  final String appName;
  final String packageName;
  final int totalTimeInForeground;
  final int lastTimeUsed;
  final int launchCount;

  // Actual Android app icon.
  final Uint8List? iconBytes;

  const AppUsageModel({
    required this.appName,
    required this.packageName,
    required this.totalTimeInForeground,
    required this.lastTimeUsed,
    required this.launchCount,
    this.iconBytes,
  });

  factory AppUsageModel.fromMap(
    Map<String, dynamic> map,
  ) {
    Uint8List? icon;

    final rawIcon = map['iconBytes'];

    if (rawIcon is Uint8List) {
      icon = rawIcon;
    } else if (rawIcon is List) {
      try {
        icon = Uint8List.fromList(
          rawIcon
              .map(
                (item) =>
                    (item as num).toInt(),
              )
              .toList(),
        );
      } catch (_) {
        icon = null;
      }
    }

    return AppUsageModel(
      appName:
          map['appName']?.toString() ??
              'Unknown App',

      packageName:
          map['packageName']?.toString() ??
              '',

      totalTimeInForeground:
          (map['totalTimeInForeground']
                  as num?)
              ?.toInt() ??
              0,

      lastTimeUsed:
          (map['lastTimeUsed'] as num?)
              ?.toInt() ??
              0,

      launchCount:
          (map['launchCount'] as num?)
              ?.toInt() ??
              0,

      iconBytes: icon,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'appName': appName,
      'packageName': packageName,
      'totalTimeInForeground':
          totalTimeInForeground,
      'lastTimeUsed': lastTimeUsed,
      'launchCount': launchCount,

      // Don't save the binary icon to Firebase.
      // The icon is retrieved directly from Android.
    };
  }

  Duration get usageDuration {
    return Duration(
      milliseconds:
          totalTimeInForeground,
    );
  }

  String get formattedDuration {
    final duration =
        usageDuration;

    final hours =
        duration.inHours;

    final minutes =
        duration.inMinutes
            .remainder(60);

    if (hours > 0) {
      return '${hours}h ${minutes}m';
    }

    return '${minutes}m';
  }

  String get formattedLastUsed {
    if (lastTimeUsed <= 0) {
      return 'Not available';
    }

    final date =
        DateTime.fromMillisecondsSinceEpoch(
      lastTimeUsed,
    );

    final hour =
        date.hour % 12 == 0
            ? 12
            : date.hour % 12;

    final minute =
        date.minute
            .toString()
            .padLeft(2, '0');

    final period =
        date.hour >= 12
            ? 'PM'
            : 'AM';

    return '$hour:$minute $period';
  }
}