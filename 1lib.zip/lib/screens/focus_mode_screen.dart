import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/notification_service.dart';
import 'blocked_apps_screen.dart';
import 'focus_statistics_screen.dart';

class FocusModeScreen extends StatefulWidget {
  const FocusModeScreen({super.key});

  @override
  State<FocusModeScreen> createState() =>
      _FocusModeScreenState();
}

class _FocusModeScreenState extends State<FocusModeScreen> {
  Timer? _timer;

  final List<int> _durations = [15, 25, 45, 60];

  int _selectedDuration = 25;
  int _remainingSeconds = 25 * 60;

  bool _isRunning = false;
  bool _isCompleted = false;
  bool _focusReminderEnabled = false;

  DateTime? _focusEndTime;

  static const int _focusNotificationId = 1001;

  static const String _focusEndTimeKey = 'focus_end_time';
  static const String _focusDurationKey = 'focus_duration';
  static const String _focusHistoryKey =
      'focus_session_history';

  static const String _focusBlockEnabledKey =
      'focus_block_enabled';

  @override
  void initState() {
    super.initState();

    _loadFocusReminderSetting();
    _restoreFocusTimer();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  // ------------------------------------------------------------
  // FOCUS BLOCKING
  // ------------------------------------------------------------

  Future<void> _setFocusBlocking(bool enabled) async {
    try {
      final prefs =
          await SharedPreferences.getInstance();

      await prefs.setBool(
        _focusBlockEnabledKey,
        enabled,
      );
    } catch (e) {
      // Do not interrupt Focus Mode if saving fails.
    }
  }

  // ------------------------------------------------------------
  // FOCUS REMINDER
  // ------------------------------------------------------------

  Future<void> _loadFocusReminderSetting() async {
    try {
      final enabled =
          await NotificationService.instance
              .getFocusReminderEnabled();

      if (!mounted) return;

      setState(() {
        _focusReminderEnabled = enabled;
      });
    } catch (e) {
      // Keep default value false.
    }
  }

  Future<void> _toggleFocusReminder() async {
    final newValue = !_focusReminderEnabled;

    await NotificationService.instance
        .setFocusReminderEnabled(newValue);

    if (!mounted) return;

    setState(() {
      _focusReminderEnabled = newValue;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          newValue
              ? '🔔 Focus reminders enabled'
              : '🔕 Focus reminders disabled',
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );

    if (newValue && _isRunning) {
      await _scheduleFocusCompletionNotification();
    }

    if (!newValue) {
      await _cancelFocusNotification();
    }
  }

  // ------------------------------------------------------------
  // RESTORE TIMER
  // ------------------------------------------------------------

  Future<void> _restoreFocusTimer() async {
    try {
      final prefs =
          await SharedPreferences.getInstance();

      final savedEndTime =
          prefs.getString(_focusEndTimeKey);

      final savedDuration =
          prefs.getInt(_focusDurationKey);

      if (savedDuration != null &&
          _durations.contains(savedDuration)) {
        _selectedDuration = savedDuration;
      }

      if (savedEndTime == null) {
        await _setFocusBlocking(false);

        if (!mounted) return;

        setState(() {
          _remainingSeconds =
              _selectedDuration * 60;
          _isRunning = false;
          _isCompleted = false;
        });

        return;
      }

      final endTime =
          DateTime.tryParse(savedEndTime);

      if (endTime == null) {
        await prefs.remove(_focusEndTimeKey);
        await _setFocusBlocking(false);

        if (!mounted) return;

        setState(() {
          _remainingSeconds =
              _selectedDuration * 60;
          _isRunning = false;
          _isCompleted = false;
        });

        return;
      }

      final remaining =
          endTime.difference(DateTime.now()).inSeconds;

      if (remaining <= 0) {
        await prefs.remove(_focusEndTimeKey);

        _focusEndTime = null;

        await _cancelFocusNotification();

        await _setFocusBlocking(false);

        await _saveCompletedFocusSession();

        if (!mounted) return;

        setState(() {
          _remainingSeconds = 0;
          _isRunning = false;
          _isCompleted = true;
        });

        return;
      }

      _focusEndTime = endTime;

      await _setFocusBlocking(true);

      if (!mounted) return;

      setState(() {
        _remainingSeconds = remaining;
        _isRunning = true;
        _isCompleted = false;
      });

      _startCountdown();
    } catch (e) {
      await _setFocusBlocking(false);
    }
  }

  // ------------------------------------------------------------
  // COUNTDOWN
  // ------------------------------------------------------------

  void _startCountdown() {
    _timer?.cancel();

    _timer = Timer.periodic(
      const Duration(seconds: 1),
      (timer) async {
        if (!mounted || _focusEndTime == null) {
          timer.cancel();
          return;
        }

        final remaining =
            _focusEndTime!
                .difference(DateTime.now())
                .inSeconds;

        if (remaining <= 0) {
          timer.cancel();

          final prefs =
              await SharedPreferences.getInstance();

          await prefs.remove(_focusEndTimeKey);

          _focusEndTime = null;

          await _cancelFocusNotification();

          await _setFocusBlocking(false);

          await _saveCompletedFocusSession();

          if (!mounted) return;

          setState(() {
            _remainingSeconds = 0;
            _isRunning = false;
            _isCompleted = true;
          });

          _showCompletionMessage();

          return;
        }

        if (!mounted) return;

        setState(() {
          _remainingSeconds = remaining;
        });
      },
    );
  }

  // ------------------------------------------------------------
  // START TIMER
  // ------------------------------------------------------------

  Future<void> _startTimer() async {
    if (_isRunning) return;

    if (_remainingSeconds <= 0) {
      _remainingSeconds =
          _selectedDuration * 60;
    }

    final endTime =
        DateTime.now().add(
      Duration(
        seconds: _remainingSeconds,
      ),
    );

    final prefs =
        await SharedPreferences.getInstance();

    await prefs.setString(
      _focusEndTimeKey,
      endTime.toIso8601String(),
    );

    await prefs.setInt(
      _focusDurationKey,
      _selectedDuration,
    );

    _focusEndTime = endTime;

    await _setFocusBlocking(true);

    if (!mounted) return;

    setState(() {
      _isRunning = true;
      _isCompleted = false;
    });

    if (_focusReminderEnabled) {
      await _scheduleFocusCompletionNotification();
    }

    _startCountdown();
  }

  // ------------------------------------------------------------
  // PAUSE TIMER
  // ------------------------------------------------------------

  Future<void> _pauseTimer() async {
    _timer?.cancel();

    _timer = null;

    await _cancelFocusNotification();

    final prefs =
        await SharedPreferences.getInstance();

    await prefs.remove(_focusEndTimeKey);

    _focusEndTime = null;

    await _setFocusBlocking(false);

    if (!mounted) return;

    setState(() {
      _isRunning = false;
      _isCompleted = false;
    });
  }

  // ------------------------------------------------------------
  // RESET TIMER
  // ------------------------------------------------------------

  Future<void> _resetTimer() async {
    _timer?.cancel();

    _timer = null;

    await _cancelFocusNotification();

    final prefs =
        await SharedPreferences.getInstance();

    await prefs.remove(_focusEndTimeKey);

    await prefs.remove(_focusDurationKey);

    _focusEndTime = null;

    await _setFocusBlocking(false);

    if (!mounted) return;

    setState(() {
      _isRunning = false;
      _isCompleted = false;
      _remainingSeconds =
          _selectedDuration * 60;
    });
  }

  // ------------------------------------------------------------
  // SELECT DURATION
  // ------------------------------------------------------------

  Future<void> _selectDuration(
    int minutes,
  ) async {
    if (_isRunning) return;

    await _cancelFocusNotification();

    final prefs =
        await SharedPreferences.getInstance();

    await prefs.remove(_focusEndTimeKey);

    await prefs.setInt(
      _focusDurationKey,
      minutes,
    );

    _focusEndTime = null;

    await _setFocusBlocking(false);

    if (!mounted) return;

    setState(() {
      _selectedDuration = minutes;
      _remainingSeconds = minutes * 60;
      _isCompleted = false;
    });
  }

  // ------------------------------------------------------------
  // NOTIFICATION
  // ------------------------------------------------------------

  Future<void> _scheduleFocusCompletionNotification() async {
    if (!_focusReminderEnabled) return;

    if (_remainingSeconds <= 0) return;

    final completionTime =
        DateTime.now().add(
      Duration(
        seconds: _remainingSeconds,
      ),
    );

    await NotificationService.instance
        .scheduleNotification(
      id: _focusNotificationId,
      title: '🎯 Focus Session Complete',
      body:
          'Great job! Your focus session is complete. Take a short break.',
      scheduledDate: completionTime,
    );
  }

  Future<void> _cancelFocusNotification() async {
    await NotificationService.instance
        .cancelNotification(
      _focusNotificationId,
    );
  }

  // ------------------------------------------------------------
  // SAVE FOCUS HISTORY
  // ------------------------------------------------------------

  Future<void> _saveCompletedFocusSession() async {
    try {
      final prefs =
          await SharedPreferences.getInstance();

      final existingData =
          prefs.getStringList(
                _focusHistoryKey,
              ) ??
              [];

      final session = {
        'duration': _selectedDuration,
        'completedAt':
            DateTime.now().toIso8601String(),
      };

      existingData.add(
        jsonEncode(session),
      );

      await prefs.setStringList(
        _focusHistoryKey,
        existingData,
      );
    } catch (e) {
      // Do not interrupt the focus screen.
    }
  }

  // ------------------------------------------------------------
  // COMPLETION MESSAGE
  // ------------------------------------------------------------

  void _showCompletionMessage() {
    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          '🎉 Focus session completed!',
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // ------------------------------------------------------------
  // TIMER FORMAT
  // ------------------------------------------------------------

  String _formatTime() {
    final minutes =
        _remainingSeconds ~/ 60;

    final seconds =
        _remainingSeconds % 60;

    return '${minutes.toString().padLeft(2, '0')}:'
        '${seconds.toString().padLeft(2, '0')}';
  }

  double get _progress {
    final totalSeconds =
        _selectedDuration * 60;

    if (totalSeconds <= 0) {
      return 0;
    }

    return 1 -
        (_remainingSeconds / totalSeconds);
  }

  // ------------------------------------------------------------
  // BUILD
  // ------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          const Color(0xFFF7F5FF),
      appBar: AppBar(
        backgroundColor:
            const Color(0xFFF7F5FF),
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: TextButton(
          onPressed: () =>
              Navigator.maybePop(context),
          child: const Text(
            '‹',
            style: TextStyle(
              fontSize: 38,
              height: .8,
              fontWeight:
                  FontWeight.w300,
              color: Color(0xFF252238),
            ),
          ),
        ),
        title: const Text(
          'Focus Mode',
          style: TextStyle(
            color: Color(0xFF252238),
            fontSize: 20,
            fontWeight:
                FontWeight.w800,
          ),
        ),
      ),
      body: SafeArea(
        child: ListView(
          padding:
              const EdgeInsets.fromLTRB(
            20,
            8,
            20,
            30,
          ),
          children: [
            _buildHero(),
            const SizedBox(height: 18),
            _buildTimerCard(),
            const SizedBox(height: 18),
            _buildDurationSelector(),
            const SizedBox(height: 18),
            _buildFocusOptions(),
          ],
        ),
      ),
    );
  }

  // ------------------------------------------------------------
  // HERO
  // ------------------------------------------------------------

  Widget _buildHero() {
    return Container(
      height: 145,
      padding:
          const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient:
            const LinearGradient(
          colors: [
            Color(0xFFE8E1FF),
            Color(0xFFF2EEFF),
          ],
          begin:
              Alignment.topLeft,
          end:
              Alignment.bottomRight,
        ),
        borderRadius:
            BorderRadius.circular(27),
      ),
      child: Stack(
        children: [
          Positioned(
            right: 10,
            top: 5,
            child: Container(
              width: 90,
              height: 90,
              decoration:
                  BoxDecoration(
                color: Colors.white
                    .withValues(
                  alpha: .45,
                ),
                shape:
                    BoxShape.circle,
              ),
            ),
          ),
          const Positioned(
            right: 28,
            top: 22,
            child: Text(
              '☀️',
              style:
                  TextStyle(
                fontSize: 34,
              ),
            ),
          ),
          const Positioned(
            right: 65,
            bottom: 8,
            child: Text(
              '🏔️',
              style:
                  TextStyle(
                fontSize: 56,
              ),
            ),
          ),
          const Align(
            alignment:
                Alignment.centerLeft,
            child: Column(
              mainAxisAlignment:
                  MainAxisAlignment
                      .center,
              crossAxisAlignment:
                  CrossAxisAlignment
                      .start,
              children: [
                Text(
                  'Focus Mode',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight:
                        FontWeight
                            .w900,
                    color:
                        Color(
                      0xFF252238,
                    ),
                  ),
                ),
                SizedBox(height: 5),
                Text(
                  'Create time for what matters.',
                  style: TextStyle(
                    fontSize: 12.5,
                    color:
                        Color(
                      0xFF62587B,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------
  // TIMER CARD
  // ------------------------------------------------------------

  Widget _buildTimerCard() {
    return Container(
      padding:
          const EdgeInsets.fromLTRB(
        20,
        25,
        20,
        23,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(27),
        boxShadow: [
          BoxShadow(
            color:
                const Color(
              0xFF7357D9,
            ).withValues(
              alpha: .07,
            ),
            blurRadius: 20,
            offset:
                const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          SizedBox(
            width: 215,
            height: 215,
            child: Stack(
              alignment:
                  Alignment.center,
              children: [
                SizedBox(
                  width: 215,
                  height: 215,
                  child:
                      CircularProgressIndicator(
                    value: _progress,
                    strokeWidth: 14,
                    strokeCap:
                        StrokeCap.round,
                    backgroundColor:
                        const Color(
                      0xFFEDE9FB,
                    ),
                    valueColor:
                        const AlwaysStoppedAnimation<
                            Color>(
                      Color(
                        0xFF7357D9,
                      ),
                    ),
                  ),
                ),
                Container(
                  width: 165,
                  height: 165,
                  decoration:
                      const BoxDecoration(
                    shape:
                        BoxShape.circle,
                    color:
                        Color(
                      0xFFF7F5FF,
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment:
                        MainAxisAlignment
                            .center,
                    children: [
                      Text(
                        _formatTime(),
                        style:
                            const TextStyle(
                          fontSize: 30,
                          fontWeight:
                              FontWeight
                                  .w900,
                          color:
                              Color(
                            0xFF252238,
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 4,
                      ),
                      Text(
                        _isCompleted
                            ? 'Completed'
                            : 'Focus Time',
                        style:
                            const TextStyle(
                          fontSize: 12,
                          color:
                              Color(
                            0xFF8B849E,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            height: 53,
            child:
                ElevatedButton(
              onPressed:
                  _isRunning
                      ? _pauseTimer
                      : _startTimer,
              style:
                  ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(
                  0xFF7357D9,
                ),
                foregroundColor:
                    Colors.white,
                elevation: 0,
                shape:
                    RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius
                          .circular(
                    17,
                  ),
                ),
              ),
              child: Row(
                mainAxisAlignment:
                    MainAxisAlignment
                        .center,
                children: [
                  Text(
                    _isRunning
                        ? '⏸️'
                        : '▶️',
                    style:
                        const TextStyle(
                      fontSize: 17,
                    ),
                  ),
                  const SizedBox(
                    width: 9,
                  ),
                  Text(
                    _isRunning
                        ? 'Pause Focus'
                        : 'Start Focus',
                    style:
                        const TextStyle(
                      fontSize: 14,
                      fontWeight:
                          FontWeight
                              .w800,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 10),
          TextButton(
            onPressed:
                _resetTimer,
            child:
                const Text(
              '🔄 Reset',
              style:
                  TextStyle(
                color:
                    Color(
                  0xFF7357D9,
                ),
                fontWeight:
                    FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------
  // DURATION SELECTOR
  // ------------------------------------------------------------

  Widget _buildDurationSelector() {
    return Container(
      padding:
          const EdgeInsets.all(17),
      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(23),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          const Text(
            'Choose Focus Time',
            style: TextStyle(
              fontSize: 16,
              fontWeight:
                  FontWeight.w800,
              color:
                  Color(0xFF252238),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children:
                _durations.map(
              (duration) {
                final selected =
                    duration ==
                        _selectedDuration;

                return Expanded(
                  child:
                      GestureDetector(
                    onTap: () =>
                        _selectDuration(
                      duration,
                    ),
                    child:
                        Container(
                      margin:
                          const EdgeInsets
                              .only(
                        right: 8,
                      ),
                      padding:
                          const EdgeInsets
                              .symmetric(
                        vertical: 12,
                      ),
                      decoration:
                          BoxDecoration(
                        color: selected
                            ? const Color(
                                0xFF7357D9,
                              )
                            : const Color(
                                0xFFF4F1FF,
                              ),
                        borderRadius:
                            BorderRadius
                                .circular(
                          14,
                        ),
                      ),
                      child:
                          Column(
                        children: [
                          Text(
                            '$duration',
                            style:
                                TextStyle(
                              fontSize: 16,
                              fontWeight:
                                  FontWeight
                                      .w900,
                              color:
                                  selected
                                      ? Colors
                                          .white
                                      : const Color(
                                          0xFF403B52,
                                        ),
                            ),
                          ),
                          const SizedBox(
                            height: 2,
                          ),
                          Text(
                            'min',
                            style:
                                TextStyle(
                              fontSize: 10,
                              color:
                                  selected
                                      ? Colors
                                          .white70
                                      : const Color(
                                          0xFF8B849E,
                                        ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                );
              },
            ).toList(),
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------
  // FOCUS OPTIONS
  // ------------------------------------------------------------

  Widget _buildFocusOptions() {
    return Container(
      padding:
          const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(23),
      ),
      child: Column(
        children: [
          _optionRow(
            emoji: '📵',
            title:
                'Block distracting apps',
            onTap: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      const BlockedAppsScreen(),
                ),
              );
            },
          ),
          const Divider(
            height: 22,
          ),
          _optionRow(
            emoji: '🔔',
            title:
                'Get focus reminders',
            trailing:
                Switch.adaptive(
              value:
                  _focusReminderEnabled,
              onChanged: (_) =>
                  _toggleFocusReminder(),
              activeThumbColor:
                  const Color(
                0xFF7357D9,
              ),
              activeTrackColor:
                  const Color(
                0xFFD9D0FF,
              ),
            ),
            onTap:
                _toggleFocusReminder,
          ),
          const Divider(
            height: 22,
          ),
          _optionRow(
            emoji: '📈',
            title:
                'Track your progress',
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) =>
                      const FocusStatisticsScreen(),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  // ------------------------------------------------------------
  // OPTION ROW
  // ------------------------------------------------------------

  Widget _optionRow({
    required String emoji,
    required String title,
    Widget? trailing,
    VoidCallback? onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius:
          BorderRadius.circular(12),
      child: Padding(
        padding:
            const EdgeInsets.symmetric(
          vertical: 2,
        ),
        child: Row(
          children: [
            Container(
              width: 39,
              height: 39,
              decoration:
                  BoxDecoration(
                color:
                    const Color(
                  0xFFF0ECFF,
                ),
                borderRadius:
                    BorderRadius.circular(
                  12,
                ),
              ),
              child: Center(
                child: Text(
                  emoji,
                  style:
                      const TextStyle(
                    fontSize: 19,
                  ),
                ),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                title,
                style:
                    const TextStyle(
                  fontSize: 13,
                  fontWeight:
                      FontWeight.w600,
                  color:
                      Color(
                    0xFF403B52,
                  ),
                ),
              ),
            ),
            trailing ??
                const Text(
                  '›',
                  style:
                      TextStyle(
                    fontSize: 24,
                    color:
                        Color(
                      0xFF9C96AC,
                    ),
                  ),
                ),
          ],
        ),
      ),
    );
  }
}