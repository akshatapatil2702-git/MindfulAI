import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/usage_service.dart';

class BlockedAppsScreen extends StatefulWidget {
  const BlockedAppsScreen({super.key});

  @override
  State<BlockedAppsScreen> createState() =>
      _BlockedAppsScreenState();
}

class _BlockedAppsScreenState
    extends State<BlockedAppsScreen> {
  final UsageService _usageService =
      UsageService.instance;

  List<Map<String, dynamic>> _apps = [];
  Set<String> _selectedPackages = {};
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadApps();
  }

  Future<void> _loadApps() async {
    try {
      final prefs =
          await SharedPreferences.getInstance();

      final saved =
          prefs.getString('blocked_packages');

      if (saved != null && saved.isNotEmpty) {
        final List<dynamic> decoded =
            jsonDecode(saved);

        _selectedPackages =
            decoded.map((e) => e.toString()).toSet();
      }

      final usage =
          await _usageService.getTodayUsage();

      if (!mounted) return;

      setState(() {
        _apps = usage;
        _isLoading = false;
      });
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<void> _saveBlockedApps() async {
    final prefs =
        await SharedPreferences.getInstance();

    await prefs.setString(
      'blocked_packages',
      jsonEncode(
        _selectedPackages.toList(),
      ),
    );

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text(
          'Blocked apps saved successfully',
        ),
      ),
    );

    Navigator.pop(context, true);
  }

  void _toggleApp(String packageName) {
    setState(() {
      if (_selectedPackages.contains(packageName)) {
        _selectedPackages.remove(packageName);
      } else {
        _selectedPackages.add(packageName);
      }
    });
  }

  String _formatUsage(dynamic value) {
    final milliseconds =
        value is int
            ? value
            : int.tryParse(value.toString()) ?? 0;

    final duration =
        Duration(milliseconds: milliseconds);

    final hours = duration.inHours;
    final minutes =
        duration.inMinutes.remainder(60);

    if (hours > 0) {
      return '${hours}h ${minutes}m used today';
    }

    return '${minutes}m used today';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          const Color(0xFFF5F3FF),
      appBar: AppBar(
        backgroundColor:
            const Color(0xFF6C63FF),
        foregroundColor: Colors.white,
        elevation: 0,
        title: const Text(
          'Block Distracting Apps',
          style: TextStyle(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : _apps.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'No app usage data found.\n\n'
                      'Please allow Usage Access permission '
                      'and use some apps first.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.black54,
                      ),
                    ),
                  ),
                )
              : Column(
                  children: [
                    Container(
                      width: double.infinity,
                      margin: const EdgeInsets.all(16),
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius:
                            BorderRadius.circular(16),
                      ),
                      child: Row(
                        children: [
                          Container(
                            padding:
                                const EdgeInsets.all(10),
                            decoration: BoxDecoration(
                              color: const Color(
                                0xFFE8E5FF,
                              ),
                              borderRadius:
                                  BorderRadius.circular(12),
                            ),
                            child: const Icon(
                              Icons.block,
                              color:
                                  Color(0xFF6C63FF),
                            ),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Text(
                              _selectedPackages.isEmpty
                                  ? 'Select apps to block during Focus Mode.'
                                  : '${_selectedPackages.length} app(s) selected',
                              style: const TextStyle(
                                fontSize: 15,
                                fontWeight:
                                    FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),

                    Expanded(
                      child: ListView.builder(
                        padding:
                            const EdgeInsets.fromLTRB(
                          16,
                          0,
                          16,
                          16,
                        ),
                        itemCount: _apps.length,
                        itemBuilder:
                            (context, index) {
                          final app =
                              _apps[index];

                          final appName =
                              app['appName']
                                      ?.toString() ??
                                  'Unknown App';

                          final packageName =
                              app['packageName']
                                      ?.toString() ??
                                  '';

                          final isSelected =
                              _selectedPackages
                                  .contains(
                            packageName,
                          );

                          return Container(
                            margin:
                                const EdgeInsets.only(
                              bottom: 10,
                            ),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius:
                                  BorderRadius.circular(
                                14,
                              ),
                            ),
                            child: CheckboxListTile(
                              value: isSelected,
                              onChanged:
                                  packageName.isEmpty
                                      ? null
                                      : (_) {
                                          _toggleApp(
                                            packageName,
                                          );
                                        },
                              activeColor:
                                  const Color(
                                0xFF6C63FF,
                              ),
                              title: Text(
                                appName,
                                style:
                                    const TextStyle(
                                  fontWeight:
                                      FontWeight.w600,
                                ),
                              ),
                              subtitle: Text(
                                _formatUsage(
                                  app[
                                    'totalTimeInForeground'
                                  ],
                                ),
                              ),
                              secondary: Container(
                                width: 42,
                                height: 42,
                                decoration:
                                    BoxDecoration(
                                  color: const Color(
                                    0xFFE8E5FF,
                                  ),
                                  borderRadius:
                                      BorderRadius
                                          .circular(
                                    12,
                                  ),
                                ),
                                child: const Icon(
                                  Icons.apps,
                                  color:
                                      Color(
                                    0xFF6C63FF,
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ),

                    SafeArea(
                      child: Padding(
                        padding:
                            const EdgeInsets.all(16),
                        child: SizedBox(
                          width: double.infinity,
                          height: 52,
                          child: ElevatedButton(
                            onPressed:
                                _saveBlockedApps,
                            style:
                                ElevatedButton.styleFrom(
                              backgroundColor:
                                  const Color(
                                0xFF6C63FF,
                              ),
                              foregroundColor:
                                  Colors.white,
                              shape:
                                  RoundedRectangleBorder(
                                borderRadius:
                                    BorderRadius.circular(
                                  14,
                                ),
                              ),
                            ),
                            child: const Text(
                              'Save Blocked Apps',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight:
                                    FontWeight.bold,
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
    );
  }
}