import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../services/firebase_service.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() =>
      _ReportsScreenState();
}

class _ReportsScreenState
    extends State<ReportsScreen> {
  static const Color primary =
      Color(0xFF7357D9);

  static const Color background =
      Color(0xFFF7F5FF);

  static const Color textColor =
      Color(0xFF252238);

  static const String _focusHistoryKey =
      'focus_session_history';

  bool _weekly = true;
  bool _loading = true;

  List<Map<String, dynamic>> _records = [];
  List<Map<String, dynamic>> _focusSessions = [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  // ==========================================================
  // LOAD DATA
  // ==========================================================

  Future<void> _load() async {
    if (mounted) {
      setState(() {
        _loading = true;
      });
    }

    try {
      final usageRecords =
          await FirebaseService.instance
              .getRecentUsage(
        limit: _weekly ? 7 : 30,
      );

      final prefs =
          await SharedPreferences.getInstance();

      final savedSessions =
          prefs.getStringList(
                _focusHistoryKey,
              ) ??
              [];

      final parsedSessions =
          <Map<String, dynamic>>[];

      for (final item in savedSessions) {
        try {
          final decoded =
              jsonDecode(item);

          if (decoded is Map) {
            parsedSessions.add(
              Map<String, dynamic>.from(
                decoded,
              ),
            );
          }
        } catch (_) {}
      }

      if (!mounted) return;

      setState(() {
        _records = usageRecords;
        _focusSessions =
            parsedSessions;
        _loading = false;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _loading = false;
      });

      _showMessage(
        'Unable to load reports.',
      );
    }
  }

  // ==========================================================
  // HELPERS
  // ==========================================================

  int _int(dynamic value) {
    if (value is num) {
      return value.toInt();
    }

    return int.tryParse(
          '$value',
        ) ??
        0;
  }

  DateTime? _parseDate(
    dynamic value,
  ) {
    if (value == null) {
      return null;
    }

    if (value is DateTime) {
      return value;
    }

    return DateTime.tryParse(
      value.toString(),
    );
  }

  String _formatDuration(
    int milliseconds,
  ) {
    final duration =
        Duration(
      milliseconds:
          milliseconds,
    );

    final hours =
        duration.inHours;

    final minutes =
        duration.inMinutes
            .remainder(60);

    if (hours > 0) {
      return '${hours}h ${minutes}m';
    }

    return '${minutes}m';
  }

  String _formatMinutes(
    int minutes,
  ) {
    if (minutes <= 0) {
      return '0m';
    }

    final hours =
        minutes ~/ 60;

    final remaining =
        minutes % 60;

    if (hours == 0) {
      return '${remaining}m';
    }

    if (remaining == 0) {
      return '${hours}h';
    }

    return '${hours}h ${remaining}m';
  }

  DateTime? _focusDate(
    Map<String, dynamic> session,
  ) {
    return _parseDate(
      session['completedAt'],
    );
  }

  int _focusMinutesFor(
    Map<String, dynamic> session,
  ) {
    return _int(
      session['duration'],
    );
  }

  // ==========================================================
  // FILTERED DATA
  // ==========================================================

  List<Map<String, dynamic>>
      get _filteredFocusSessions {
    final now =
        DateTime.now();

    final today = DateTime(
      now.year,
      now.month,
      now.day,
    );

    final start =
        today.subtract(
      Duration(
        days:
            _weekly ? 6 : 29,
      ),
    );

    return _focusSessions
        .where(
          (session) {
            final date =
                _focusDate(session);

            if (date == null) {
              return false;
            }

            return !date.isBefore(
                  start,
                ) &&
                !date.isAfter(now);
          },
        )
        .toList();
  }

  int get _totalScreenTime {
    return _records.fold<int>(
      0,
      (
        sum,
        record,
      ) =>
          sum +
          _int(
            record[
              'totalScreenTime'
            ],
          ),
    );
  }

  int get _totalLaunches {
    return _records.fold<int>(
      0,
      (
        sum,
        record,
      ) =>
          sum +
          _int(
            record[
              'appLaunches'
            ],
          ),
    );
  }

  int get _focusMinutes {
    return _filteredFocusSessions
        .fold<int>(
      0,
      (
        sum,
        session,
      ) =>
          sum +
          _focusMinutesFor(
            session,
          ),
    );
  }

  int get _focusSessionCount {
    return _filteredFocusSessions
        .length;
  }

  int get _focusScore {
    if (_focusMinutes <= 0) {
      return 0;
    }

    final target =
        _weekly
            ? 7 * 60
            : 30 * 60;

    return ((_focusMinutes /
                target) *
            100)
        .round()
        .clamp(0, 100);
  }

  int get _averageScreenTime {
    if (_records.isEmpty) {
      return 0;
    }

    return (_totalScreenTime /
            _records.length)
        .round();
  }

  // ==========================================================
  // PRODUCTIVITY
  // ==========================================================

  int get _productivityPercent {
    if (_totalScreenTime <= 0) {
      return 0;
    }

    final focusMilliseconds =
        _focusMinutes *
            60 *
            1000;

    final value =
        (focusMilliseconds /
                _totalScreenTime) *
            100;

    return value
        .round()
        .clamp(0, 100);
  }

  // ==========================================================
  // TREND DATA
  // ==========================================================

  List<_TrendPoint>
      get _trendPoints {
    if (_records.isEmpty) {
      return [];
    }

    final sorted =
        List<Map<String, dynamic>>.from(
      _records,
    );

    sorted.sort(
      (a, b) {
        final da =
            _parseDate(
              a['date'],
            );

        final db =
            _parseDate(
              b['date'],
            );

        if (da == null ||
            db == null) {
          return 0;
        }

        return da.compareTo(db);
      },
    );

    final points =
        <_TrendPoint>[];

    for (final record
        in sorted) {
      final date =
          _parseDate(
        record['date'],
      );

      if (date == null) {
        continue;
      }

      final milliseconds =
          _int(
        record[
          'totalScreenTime'
        ],
      );

      points.add(
        _TrendPoint(
          date: date,
          value:
              milliseconds /
                  3600000,
        ),
      );
    }

    return points;
  }

  // ==========================================================
  // INSIGHTS
  // ==========================================================

  List<String> get _insights {
    final result =
        <String>[];

    if (_focusSessionCount >
        0) {
      result.add(
        'You completed $_focusSessionCount focus session${_focusSessionCount == 1 ? '' : 's'} during this period.',
      );
    } else {
      result.add(
        'Complete a Focus Mode session to start building your focus history.',
      );
    }

    if (_focusMinutes > 0) {
      result.add(
        'You spent ${_formatMinutes(_focusMinutes)} in focused sessions.',
      );
    }

    if (_productivityPercent >=
        50) {
      result.add(
        'A good portion of your recorded screen time was covered by focused sessions.',
      );
    } else if (_productivityPercent >
        0) {
      result.add(
        'Try adding another short Focus Mode session to increase your focused time.',
      );
    }

    if (_totalScreenTime > 0) {
      result.add(
        'Your average recorded screen time is ${_formatDuration(_averageScreenTime)} per day.',
      );
    }

    if (_totalLaunches > 0) {
      result.add(
        'You recorded $_totalLaunches app launches during this report period.',
      );
    }

    return result;
  }

  // ==========================================================
  // UI
  // ==========================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      backgroundColor:
          background,

      appBar: AppBar(
        backgroundColor:
            background,
        elevation: 0,
        scrolledUnderElevation:
            0,

        leading: IconButton(
          onPressed: () {
            Navigator.maybePop(
              context,
            );
          },
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            size: 19,
          ),
          color:
              textColor,
        ),

        title: const Text(
          'Reports',
          style: TextStyle(
            fontSize: 20,
            fontWeight:
                FontWeight.w800,
            color:
                textColor,
          ),
        ),

        actions: [
          IconButton(
            onPressed:
                _loading
                    ? null
                    : _load,
            icon: const Icon(
              Icons.refresh_rounded,
            ),
            color:
                primary,
          ),
        ],
      ),

      body: RefreshIndicator(
        color: primary,

        onRefresh:
            _load,

        child: ListView(
          physics:
              const AlwaysScrollableScrollPhysics(),

          padding:
              const EdgeInsets.fromLTRB(
            18,
            8,
            18,
            35,
          ),

          children: [
            _buildPeriodToggle(),

            const SizedBox(
              height: 16,
            ),

            _buildTrendCard(),

            const SizedBox(
              height: 12,
            ),

            _buildMetrics(),

            const SizedBox(
              height: 12,
            ),

            _buildFocusSummary(),

            const SizedBox(
              height: 12,
            ),

            _buildInsights(),

            const SizedBox(
              height: 12,
            ),

            _buildDailySummary(),
          ],
        ),
      ),
    );
  }

  // ==========================================================
  // PERIOD TOGGLE
  // ==========================================================

  Widget _buildPeriodToggle() {
    return Container(
      padding:
          const EdgeInsets.all(4),

      decoration:
          BoxDecoration(
        color:
            const Color(0xFFECE8FF),
        borderRadius:
            BorderRadius.circular(
          18,
        ),
      ),

      child: Row(
        children: [
          Expanded(
            child:
                _buildPeriodButton(
              'Weekly',
              _weekly,
              () {
                if (_weekly) {
                  return;
                }

                setState(() {
                  _weekly = true;
                });

                _load();
              },
            ),
          ),

          Expanded(
            child:
                _buildPeriodButton(
              'Monthly',
              !_weekly,
              () {
                if (!_weekly) {
                  return;
                }

                setState(() {
                  _weekly = false;
                });

                _load();
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPeriodButton(
    String title,
    bool selected,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,

      child:
          AnimatedContainer(
        duration:
            const Duration(
          milliseconds: 180,
        ),

        padding:
            const EdgeInsets.symmetric(
          vertical: 11,
        ),

        decoration:
            BoxDecoration(
          color: selected
              ? primary
              : Colors.transparent,

          borderRadius:
              BorderRadius.circular(
            15,
          ),
        ),

        child: Text(
          title,
          textAlign:
              TextAlign.center,

          style: TextStyle(
            fontSize: 12,
            fontWeight:
                FontWeight.w800,
            color: selected
                ? Colors.white
                : textColor,
          ),
        ),
      ),
    );
  }

  // ==========================================================
  // PRODUCTIVITY TREND
  // ==========================================================

  Widget _buildTrendCard() {
    return _card(
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Productivity Trend',
                  style:
                      TextStyle(
                    fontSize: 16,
                    fontWeight:
                        FontWeight.w800,
                    color:
                        textColor,
                  ),
                ),
              ),

              Container(
                padding:
                    const EdgeInsets
                        .symmetric(
                  horizontal: 9,
                  vertical: 5,
                ),

                decoration:
                    BoxDecoration(
                  color:
                      const Color(
                    0xFFF0ECFF,
                  ),
                  borderRadius:
                      BorderRadius.circular(
                    10,
                  ),
                ),

                child: Text(
                  _weekly
                      ? '7 Days'
                      : '30 Days',
                  style:
                      const TextStyle(
                    fontSize: 10,
                    fontWeight:
                        FontWeight.w800,
                    color: primary,
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 18,
          ),

          SizedBox(
            height: 170,
            child:
                _buildTrendChart(),
          ),

          const SizedBox(
            height: 8,
          ),

          Row(
            mainAxisAlignment:
                MainAxisAlignment
                    .spaceBetween,

            children:
                _buildDateLabels(),
          ),
        ],
      ),
    );
  }

  Widget _buildTrendChart() {
    final points =
        _trendPoints;

    if (points.isEmpty) {
      return const Center(
        child: Text(
          'No saved usage data yet',
          style: TextStyle(
            fontSize: 12,
            color:
                Color(0xFF858090),
          ),
        ),
      );
    }

    return CustomPaint(
      painter:
          _ProductivityChartPainter(
        points: points,
        primary: primary,
      ),
      child:
          const SizedBox.expand(),
    );
  }

  List<Widget> _buildDateLabels() {
    final points =
        _trendPoints;

    if (points.isEmpty) {
      return [];
    }

    final visible =
        points.length > 7
            ? points.sublist(
                points.length - 7,
              )
            : points;

    return visible.map(
      (point) {
        return Text(
          _dayLabel(
            point.date,
          ),
          style:
              const TextStyle(
            fontSize: 9,
            fontWeight:
                FontWeight.w600,
            color:
                Color(0xFF9A94A8),
          ),
        );
      },
    ).toList();
  }

  String _dayLabel(
    DateTime date,
  ) {
    const names = [
      'Mon',
      'Tue',
      'Wed',
      'Thu',
      'Fri',
      'Sat',
      'Sun',
    ];

    return names[
        date.weekday - 1];
  }

  // ==========================================================
  // METRICS
  // ==========================================================

  Widget _buildMetrics() {
    return Row(
      children: [
        Expanded(
          child: _metricCard(
            title:
                'Productivity',
            value:
                _productivityPercent ==
                        0
                    ? '—'
                    : '$_productivityPercent%',
            subtitle:
                'Focus / screen time',
            icon:
                Icons.trending_up_rounded,
            background:
                const Color(
              0xFFE9F8F2,
            ),
            iconColor:
                const Color(
              0xFF299A68,
            ),
          ),
        ),

        const SizedBox(
          width: 10,
        ),

        Expanded(
          child: _metricCard(
            title:
                'Focus Hours',
            value:
                _focusMinutes == 0
                    ? '—'
                    : _formatMinutes(
                        _focusMinutes,
                      ),
            subtitle:
                'Completed sessions',
            icon:
                Icons.timer_rounded,
            background:
                const Color(
              0xFFECE8FF,
            ),
            iconColor:
                primary,
          ),
        ),
      ],
    );
  }

  Widget _metricCard({
    required String title,
    required String value,
    required String subtitle,
    required IconData icon,
    required Color background,
    required Color iconColor,
  }) {
    return Container(
      padding:
          const EdgeInsets.all(15),

      decoration:
          BoxDecoration(
        color: background,
        borderRadius:
            BorderRadius.circular(
          20,
        ),
      ),

      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          Container(
            width: 36,
            height: 36,

            decoration:
                BoxDecoration(
              color:
                  Colors.white
                      .withValues(
                alpha: 0.72,
              ),
              borderRadius:
                  BorderRadius.circular(
                11,
              ),
            ),

            child: Icon(
              icon,
              color: iconColor,
              size: 19,
            ),
          ),

          const SizedBox(
            height: 10,
          ),

          Text(
            title,
            style:
                const TextStyle(
              fontSize: 11,
              fontWeight:
                  FontWeight.w700,
              color: textColor,
            ),
          ),

          const SizedBox(
            height: 4,
          ),

          Text(
            value,
            style:
                const TextStyle(
              fontSize: 21,
              fontWeight:
                  FontWeight.w900,
              color: textColor,
            ),
          ),

          const SizedBox(
            height: 2,
          ),

          Text(
            subtitle,
            maxLines: 1,
            overflow:
                TextOverflow.ellipsis,
            style:
                const TextStyle(
              fontSize: 9,
              color:
                  Color(0xFF777286),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // FOCUS SUMMARY
  // ==========================================================

  Widget _buildFocusSummary() {
    return _card(
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          const Text(
            'Focus Summary',
            style:
                TextStyle(
              fontSize: 16,
              fontWeight:
                  FontWeight.w800,
              color: textColor,
            ),
          ),

          const SizedBox(
            height: 15,
          ),

          _summaryRow(
            Icons.track_changes_rounded,
            'Focus Score',
            _focusScore == 0
                ? '—'
                : '$_focusScore%',
          ),

          _summaryRow(
            Icons.check_circle_outline_rounded,
            'Completed Sessions',
            '$_focusSessionCount',
          ),

          _summaryRow(
            Icons.access_time_rounded,
            'Total Focus Time',
            _formatMinutes(
              _focusMinutes,
            ),
          ),

          _summaryRow(
            Icons.calendar_month_rounded,
            'Report Period',
            _weekly
                ? 'Last 7 Days'
                : 'Last 30 Days',
            last: true,
          ),
        ],
      ),
    );
  }

  Widget _summaryRow(
    IconData icon,
    String title,
    String value, {
    bool last = false,
  }) {
    return Padding(
      padding:
          EdgeInsets.only(
        bottom:
            last ? 0 : 12,
      ),

      child: Row(
        children: [
          Container(
            width: 34,
            height: 34,

            decoration:
                BoxDecoration(
              color:
                  const Color(
                0xFFF0ECFF,
              ),
              borderRadius:
                  BorderRadius.circular(
                10,
              ),
            ),

            child: Icon(
              icon,
              size: 18,
              color: primary,
            ),
          ),

          const SizedBox(
            width: 10,
          ),

          Expanded(
            child: Text(
              title,
              style:
                  const TextStyle(
                fontSize: 12,
                fontWeight:
                    FontWeight.w600,
                color:
                    Color(0xFF514B60),
              ),
            ),
          ),

          Text(
            value,
            style:
                const TextStyle(
              fontSize: 12,
              fontWeight:
                  FontWeight.w900,
              color: primary,
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // INSIGHTS
  // ==========================================================

  Widget _buildInsights() {
    final insights =
        _insights;

    return _card(
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          const Text(
            'Top Insights',
            style:
                TextStyle(
              fontSize: 16,
              fontWeight:
                  FontWeight.w800,
              color: textColor,
            ),
          ),

          const SizedBox(
            height: 14,
          ),

          for (int i = 0;
              i < math.min(
                insights.length,
                4,
              );
              i++)
            _insightRow(
              i,
              insights[i],
            ),
        ],
      ),
    );
  }

  Widget _insightRow(
    int index,
    String text,
  ) {
    const icons = [
      Icons.track_changes_rounded,
      Icons.timer_outlined,
      Icons.trending_up_rounded,
      Icons.lightbulb_outline_rounded,
    ];

    return Padding(
      padding:
          const EdgeInsets.only(
        bottom: 12,
      ),

      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          Container(
            width: 32,
            height: 32,

            decoration:
                BoxDecoration(
              color:
                  const Color(
                0xFFF0ECFF,
              ),
              borderRadius:
                  BorderRadius.circular(
                10,
              ),
            ),

            child: Icon(
              icons[
                  index %
                      icons.length],
              color: primary,
              size: 17,
            ),
          ),

          const SizedBox(
            width: 10,
          ),

          Expanded(
            child: Text(
              text,
              style:
                  const TextStyle(
                fontSize: 11.5,
                height: 1.4,
                color: textColor,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // DAILY SUMMARY
  // ==========================================================

  Widget _buildDailySummary() {
    return _card(
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,

            decoration:
                BoxDecoration(
              color:
                  const Color(
                0xFFF0ECFF,
              ),
              borderRadius:
                  BorderRadius.circular(
                13,
              ),
            ),

            child: const Icon(
              Icons.insights_rounded,
              color: primary,
              size: 23,
            ),
          ),

          const SizedBox(
            width: 12,
          ),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [
                const Text(
                  'Usage Overview',
                  style:
                      TextStyle(
                    fontSize: 13,
                    fontWeight:
                        FontWeight.w800,
                    color:
                        textColor,
                  ),
                ),

                const SizedBox(
                  height: 4,
                ),

                Text(
                  _records.isEmpty
                      ? 'No usage records have been saved yet.'
                      : '${_formatDuration(_averageScreenTime)} average daily screen time • $_totalLaunches app launches',
                  style:
                      const TextStyle(
                    fontSize: 10.5,
                    height: 1.4,
                    color:
                        Color(0xFF777286),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // CARD
  // ==========================================================

  Widget _card({
    required Widget child,
    Color color = Colors.white,
  }) {
    return Container(
      padding:
          const EdgeInsets.all(16),

      decoration:
          BoxDecoration(
        color: color,
        borderRadius:
            BorderRadius.circular(
          20,
        ),

        border: Border.all(
          color:
              const Color(0xFFEAE6F7),
        ),

        boxShadow: [
          BoxShadow(
            color:
                primary.withValues(
              alpha: 0.045,
            ),
            blurRadius: 15,
            offset:
                const Offset(0, 5),
          ),
        ],
      ),

      child: child,
    );
  }

  // ==========================================================
  // MESSAGE
  // ==========================================================

  void _showMessage(
    String message,
  ) {
    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(
      context,
    )
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content:
              Text(message),
          behavior:
              SnackBarBehavior.floating,
          margin:
              const EdgeInsets.all(16),
          backgroundColor:
              const Color(0xFF2D2942),
          shape:
              RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(
              14,
            ),
          ),
        ),
      );
  }
}

// ============================================================
// TREND POINT
// ============================================================

class _TrendPoint {
  final DateTime date;
  final double value;

  const _TrendPoint({
    required this.date,
    required this.value,
  });
}

// ============================================================
// PRODUCTIVITY CHART
// ============================================================

class _ProductivityChartPainter
    extends CustomPainter {
  final List<_TrendPoint> points;
  final Color primary;

  const _ProductivityChartPainter({
    required this.points,
    required this.primary,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    if (points.isEmpty) {
      return;
    }

    final gridPaint =
        Paint()
          ..color =
              const Color(
            0xFFEDE9F7,
          )
          ..strokeWidth = 1;

    for (int i = 0;
        i < 4;
        i++) {
      final y =
          size.height *
              i /
              3;

      canvas.drawLine(
        Offset(0, y),
        Offset(size.width, y),
        gridPaint,
      );
    }

    final maxValue =
        points.fold<double>(
      0,
      (
        max,
        point,
      ) =>
          point.value > max
              ? point.value
              : max,
    );

    final safeMax =
        maxValue <= 0
            ? 1
            : maxValue;

    final linePaint =
        Paint()
          ..color = primary
          ..strokeWidth = 3
          ..style =
              PaintingStyle.stroke
          ..strokeCap =
              StrokeCap.round
          ..strokeJoin =
              StrokeJoin.round;

    final fillPaint =
        Paint()
          ..color =
              primary.withValues(
            alpha: 0.08,
          )
          ..style =
              PaintingStyle.fill;

    final linePath =
        Path();

    final fillPath =
        Path();

    for (int i = 0;
        i < points.length;
        i++) {
      final x = points.length ==
              1
          ? size.width / 2
          : i *
              size.width /
              (points.length - 1);

      final normalized =
          points[i].value /
              safeMax;

      final y =
          size.height -
              (normalized *
                  (size.height - 20)) -
              10;

      if (i == 0) {
        linePath.moveTo(
          x,
          y,
        );

        fillPath.moveTo(
          x,
          size.height,
        );

        fillPath.lineTo(
          x,
          y,
        );
      } else {
        linePath.lineTo(
          x,
          y,
        );

        fillPath.lineTo(
          x,
          y,
        );
      }

      canvas.drawCircle(
        Offset(x, y),
        4,
        Paint()..color = primary,
      );
    }

    final lastX =
        points.length == 1
            ? size.width / 2
            : size.width;

    fillPath.lineTo(
      lastX,
      size.height,
    );

    fillPath.close();

    canvas.drawPath(
      fillPath,
      fillPaint,
    );

    canvas.drawPath(
      linePath,
      linePaint,
    );
  }

  @override
  bool shouldRepaint(
    covariant _ProductivityChartPainter
        oldDelegate,
  ) {
    return oldDelegate.points !=
            points ||
        oldDelegate.primary !=
            primary;
  }
}