import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/app_usage_model.dart';
import '../services/usage_service.dart';
import '../widgets/app_usage_card.dart';

class DistractionScreen extends StatefulWidget {
  const DistractionScreen({super.key});

  @override
  State<DistractionScreen> createState() =>
      _DistractionScreenState();
}

class _DistractionScreenState
    extends State<DistractionScreen>
    with WidgetsBindingObserver {
  final UsageService _usageService =
      UsageService.instance;

  bool _isLoading = true;
  bool _hasPermission = false;

  List<AppUsageModel> _apps = [];

  int _totalScreenTime = 0;
  int _socialMediaTime = 0;
  int _totalLaunches = 0;

  int _riskScore = 0;

  String _riskLevel = 'Low';

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addObserver(this);

    _loadData();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(
    AppLifecycleState state,
  ) {
    if (state == AppLifecycleState.resumed) {
      _loadData();
    }
  }

  // ==========================================================
  // LOAD REAL DATA
  // ==========================================================

  Future<void> _loadData() async {
    if (mounted) {
      setState(() {
        _isLoading = true;
      });
    }

    try {
      final permission =
          await _usageService.hasUsageAccess();

      if (!permission) {
        if (!mounted) return;

        setState(() {
          _hasPermission = false;
          _isLoading = false;
          _apps = [];
          _totalScreenTime = 0;
          _socialMediaTime = 0;
          _totalLaunches = 0;
          _riskScore = 0;
          _riskLevel = 'Low';
        });

        return;
      }

      final rawData =
          await _usageService.getUsageStats(
        days: 1,
      );

      final apps = rawData
          .map(
            (item) =>
                AppUsageModel.fromMap(item),
          )
          .where(
            (app) =>
                app.totalTimeInForeground > 0,
          )
          .toList();

      apps.sort(
        (a, b) =>
            b.totalTimeInForeground.compareTo(
          a.totalTimeInForeground,
        ),
      );

      int total = 0;
      int social = 0;
      int launches = 0;

      for (final app in apps) {
        total +=
            app.totalTimeInForeground;

        launches += app.launchCount;

        final category =
            _usageService.getAppCategory(
          app.packageName,
          app.appName,
        );

        if (category ==
            'Social Media') {
          social +=
              app.totalTimeInForeground;
        }
      }

      final score =
          _calculateRiskScore(
        totalScreenTime: total,
        socialMediaTime: social,
        totalLaunches: launches,
      );

      if (!mounted) return;

      setState(() {
        _hasPermission = true;
        _isLoading = false;
        _apps = apps;
        _totalScreenTime = total;
        _socialMediaTime = social;
        _totalLaunches = launches;
        _riskScore = score;
        _riskLevel =
            _getRiskLevel(score);
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _isLoading = false;
      });

      _showMessage(
        'Unable to load distraction data.',
      );
    }
  }

  // ==========================================================
  // RISK CALCULATION
  // ==========================================================

  int _calculateRiskScore({
    required int totalScreenTime,
    required int socialMediaTime,
    required int totalLaunches,
  }) {
    int score = 0;

    final hours =
        totalScreenTime /
            const Duration(
              hours: 1,
            ).inMilliseconds;

    final socialHours =
        socialMediaTime /
            const Duration(
              hours: 1,
            ).inMilliseconds;

    // Screen time contribution.
    if (hours >= 6) {
      score += 35;
    } else if (hours >= 4) {
      score += 25;
    } else if (hours >= 2) {
      score += 15;
    } else if (hours >= 1) {
      score += 8;
    }

    // Social media contribution.
    if (socialHours >= 3) {
      score += 30;
    } else if (socialHours >= 2) {
      score += 24;
    } else if (socialHours >= 1) {
      score += 15;
    } else if (socialHours > 0) {
      score += 7;
    }

    // App switching / launch contribution.
    if (totalLaunches >= 80) {
      score += 30;
    } else if (totalLaunches >= 50) {
      score += 23;
    } else if (totalLaunches >= 30) {
      score += 15;
    } else if (totalLaunches >= 15) {
      score += 8;
    }

    return score.clamp(0, 100);
  }

  String _getRiskLevel(
    int score,
  ) {
    if (score >= 70) {
      return 'High';
    }

    if (score >= 40) {
      return 'Medium';
    }

    return 'Low';
  }

  // ==========================================================
  // RISK COLORS
  // ==========================================================

  Color get _riskColor {
    switch (_riskLevel) {
      case 'High':
        return const Color(0xFFE35D6A);

      case 'Medium':
        return const Color(0xFFE5A43D);

      default:
        return const Color(0xFF43A97D);
    }
  }

  // ==========================================================
  // SCREEN TIME TEXT
  // ==========================================================

  String _formatDuration(
    int milliseconds,
  ) {
    return _usageService.formatDuration(
      milliseconds,
    );
  }

  // ==========================================================
  // SOCIAL PERCENTAGE
  // ==========================================================

  int get _socialPercentage {
    if (_totalScreenTime <= 0) {
      return 0;
    }

    return ((_socialMediaTime /
                _totalScreenTime) *
            100)
        .round();
  }

  // ==========================================================
  // SWITCHING LEVEL
  // ==========================================================

  String get _switchingLevel {
    if (_totalLaunches >= 50) {
      return 'High';
    }

    if (_totalLaunches >= 25) {
      return 'Medium';
    }

    return 'Low';
  }

  Color get _switchingColor {
    switch (_switchingLevel) {
      case 'High':
        return const Color(0xFFE35D6A);

      case 'Medium':
        return const Color(0xFFE5A43D);

      default:
        return const Color(0xFF43A97D);
    }
  }

  // ==========================================================
  // LATE NIGHT
  // ==========================================================

  String get _lateNightLevel {
    final now = DateTime.now();

    final nightHour =
        now.hour >= 22 ||
            now.hour < 6;

    if (nightHour &&
        _totalScreenTime >
            const Duration(
              minutes: 30,
            ).inMilliseconds) {
      return 'Medium';
    }

    return 'Low';
  }

  Color get _lateNightColor {
    switch (_lateNightLevel) {
      case 'High':
        return const Color(0xFFE35D6A);

      case 'Medium':
        return const Color(0xFFE5A43D);

      default:
        return const Color(0xFF43A97D);
    }
  }

  // ==========================================================
  // OPEN SETTINGS
  // ==========================================================

  Future<void> _openUsageSettings() async {
    final success =
        await _usageService
            .openUsageAccessSettings();

    if (!success && mounted) {
      _showMessage(
        'Unable to open Usage Access settings.',
      );
    }
  }

  // ==========================================================
  // MESSAGE
  // ==========================================================

  void _showMessage(
    String message,
  ) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content:
              Text(message),
          behavior:
              SnackBarBehavior.floating,
          margin:
              const EdgeInsets.all(16),
          backgroundColor:
              const Color(0xFF2D2942),
          shape:
              RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(
              14,
            ),
          ),
        ),
      );
  }

  // ==========================================================
  // BUILD
  // ==========================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      backgroundColor:
          const Color(0xFFF7F5FF),

      appBar: AppBar(
        backgroundColor:
            const Color(0xFFF7F5FF),
        elevation: 0,
        scrolledUnderElevation: 0,

        leading: IconButton(
          onPressed: () {
            Navigator.maybePop(
              context,
            );
          },
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            size: 19,
          ),
          color:
              const Color(0xFF302B42),
        ),

        title: const Text(
          'Distraction Detection',
          style: TextStyle(
            fontSize: 20,
            fontWeight:
                FontWeight.w800,
            color:
                Color(0xFF252238),
          ),
        ),

        actions: [
          IconButton(
            onPressed:
                _isLoading
                    ? null
                    : _loadData,
            icon: const Icon(
              Icons.refresh_rounded,
            ),
            color:
                const Color(0xFF7357D9),
          ),
        ],
      ),

      body: _isLoading
          ? const Center(
              child:
                  CircularProgressIndicator(
                color:
                    Color(0xFF7357D9),
              ),
            )
          : RefreshIndicator(
              color:
                  const Color(0xFF7357D9),

              onRefresh:
                  _loadData,

              child: ListView(
                physics:
                    const AlwaysScrollableScrollPhysics(),

                padding:
                    const EdgeInsets.fromLTRB(
                  20,
                  8,
                  20,
                  35,
                ),

                children: [
                  if (!_hasPermission)
                    _buildPermissionCard()
                  else ...[
                    _buildRiskCard(),

                    const SizedBox(
                      height: 20,
                    ),

                    _buildRiskFactors(),

                    const SizedBox(
                      height: 20,
                    ),

                    _buildUsageSummary(),

                    const SizedBox(
                      height: 20,
                    ),

                    _buildTopDistractingApps(),

                    const SizedBox(
                      height: 20,
                    ),

                    _buildFocusTip(),
                  ],
                ],
              ),
            ),
    );
  }

  // ==========================================================
  // RISK CARD
  // ==========================================================

  Widget _buildRiskCard() {
    return Container(
      padding:
          const EdgeInsets.fromLTRB(
        20,
        22,
        20,
        22,
      ),

      decoration:
          BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(28),

        border: Border.all(
          color:
              const Color(0xFFEAE6F7),
        ),

        boxShadow: [
          BoxShadow(
            color:
                const Color(0xFF7357D9)
                    .withValues(
              alpha: 0.07,
            ),
            blurRadius: 20,
            offset:
                const Offset(0, 7),
          ),
        ],
      ),

      child: Column(
        children: [
          const Text(
            'Your Distraction Risk',
            style: TextStyle(
              fontSize: 17,
              fontWeight:
                  FontWeight.w800,
              color:
                  Color(0xFF252238),
            ),
          ),

          const SizedBox(
            height: 22,
          ),

          SizedBox(
            width: 190,
            height: 190,

            child: CustomPaint(
              painter:
                  _RiskGaugePainter(
                progress:
                    _riskScore / 100,
                color:
                    _riskColor,
                background:
                    const Color(
                  0xFFF0ECF8,
                ),
              ),

              child: Center(
                child: Column(
                  mainAxisAlignment:
                      MainAxisAlignment.center,

                  children: [
                    Text(
                      _riskLevel,
                      style:
                          TextStyle(
                        fontSize: 25,
                        fontWeight:
                            FontWeight.w900,
                        color:
                            _riskColor,
                      ),
                    ),

                    const SizedBox(
                      height: 2,
                    ),

                    const Text(
                      'Risk Level',
                      style:
                          TextStyle(
                        fontSize: 12,
                        fontWeight:
                            FontWeight.w600,
                        color:
                            Color(0xFF858090),
                      ),
                    ),

                    const SizedBox(
                      height: 7,
                    ),

                    Text(
                      '$_riskScore/100',
                      style:
                          const TextStyle(
                        fontSize: 11,
                        fontWeight:
                            FontWeight.w800,
                        color:
                            Color(0xFFAAA4B8),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),

          const SizedBox(
            height: 15,
          ),

          Text(
            _riskDescription,
            textAlign:
                TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              height: 1.5,
              color:
                  Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  String get _riskDescription {
    switch (_riskLevel) {
      case 'High':
        return 'Your usage shows a higher distraction pattern. Try reducing non-productive app usage and take regular breaks.';

      case 'Medium':
        return 'You’re at medium risk of distraction. Try to reduce non-productive app usage.';

      default:
        return 'Your current usage shows a lower distraction pattern. Keep building healthy digital habits.';
    }
  }

  // ==========================================================
  // RISK FACTORS
  // ==========================================================

  Widget _buildRiskFactors() {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,

      children: [
        const Text(
          'Risk Factors',
          style: TextStyle(
            fontSize: 19,
            fontWeight:
                FontWeight.w800,
            color:
                Color(0xFF252238),
          ),
        ),

        const SizedBox(
          height: 12,
        ),

        _buildRiskFactorCard(
          icon:
              Icons.people_alt_rounded,
          title:
              'Social Media Usage',
          value:
              _socialPercentage >= 30
                  ? 'High'
                  : _socialPercentage >= 15
                      ? 'Medium'
                      : 'Low',
          color:
              _socialPercentage >= 30
                  ? const Color(
                      0xFFE35D6A,
                    )
                  : _socialPercentage >= 15
                      ? const Color(
                          0xFFE5A43D,
                        )
                      : const Color(
                          0xFF43A97D,
                        ),
          subtitle:
              '$_socialPercentage% of today\'s screen time',
        ),

        const SizedBox(
          height: 10,
        ),

        _buildRiskFactorCard(
          icon:
              Icons.swap_horiz_rounded,
          title:
              'Frequent App Switching',
          value:
              _switchingLevel,
          color:
              _switchingColor,
          subtitle:
              '$_totalLaunches app opens today',
        ),

        const SizedBox(
          height: 10,
        ),

        _buildRiskFactorCard(
          icon:
              Icons.nightlight_round,
          title:
              'Late Night Usage',
          value:
              _lateNightLevel,
          color:
              _lateNightColor,
          subtitle:
              'Based on current usage time',
        ),
      ],
    );
  }

  Widget _buildRiskFactorCard({
    required IconData icon,
    required String title,
    required String value,
    required Color color,
    required String subtitle,
  }) {
    return Container(
      padding:
          const EdgeInsets.all(14),

      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(18),
        border: Border.all(
          color:
              const Color(0xFFEAE6F7),
        ),
      ),

      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,

            decoration:
                BoxDecoration(
              color:
                  color.withValues(
                alpha: 0.11,
              ),
              borderRadius:
                  BorderRadius.circular(
                13,
              ),
            ),

            child: Icon(
              icon,
              color: color,
              size: 22,
            ),
          ),

          const SizedBox(
            width: 12,
          ),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [
                Text(
                  title,
                  style:
                      const TextStyle(
                    fontSize: 13,
                    fontWeight:
                        FontWeight.w800,
                    color:
                        Color(0xFF403B52),
                  ),
                ),

                const SizedBox(
                  height: 3,
                ),

                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 10,
                    color:
                        Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),

          Container(
            padding:
                const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 6,
            ),

            decoration:
                BoxDecoration(
              color:
                  color.withValues(
                alpha: 0.10,
              ),
              borderRadius:
                  BorderRadius.circular(
                10,
              ),
            ),

            child: Text(
              value,
              style: TextStyle(
                fontSize: 11,
                fontWeight:
                    FontWeight.w900,
                color: color,
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // USAGE SUMMARY
  // ==========================================================

  Widget _buildUsageSummary() {
    return Container(
      padding:
          const EdgeInsets.all(18),

      decoration:
          BoxDecoration(
        color:
            const Color(0xFFF0ECFF),
        borderRadius:
            BorderRadius.circular(22),
      ),

      child: Row(
        children: [
          Expanded(
            child:
                _summaryItem(
              icon:
                  Icons.access_time_rounded,
              title:
                  'Screen Time',
              value:
                  _formatDuration(
                _totalScreenTime,
              ),
            ),
          ),

          Container(
            width: 1,
            height: 45,
            color:
                const Color(0xFFDCD5F5),
          ),

          Expanded(
            child:
                _summaryItem(
              icon:
                  Icons.apps_rounded,
              title:
                  'Apps Used',
              value:
                  '${_apps.length}',
            ),
          ),

          Container(
            width: 1,
            height: 45,
            color:
                const Color(0xFFDCD5F5),
          ),

          Expanded(
            child:
                _summaryItem(
              icon:
                  Icons.touch_app_rounded,
              title:
                  'App Opens',
              value:
                  '$_totalLaunches',
            ),
          ),
        ],
      ),
    );
  }

  Widget _summaryItem({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Column(
      children: [
        Icon(
          icon,
          color:
              const Color(0xFF7357D9),
          size: 19,
        ),

        const SizedBox(
          height: 5,
        ),

        Text(
          value,
          maxLines: 1,
          overflow:
              TextOverflow.ellipsis,
          style:
              const TextStyle(
            fontSize: 13,
            fontWeight:
                FontWeight.w900,
            color:
                Color(0xFF403B52),
          ),
        ),

        const SizedBox(
          height: 2,
        ),

        Text(
          title,
          style:
              const TextStyle(
            fontSize: 9,
            color:
                Color(0xFF817B8D),
          ),
        ),
      ],
    );
  }

  // ==========================================================
  // TOP DISTRACTING APPS
  // ==========================================================

  Widget _buildTopDistractingApps() {
    final distractingApps =
        _apps
            .where((app) {
          final category =
              _usageService
                  .getAppCategory(
            app.packageName,
            app.appName,
          );

          return category ==
                  'Social Media' ||
              category ==
                  'Entertainment';
        })
            .take(3)
            .toList();

    if (distractingApps.isEmpty) {
      return const SizedBox.shrink();
    }

    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,

      children: [
        const Text(
          'Top Distracting Apps',
          style: TextStyle(
            fontSize: 19,
            fontWeight:
                FontWeight.w800,
            color:
                Color(0xFF252238),
          ),
        ),

        const SizedBox(
          height: 12,
        ),

        ...distractingApps.map(
          (app) {
            return AppUsageCard(
              app: app,
            );
          },
        ),
      ],
    );
  }

  // ==========================================================
  // FOCUS TIP
  // ==========================================================

  Widget _buildFocusTip() {
    return Container(
      padding:
          const EdgeInsets.all(18),

      decoration:
          BoxDecoration(
        gradient:
            const LinearGradient(
          colors: [
            Color(0xFF7357D9),
            Color(0xFF917BE6),
          ],
        ),

        borderRadius:
            BorderRadius.circular(22),

        boxShadow: [
          BoxShadow(
            color:
                const Color(0xFF7357D9)
                    .withValues(
              alpha: 0.15,
            ),
            blurRadius: 15,
            offset:
                const Offset(0, 6),
          ),
        ],
      ),

      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          Container(
            width: 44,
            height: 44,

            decoration:
                BoxDecoration(
              color:
                  Colors.white.withValues(
                alpha: 0.16,
              ),
              shape: BoxShape.circle,
            ),

            child: const Icon(
              Icons.auto_awesome_rounded,
              color: Colors.white,
              size: 22,
            ),
          ),

          const SizedBox(
            width: 12,
          ),

          const Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [
                Text(
                  'Stay Focused!',
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight:
                        FontWeight.w900,
                    color:
                        Colors.white,
                  ),
                ),

                SizedBox(
                  height: 5,
                ),

                Text(
                  'Take short breaks, keep your phone away, and focus on what matters.',
                  style: TextStyle(
                    fontSize: 11,
                    height: 1.45,
                    color:
                        Colors.white70,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // PERMISSION CARD
  // ==========================================================

  Widget _buildPermissionCard() {
    return Container(
      padding:
          const EdgeInsets.all(24),

      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(26),
        border: Border.all(
          color:
              const Color(0xFFEAE6F7),
        ),
      ),

      child: Column(
        children: [
          Container(
            width: 76,
            height: 76,

            decoration:
                const BoxDecoration(
              color:
                  Color(0xFFF0ECFF),
              shape: BoxShape.circle,
            ),

            child: const Icon(
              Icons.shield_rounded,
              color:
                  Color(0xFF7357D9),
              size: 38,
            ),
          ),

          const SizedBox(
            height: 18,
          ),

          const Text(
            'Usage Access Required',
            textAlign:
                TextAlign.center,
            style:
                TextStyle(
              fontSize: 20,
              fontWeight:
                  FontWeight.w800,
              color:
                  Color(0xFF252238),
            ),
          ),

          const SizedBox(
            height: 8,
          ),

          Text(
            'MindfulAI needs usage access to calculate your distraction risk from actual device usage.',
            textAlign:
                TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              height: 1.5,
              color:
                  Colors.grey.shade600,
            ),
          ),

          const SizedBox(
            height: 20,
          ),

          SizedBox(
            width: double.infinity,
            height: 50,

            child:
                ElevatedButton.icon(
              onPressed:
                  _openUsageSettings,

              icon: const Icon(
                Icons.settings_rounded,
                size: 19,
              ),

              label: const Text(
                'Open Usage Access',
              ),

              style:
                  ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(
                  0xFF7357D9,
                ),
                foregroundColor:
                    Colors.white,
                elevation: 0,
                shape:
                    RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(
                    15,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// RISK GAUGE PAINTER
// ============================================================

class _RiskGaugePainter
    extends CustomPainter {
  final double progress;
  final Color color;
  final Color background;

  const _RiskGaugePainter({
    required this.progress,
    required this.color,
    required this.background,
  });

  @override
  void paint(
    Canvas canvas,
    Size size,
  ) {
    final center =
        Offset(
      size.width / 2,
      size.height / 2,
    );

    final radius =
        math.min(
              size.width,
              size.height,
            ) /
            2 -
        13;

    const strokeWidth = 15.0;

    final backgroundPaint =
        Paint()
          ..color = background
          ..style =
              PaintingStyle.stroke
          ..strokeWidth =
              strokeWidth
          ..strokeCap =
              StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(
        center: center,
        radius: radius,
      ),
      math.pi * 0.75,
      math.pi * 1.5,
      false,
      backgroundPaint,
    );

    final progressPaint =
        Paint()
          ..color = color
          ..style =
              PaintingStyle.stroke
          ..strokeWidth =
              strokeWidth
          ..strokeCap =
              StrokeCap.round;

    canvas.drawArc(
      Rect.fromCircle(
        center: center,
        radius: radius,
      ),
      math.pi * 0.75,
      math.pi *
          1.5 *
          progress.clamp(
            0.0,
            1.0,
          ),
      false,
      progressPaint,
    );
  }

  @override
  bool shouldRepaint(
    covariant _RiskGaugePainter oldDelegate,
  ) {
    return oldDelegate.progress !=
            progress ||
        oldDelegate.color != color ||
        oldDelegate.background !=
            background;
  }
}