import 'package:flutter/material.dart';

import '../models/app_usage_model.dart';

class AppUsageDetailsScreen extends StatelessWidget {
  final AppUsageModel app;

  const AppUsageDetailsScreen({
    super.key,
    required this.app,
  });

  static const Color primary =
      Color(0xFF7357D9);

  static const Color background =
      Color(0xFFF7F5FF);

  static const Color textColor =
      Color(0xFF252238);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,

      appBar: AppBar(
        backgroundColor: background,
        elevation: 0,

        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_rounded,
            color: textColor,
          ),
          onPressed: () {
            Navigator.pop(context);
          },
        ),

        title: const Text(
          'App Usage Details',
          style: TextStyle(
            color: textColor,
            fontSize: 18,
            fontWeight: FontWeight.w800,
          ),
        ),

        centerTitle: false,
      ),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(
            18,
            8,
            18,
            28,
          ),

          child: Column(
            crossAxisAlignment:
                CrossAxisAlignment.start,

            children: [
              _buildAppHeader(),

              const SizedBox(height: 16),

              _buildUsageOverview(),

              const SizedBox(height: 16),

              _buildDetailsCard(),

              const SizedBox(height: 16),

              _buildInfoCard(),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // APP HEADER
  // ============================================================

  Widget _buildAppHeader() {
    return Container(
      width: double.infinity,

      padding: const EdgeInsets.all(20),

      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF7357D9),
            Color(0xFF9A88F2),
          ],

          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),

        borderRadius:
            BorderRadius.circular(24),

        boxShadow: [
          BoxShadow(
            color:
                primary.withValues(alpha: 0.15),
            blurRadius: 18,
            offset:
                const Offset(0, 8),
          ),
        ],
      ),

      child: Row(
        children: [
          _buildIcon(
            size: 68,
            background:
                Colors.white,
          ),

          const SizedBox(width: 16),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [
                Text(
                  app.appName,
                  maxLines: 2,
                  overflow:
                      TextOverflow.ellipsis,

                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 21,
                    fontWeight:
                        FontWeight.w900,
                  ),
                ),

                const SizedBox(height: 6),

                Text(
                  app.packageName.isEmpty
                      ? 'Installed application'
                      : app.packageName,

                  maxLines: 2,
                  overflow:
                      TextOverflow.ellipsis,

                  style: const TextStyle(
                    color: Colors.white70,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // USAGE OVERVIEW
  // ============================================================

  Widget _buildUsageOverview() {
    return Row(
      children: [
        Expanded(
          child: _statCard(
            icon:
                Icons.access_time_rounded,
            title: 'Screen Time',
            value:
                app.formattedDuration,
          ),
        ),

        const SizedBox(width: 10),

        Expanded(
          child: _statCard(
            icon:
                Icons.open_in_new_rounded,
            title: 'App Opens',
            value:
                '${app.launchCount}',
          ),
        ),
      ],
    );
  }

  Widget _statCard({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Container(
      padding:
          const EdgeInsets.all(15),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(18),

        border: Border.all(
          color:
              const Color(0xFFE8E3F6),
        ),

        boxShadow: [
          BoxShadow(
            color:
                primary.withValues(
              alpha: 0.04,
            ),
            blurRadius: 12,
            offset:
                const Offset(0, 5),
          ),
        ],
      ),

      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          Container(
            width: 38,
            height: 38,

            decoration:
                const BoxDecoration(
              color:
                  Color(0xFFECE8FF),
              shape:
                  BoxShape.circle,
            ),

            child: Icon(
              icon,
              color: primary,
              size: 20,
            ),
          ),

          const SizedBox(height: 9),

          Text(
            title,
            style: const TextStyle(
              fontSize: 10,
              color:
                  Color(0xFF777286),
              fontWeight:
                  FontWeight.w600,
            ),
          ),

          const SizedBox(height: 3),

          Text(
            value,
            style: const TextStyle(
              fontSize: 18,
              color: textColor,
              fontWeight:
                  FontWeight.w900,
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // DETAILS
  // ============================================================

  Widget _buildDetailsCard() {
    return Container(
      width: double.infinity,

      padding:
          const EdgeInsets.all(18),

      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(20),

        border: Border.all(
          color:
              const Color(0xFFE8E3F6),
        ),
      ),

      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          const Text(
            'Usage Details',
            style: TextStyle(
              fontSize: 16,
              fontWeight:
                  FontWeight.w900,
              color: textColor,
            ),
          ),

          const SizedBox(height: 14),

          _detailRow(
            icon:
                Icons.timer_outlined,
            title: 'Total Time Used',
            value:
                app.formattedDuration,
          ),

          _divider(),

          _detailRow(
            icon:
                Icons.touch_app_outlined,
            title: 'Times Opened',
            value:
                '${app.launchCount}',
          ),

          _divider(),

          _detailRow(
            icon:
                Icons.schedule_rounded,
            title: 'Last Used',
            value:
                app.formattedLastUsed,
          ),
        ],
      ),
    );
  }

  Widget _detailRow({
    required IconData icon,
    required String title,
    required String value,
  }) {
    return Row(
      children: [
        Container(
          width: 38,
          height: 38,

          decoration:
              const BoxDecoration(
            color:
                Color(0xFFF2EFFF),
            shape:
                BoxShape.circle,
          ),

          child: Icon(
            icon,
            color: primary,
            size: 19,
          ),
        ),

        const SizedBox(width: 11),

        Expanded(
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 12,
              color:
                  Color(0xFF696477),
              fontWeight:
                  FontWeight.w600,
            ),
          ),
        ),

        Text(
          value,
          style: const TextStyle(
            fontSize: 13,
            color: textColor,
            fontWeight:
                FontWeight.w800,
          ),
        ),
      ],
    );
  }

  Widget _divider() {
    return const Padding(
      padding:
          EdgeInsets.symmetric(
        vertical: 13,
      ),

      child: Divider(
        height: 1,
        color:
            Color(0xFFF0EDF6),
      ),
    );
  }

  // ============================================================
  // APP INFORMATION
  // ============================================================

  Widget _buildInfoCard() {
    return Container(
      width: double.infinity,

      padding:
          const EdgeInsets.all(17),

      decoration: BoxDecoration(
        color:
            const Color(0xFFECE8FF),

        borderRadius:
            BorderRadius.circular(19),
      ),

      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          Container(
            width: 40,
            height: 40,

            decoration:
                const BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),

            child: const Icon(
              Icons.info_outline_rounded,
              color: primary,
              size: 21,
            ),
          ),

          const SizedBox(width: 11),

          const Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [
                Text(
                  'About this data',
                  style: TextStyle(
                    color: textColor,
                    fontSize: 13,
                    fontWeight:
                        FontWeight.w900,
                  ),
                ),

                SizedBox(height: 4),

                Text(
                  'Usage information is collected from Android Usage Access and represents the actual usage recorded on your device.',
                  style: TextStyle(
                    color:
                        Color(0xFF615B74),
                    fontSize: 10.5,
                    height: 1.45,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // REAL APP ICON
  // ============================================================

  Widget _buildIcon({
    required double size,
    required Color background,
  }) {
    final bytes = app.iconBytes;

    if (bytes != null &&
        bytes.isNotEmpty) {
      return Container(
        width: size,
        height: size,

        padding: const EdgeInsets.all(7),

        decoration: BoxDecoration(
          color: background,
          borderRadius:
              BorderRadius.circular(18),
        ),

        clipBehavior:
            Clip.antiAlias,

        child: Image.memory(
          bytes,
          width: size,
          height: size,
          fit: BoxFit.contain,

          gaplessPlayback: true,

          errorBuilder:
              (
                context,
                error,
                stackTrace,
              ) {
            return _fallbackIcon(
              size,
            );
          },
        ),
      );
    }

    return Container(
      width: size,
      height: size,

      decoration: BoxDecoration(
        color: background,
        borderRadius:
            BorderRadius.circular(18),
      ),

      child: _fallbackIcon(
        size,
      ),
    );
  }

  Widget _fallbackIcon(
    double size,
  ) {
    return Center(
      child: Icon(
        Icons.apps_rounded,
        color: primary,
        size: size * 0.42,
      ),
    );
  }
}