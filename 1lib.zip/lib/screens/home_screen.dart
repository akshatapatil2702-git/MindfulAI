import 'dart:convert';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/app_usage_model.dart';
import '../services/ml_service.dart';
import '../services/usage_service.dart';
import 'distraction_screen.dart';
import 'focus_mode_screen.dart';
import 'profile_screen.dart';
import 'reports_screen.dart';
import 'usage_access_screen.dart';
import 'usage_stats_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen>
    with SingleTickerProviderStateMixin {
  static const primary = Color(0xFF7357D9);
  static const background = Color(0xFFF7F5FF);

  static const String focusHistoryKey = 'focus_session_history';

  late final AnimationController _animationController;
  late final Animation<double> _fadeAnimation;
  late final Animation<Offset> _slideAnimation;

  final UsageService _usageService = UsageService.instance;
  final MLService _mlService = MLService.instance;

  int _currentIndex = 0;

  bool _isLoading = true;
  bool _hasUsageAccess = false;

  int _screenTime = 0;
  int _appsUsed = 0;
  int _launches = 0;

  int _productivity = 0;
  int _focusMinutes = 0;

  double _distractionScore = 0;
  String _distractionLevel = 'Low';

  final List<Widget> _pages = const [
    SizedBox.shrink(),
    UsageStatsScreen(),
    FocusModeScreen(),
    ReportsScreen(),
    ProfileScreen(),
  ];

  @override
  void initState() {
    super.initState();

    _animationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );

    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.025),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOutCubic,
      ),
    );

    _animationController.forward();

    _loadHomeData();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  Future<void> _loadHomeData() async {
    try {
      final hasAccess = await _usageService.hasUsageAccess();

      final focusMinutes = await _loadTodayFocusMinutes();

      if (!hasAccess) {
        if (!mounted) return;

        setState(() {
          _hasUsageAccess = false;
          _isLoading = false;
          _focusMinutes = focusMinutes;
        });

        return;
      }

      final rawUsage = await _usageService.getTodayUsage();

      final apps = rawUsage
          .map(
            (item) => AppUsageModel.fromMap(item),
          )
          .where(
            (app) => app.totalTimeInForeground > 0,
          )
          .toList();

      apps.sort(
        (a, b) => b.totalTimeInForeground.compareTo(
          a.totalTimeInForeground,
        ),
      );

      var totalTime = 0;
      var launches = 0;

      for (final app in apps) {
        totalTime += app.totalTimeInForeground;
        launches += app.launchCount;
      }

      final distractingTime = _calculateDistractingTime(apps);

      final productiveTime = (totalTime - distractingTime)
          .clamp(0, totalTime)
          .toInt();

      final productivity = _mlService.calculateProductivityScore(
        totalScreenTime: totalTime,
        productiveTime: productiveTime,
        distractingTime: distractingTime,
      );

      final socialTime = _calculateCategoryTime(
        apps,
        const [
          'instagram',
          'facebook',
          'messenger',
          'whatsapp',
          'snapchat',
          'telegram',
          'twitter',
          'reddit',
          'threads',
          'social',
        ],
      );

      final entertainmentTime = _calculateCategoryTime(
        apps,
        const [
          'youtube',
          'netflix',
          'spotify',
          'hotstar',
          'prime video',
          'jio cinema',
          'twitch',
          'game',
          'gaming',
          'movie',
        ],
      );

      final result = _mlService.analyzeUsage(
        totalScreenTime: totalTime,
        socialMediaTime: socialTime,
        entertainmentTime: entertainmentTime,
        appLaunches: launches,
      );

      final score =
          (result['distractionScore'] as num?)?.toDouble() ?? 0;

      final level = result['level']?.toString() ?? 'Low';

      if (!mounted) return;

      setState(() {
        _hasUsageAccess = true;
        _isLoading = false;

        _screenTime = totalTime;
        _appsUsed = apps.length;
        _launches = launches;

        _productivity = productivity.clamp(0, 100);

        _focusMinutes = focusMinutes;

        _distractionScore = score;
        _distractionLevel = level;
      });
    } catch (_) {
      final focusMinutes = await _loadTodayFocusMinutes();

      if (!mounted) return;

      setState(() {
        _isLoading = false;
        _focusMinutes = focusMinutes;
      });
    }
  }

  Future<int> _loadTodayFocusMinutes() async {
    try {
      final prefs = await SharedPreferences.getInstance();

      final sessions = prefs.getStringList(
            focusHistoryKey,
          ) ??
          [];

      final now = DateTime.now();

      var minutes = 0;

      for (final item in sessions) {
        try {
          final decoded = jsonDecode(item);

          if (decoded is! Map) {
            continue;
          }

          final session = Map<String, dynamic>.from(decoded);

          final completedAt = DateTime.tryParse(
            session['completedAt']?.toString() ?? '',
          );

          if (completedAt == null) {
            continue;
          }

          final today = completedAt.year == now.year &&
              completedAt.month == now.month &&
              completedAt.day == now.day;

          if (!today) {
            continue;
          }

          minutes +=
              int.tryParse(
                    session['duration']?.toString() ?? '0',
                  ) ??
                  0;
        } catch (_) {}
      }

      return minutes;
    } catch (_) {
      return 0;
    }
  }

  int _calculateCategoryTime(
    List<AppUsageModel> apps,
    List<String> keywords,
  ) {
    var total = 0;

    for (final app in apps) {
      final name = app.appName.toLowerCase();
      final package = app.packageName.toLowerCase();

      final matched = keywords.any(
        (keyword) =>
            name.contains(keyword) ||
            package.contains(keyword),
      );

      if (matched) {
        total += app.totalTimeInForeground;
      }
    }

    return total;
  }

  int _calculateDistractingTime(
    List<AppUsageModel> apps,
  ) {
    return _calculateCategoryTime(
      apps,
      const [
        'instagram',
        'facebook',
        'messenger',
        'whatsapp',
        'snapchat',
        'telegram',
        'twitter',
        'reddit',
        'threads',
        'youtube',
        'netflix',
        'spotify',
        'hotstar',
        'prime video',
        'jio cinema',
        'game',
        'gaming',
        'twitch',
      ],
    );
  }

  String _formatDuration(int milliseconds) {
    final duration = Duration(
      milliseconds: milliseconds,
    );

    final hours = duration.inHours;
    final minutes = duration.inMinutes.remainder(60);

    if (hours > 0) {
      return '${hours}h ${minutes}m';
    }

    return '${minutes}m';
  }

  void _changePage(int index) {
    setState(() {
      _currentIndex = index;
    });

    _animationController
      ..reset()
      ..forward();

    if (index == 0) {
      _loadHomeData();
    }
  }

  void _openUsageAccess() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const UsageAccessScreen(),
      ),
    ).then((_) {
      _loadHomeData();
    });
  }

  void _openDistraction() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const DistractionScreen(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: background,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: _currentIndex == 0
                ? _Dashboard(
                    loading: _isLoading,
                    hasAccess: _hasUsageAccess,
                    screenTime: _screenTime,
                    appsUsed: _appsUsed,
                    launches: _launches,
                    productivity: _productivity,
                    focusMinutes: _focusMinutes,
                    distractionLevel: _distractionLevel,
                    distractionScore: _distractionScore,
                    format: _formatDuration,
                    openUsage: () => _changePage(1),
                    openFocus: () => _changePage(2),
                    openReports: () => _changePage(3),
                    openProfile: () => _changePage(4),
                    openAccess: _openUsageAccess,
                    openDistraction: _openDistraction,
                  )
                : _pages[_currentIndex],
          ),
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _currentIndex,
        onDestinationSelected: _changePage,
        backgroundColor: Colors.white,
        indicatorColor: const Color(0xFFE9E4FF),
        elevation: 0,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(
              Icons.home_rounded,
              color: primary,
            ),
            label: 'Home',
          ),
          NavigationDestination(
            icon: Icon(Icons.bar_chart_outlined),
            selectedIcon: Icon(
              Icons.bar_chart_rounded,
              color: primary,
            ),
            label: 'Usage',
          ),
          NavigationDestination(
            icon: Icon(Icons.timer_outlined),
            selectedIcon: Icon(
              Icons.timer_rounded,
              color: primary,
            ),
            label: 'Focus',
          ),
          NavigationDestination(
            icon: Icon(Icons.description_outlined),
            selectedIcon: Icon(
              Icons.description_rounded,
              color: primary,
            ),
            label: 'Reports',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline_rounded),
            selectedIcon: Icon(
              Icons.person_rounded,
              color: primary,
            ),
            label: 'Profile',
          ),
        ],
      ),
    );
  }
}

class _Dashboard extends StatelessWidget {
  static const primary = Color(0xFF7357D9);
  static const text = Color(0xFF252238);

  final bool loading;
  final bool hasAccess;

  final int screenTime;
  final int appsUsed;
  final int launches;

  final int productivity;
  final int focusMinutes;

  final double distractionScore;
  final String distractionLevel;

  final String Function(int) format;

  final VoidCallback openUsage;
  final VoidCallback openFocus;
  final VoidCallback openReports;
  final VoidCallback openProfile;
  final VoidCallback openAccess;
  final VoidCallback openDistraction;

  const _Dashboard({
    required this.loading,
    required this.hasAccess,
    required this.screenTime,
    required this.appsUsed,
    required this.launches,
    required this.productivity,
    required this.focusMinutes,
    required this.distractionLevel,
    required this.distractionScore,
    required this.format,
    required this.openUsage,
    required this.openFocus,
    required this.openReports,
    required this.openProfile,
    required this.openAccess,
    required this.openDistraction,
  });

  String _greeting() {
    final hour = DateTime.now().hour;

    if (hour < 12) {
      return 'Good Morning,';
    }

    if (hour < 17) {
      return 'Good Afternoon,';
    }

    return 'Good Evening,';
  }

  String _riskLabel() {
    if (!hasAccess) {
      return '—';
    }

    if (distractionLevel.toLowerCase() == 'high') {
      return 'High';
    }

    if (distractionLevel.toLowerCase() == 'moderate') {
      return 'Medium';
    }

    return 'Low';
  }

  Color _riskBackground() {
    if (!hasAccess) {
      return const Color(0xFFF2EFF8);
    }

    if (distractionLevel.toLowerCase() == 'high') {
      return const Color(0xFFFFE8E8);
    }

    if (distractionLevel.toLowerCase() == 'moderate') {
      return const Color(0xFFFFF1E7);
    }

    return const Color(0xFFE9F8F2);
  }

  Color _riskTextColor() {
    if (!hasAccess) {
      return const Color(0xFF777286);
    }

    if (distractionLevel.toLowerCase() == 'high') {
      return const Color(0xFFD9534F);
    }

    if (distractionLevel.toLowerCase() == 'moderate') {
      return const Color(0xFFD7832C);
    }

    return const Color(0xFF299A68);
  }

  String _focusText() {
    if (!hasAccess && focusMinutes == 0) {
      return '—';
    }

    if (focusMinutes < 60) {
      return '${focusMinutes}m';
    }

    final hours = focusMinutes ~/ 60;
    final minutes = focusMinutes % 60;

    if (minutes == 0) {
      return '${hours}h';
    }

    return '${hours}h ${minutes}m';
  }

  String _scoreLabel() {
    if (!hasAccess) {
      return 'Connect usage';
    }

    if (productivity >= 70) {
      return 'Good';
    }

    if (productivity >= 45) {
      return 'Moderate';
    }

    return 'Needs focus';
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;

    final userName = user?.displayName?.trim().isNotEmpty == true
        ? user!.displayName!.trim()
        : 'Mindful User';

    return RefreshIndicator(
      color: primary,
      onRefresh: () async {},
      child: ListView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(
          18,
          16,
          18,
          28,
        ),
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${_greeting()} ☀️',
                      style: const TextStyle(
                        fontSize: 13,
                        color: Color(0xFF555064),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      userName,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 25,
                        fontWeight: FontWeight.w900,
                        color: text,
                      ),
                    ),
                    const SizedBox(height: 3),
                    const Text(
                      'Small steps create big changes.',
                      style: TextStyle(
                        fontSize: 11,
                        color: Color(0xFF777286),
                      ),
                    ),
                  ],
                ),
              ),
              GestureDetector(
                onTap: openProfile,
                child: Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: const Color(0xFFECE8FF),
                    borderRadius: BorderRadius.circular(17),
                  ),
                  child: const Center(
                    child: Text(
                      '🧑',
                      style: TextStyle(fontSize: 25),
                    ),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 17),
          _focusScoreCard(),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: _metricCard(
                  icon: Icons.phone_android_rounded,
                  title: 'Screen Time',
                  value: hasAccess ? format(screenTime) : '—',
                  background: const Color(0xFFE9F8F2),
                  iconBackground: const Color(0xFFD8F2E8),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _metricCard(
                  icon: Icons.insights_rounded,
                  title: 'Productivity',
                  value: hasAccess ? '$productivity%' : '—',
                  background: const Color(0xFFECE8FF),
                  iconBackground: const Color(0xFFDDD5FF),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _metricCard(
                  icon: Icons.warning_amber_rounded,
                  title: 'Distraction Risk',
                  value: _riskLabel(),
                  background: _riskBackground(),
                  iconBackground: Colors.white.withValues(alpha: .65),
                  valueColor: _riskTextColor(),
                  onTap: openDistraction,
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: _metricCard(
                  icon: Icons.hourglass_bottom_rounded,
                  title: 'Focus Time',
                  value: _focusText(),
                  background: const Color(0xFFEAF0FF),
                  iconBackground: const Color(0xFFDCE7FF),
                ),
              ),
            ],
          ),
          const SizedBox(height: 19),
          const Text(
            'Quick Actions',
            style: TextStyle(
              fontSize: 17,
              fontWeight: FontWeight.w900,
              color: text,
            ),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              _quickAction(
                icon: Icons.bar_chart_rounded,
                title: 'Usage Access',
                onTap: openAccess,
              ),
              const SizedBox(width: 8),
              _quickAction(
                icon: Icons.timer_rounded,
                title: 'Focus Mode',
                onTap: openFocus,
              ),
              const SizedBox(width: 8),
              _quickAction(
                icon: Icons.insert_chart_rounded,
                title: 'Reports',
                onTap: openReports,
              ),
              const SizedBox(width: 8),
              _quickAction(
                icon: Icons.person_rounded,
                title: 'Profile',
                onTap: openProfile,
              ),
            ],
          ),
          const SizedBox(height: 14),
          _wideActionCard(
            icon: Icons.bar_chart_rounded,
            title: 'Usage Statistics',
            subtitle: hasAccess
                ? 'View your screen-time history and app categories.'
                : 'Connect Usage Access to see real device data.',
            onTap: openUsage,
          ),
          const SizedBox(height: 10),
          _wideActionCard(
            icon: Icons.psychology_rounded,
            title: 'Distraction Detection',
            subtitle: hasAccess
                ? 'Check your AI-powered digital distraction risk.'
                : 'Analyze your digital distraction after granting access.',
            onTap: openDistraction,
          ),
          const SizedBox(height: 12),
          if (!hasAccess) _accessCard(),
          if (!hasAccess) const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFFECE8FF),
              borderRadius: BorderRadius.circular(19),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(
                    Icons.lightbulb_rounded,
                    color: Color(0xFF7357D9),
                    size: 21,
                  ),
                ),
                const SizedBox(width: 11),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Tip',
                        style: TextStyle(
                          fontWeight: FontWeight.w900,
                          color: text,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Take regular breaks and review your digital habits to support better focus.',
                        style: TextStyle(
                          fontSize: 12,
                          height: 1.4,
                          color: Color(0xFF5D5870),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _focusScoreCard() {
    final score = productivity.clamp(0, 100);
    final progress = score / 100;

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color(0xFF7357D9),
            Color(0xFF9B8AFB),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(23),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF7357D9).withValues(alpha: .16),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          SizedBox(
            width: 112,
            height: 112,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 105,
                  height: 105,
                  child: CircularProgressIndicator(
                    value: loading ? null : progress,
                    strokeWidth: 9,
                    backgroundColor: Colors.white24,
                    valueColor:
                        const AlwaysStoppedAnimation<Color>(
                      Colors.white,
                    ),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      hasAccess ? '$score' : '—',
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 25,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    const Text(
                      '/100',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 11,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      _scoreLabel(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Your Focus Score',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 17,
                    fontWeight: FontWeight.w800,
                  ),
                ),
                SizedBox(height: 7),
                Text(
                  'Your score reflects your digital activity and productive screen time today.',
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 11.5,
                    height: 1.45,
                  ),
                ),
                SizedBox(height: 11),
                Row(
                  children: [
                    Icon(
                      Icons.self_improvement_rounded,
                      color: Colors.white,
                      size: 17,
                    ),
                    SizedBox(width: 5),
                    Text(
                      'Stay mindful',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _metricCard({
    required IconData icon,
    required String title,
    required String value,
    required Color background,
    required Color iconBackground,
    Color valueColor = text,
    VoidCallback? onTap,
  }) {
    final child = Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(18),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: iconBackground,
              borderRadius: BorderRadius.circular(11),
            ),
            child: Icon(
              icon,
              size: 19,
              color: primary,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(
              fontSize: 10,
              color: text,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 2),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: TextStyle(
              fontSize: 18,
              color: valueColor,
              fontWeight: FontWeight.w900,
            ),
          ),
        ],
      ),
    );

    if (onTap == null) {
      return child;
    }

    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: child,
      ),
    );
  }

  Widget _quickAction({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
  }) {
    return Expanded(
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(15),
          child: Container(
            padding: const EdgeInsets.symmetric(
              vertical: 11,
              horizontal: 3,
            ),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(15),
              border: Border.all(
                color: const Color(0xFFE8E3F6),
              ),
            ),
            child: Column(
              children: [
                Container(
                  width: 38,
                  height: 38,
                  decoration: const BoxDecoration(
                    color: Color(0xFFF0ECFF),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(
                    icon,
                    size: 19,
                    color: primary,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  title,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 8.5,
                    fontWeight: FontWeight.w700,
                    color: text,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _wideActionCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(18),
        child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(18),
            boxShadow: [
              BoxShadow(
                color: primary.withValues(alpha: .04),
                blurRadius: 14,
                offset: const Offset(0, 5),
              ),
            ],
          ),
          child: Row(
            children: [
              Container(
                width: 46,
                height: 46,
                decoration: const BoxDecoration(
                  color: Color(0xFFECE8FF),
                  shape: BoxShape.circle,
                ),
                child: Icon(
                  icon,
                  color: primary,
                  size: 22,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w800,
                        color: text,
                      ),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      subtitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 10.5,
                        color: Color(0xFF777286),
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.chevron_right_rounded,
                color: Color(0xFFAAA4BD),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _accessCard() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: openAccess,
        borderRadius: BorderRadius.circular(19),
        child: Container(
          padding: const EdgeInsets.all(15),
          decoration: BoxDecoration(
            color: const Color(0xFFFFF5E9),
            borderRadius: BorderRadius.circular(19),
            border: Border.all(
              color: const Color(0xFFFFE3C2),
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 43,
                height: 43,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.security_rounded,
                  color: Color(0xFFD7832C),
                  size: 21,
                ),
              ),
              const SizedBox(width: 11),
              const Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Enable Usage Access',
                      style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF5A4630),
                      ),
                    ),
                    SizedBox(height: 3),
                    Text(
                      'Allow MindfulAI to read your real device usage.',
                      style: TextStyle(
                        fontSize: 10,
                        color: Color(0xFF806D58),
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(
                Icons.chevron_right_rounded,
                color: Color(0xFFD7832C),
              ),
            ],
          ),
        ),
      ),
    );
  }
}