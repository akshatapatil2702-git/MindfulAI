import 'package:flutter/material.dart';

import '../services/notification_service.dart';

class NotificationSettingsScreen extends StatefulWidget {
  const NotificationSettingsScreen({
    super.key,
  });

  @override
  State<NotificationSettingsScreen> createState() =>
      _NotificationSettingsScreenState();
}

class _NotificationSettingsScreenState
    extends State<NotificationSettingsScreen> {
  final NotificationService _notificationService =
      NotificationService.instance;

  bool _notificationsEnabled = true;
  bool _focusReminder = true;
  bool _screenTimeReminder = true;
  bool _distractionAlert = true;
  bool _wellbeingReminder = true;

  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final service = _notificationService;

    final notifications =
        await service.getNotificationsEnabled();

    final focus =
        await service.getFocusReminderEnabled();

    final screenTime =
        await service.getScreenTimeReminderEnabled();

    final distraction =
        await service.getDistractionAlertEnabled();

    final wellbeing =
        await service.getWellbeingReminderEnabled();

    if (!mounted) return;

    setState(() {
      _notificationsEnabled = notifications;
      _focusReminder = focus;
      _screenTimeReminder = screenTime;
      _distractionAlert = distraction;
      _wellbeingReminder = wellbeing;
      _loading = false;
    });
  }

  Future<void> _setNotificationsEnabled(
    bool value,
  ) async {
    setState(() {
      _notificationsEnabled = value;
    });

    await _notificationService
        .setNotificationsEnabled(value);

    if (value) {
      await _notificationService
          .scheduleScreenTimeReminder();
    }
  }

  Future<void> _setFocusReminder(bool value) async {
    setState(() {
      _focusReminder = value;
    });

    await _notificationService
        .setFocusReminderEnabled(value);
  }

  Future<void> _setScreenTimeReminder(
    bool value,
  ) async {
    setState(() {
      _screenTimeReminder = value;
    });

    await _notificationService
        .setScreenTimeReminderEnabled(value);

    if (value && _notificationsEnabled) {
      await _notificationService
          .scheduleScreenTimeReminder();
    }
  }

  Future<void> _setDistractionAlert(
    bool value,
  ) async {
    setState(() {
      _distractionAlert = value;
    });

    await _notificationService
        .setDistractionAlertEnabled(value);
  }

  Future<void> _setWellbeingReminder(
    bool value,
  ) async {
    setState(() {
      _wellbeingReminder = value;
    });

    await _notificationService
        .setWellbeingReminderEnabled(value);
  }

  Widget _settingTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.symmetric(
        horizontal: 18,
        vertical: 16,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF7357D9)
                .withValues(alpha: 0.07),
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: const Color(0xFFEDE9FF),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(
              icon,
              color: const Color(0xFF7357D9),
              size: 23,
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF252238),
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(
                    fontSize: 12.5,
                    height: 1.3,
                    color: Colors.grey.shade600,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            activeThumbColor:
                const Color(0xFF7357D9),
            activeTrackColor:
                const Color(0xFFDCD4FF),
            onChanged: _notificationsEnabled
                ? onChanged
                : null,
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F5FF),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF7F5FF),
        elevation: 0,
        centerTitle: true,
        title: const Text(
          'Notification Settings',
          style: TextStyle(
            fontWeight: FontWeight.w800,
            color: Color(0xFF252238),
          ),
        ),
        iconTheme: const IconThemeData(
          color: Color(0xFF252238),
        ),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(
                color: Color(0xFF7357D9),
              ),
            )
          : ListView(
              padding: const EdgeInsets.fromLTRB(
                20,
                18,
                20,
                30,
              ),
              children: [
                Container(
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [
                        Color(0xFF7357D9),
                        Color(0xFF8E78E8),
                      ],
                    ),
                    borderRadius:
                        BorderRadius.circular(24),
                  ),
                  child: Row(
                    children: [
                      Container(
                        width: 52,
                        height: 52,
                        decoration:
                            BoxDecoration(
                          color: Colors.white
                              .withValues(alpha: 0.18),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.notifications_active_rounded,
                          color: Colors.white,
                          size: 27,
                        ),
                      ),
                      const SizedBox(width: 14),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment:
                              CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Mindful Reminders',
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: 19,
                                fontWeight:
                                    FontWeight.w800,
                              ),
                            ),
                            SizedBox(height: 5),
                            Text(
                              'Stay aware of your digital habits.',
                              style: TextStyle(
                                color: Colors.white70,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 24),

                const Text(
                  'GENERAL',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                    color: Color(0xFF7357D9),
                  ),
                ),

                const SizedBox(height: 10),

                _settingTile(
                  icon: Icons.notifications_rounded,
                  title: 'Notifications',
                  subtitle:
                      'Enable or disable all MindfulAI notifications.',
                  value: _notificationsEnabled,
                  onChanged:
                      _setNotificationsEnabled,
                ),

                const SizedBox(height: 8),

                const Text(
                  'REMINDERS & ALERTS',
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1,
                    color: Color(0xFF7357D9),
                  ),
                ),

                const SizedBox(height: 10),

                _settingTile(
                  icon: Icons.timer_rounded,
                  title: 'Focus Reminder',
                  subtitle:
                      'Get reminders related to your focus sessions.',
                  value: _focusReminder,
                  onChanged: _setFocusReminder,
                ),

                _settingTile(
                  icon: Icons.phone_android_rounded,
                  title: 'Screen-Time Reminder',
                  subtitle:
                      'Get a reminder in the evening to check your screen time.',
                  value: _screenTimeReminder,
                  onChanged:
                      _setScreenTimeReminder,
                ),

                _settingTile(
                  icon: Icons.psychology_rounded,
                  title: 'Distraction Alert',
                  subtitle:
                      'Receive an alert when distracting usage increases.',
                  value: _distractionAlert,
                  onChanged:
                      _setDistractionAlert,
                ),

                _settingTile(
                  icon: Icons.self_improvement_rounded,
                  title: 'Daily Wellbeing',
                  subtitle:
                      'Receive a daily reminder to check your digital wellbeing.',
                  value: _wellbeingReminder,
                  onChanged:
                      _setWellbeingReminder,
                ),

                const SizedBox(height: 12),

                Container(
                  padding: const EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: const Color(0xFFEDE9FF),
                    borderRadius:
                        BorderRadius.circular(18),
                  ),
                  child: Row(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      const Icon(
                        Icons.info_outline_rounded,
                        color: Color(0xFF7357D9),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          'MindfulAI reminders are designed to help you build healthier digital habits without interrupting your important activities.',
                          style: TextStyle(
                            fontSize: 12,
                            height: 1.4,
                            color: Colors
                                .deepPurple
                                .shade700,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}