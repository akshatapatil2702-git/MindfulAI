import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../models/app_usage_model.dart';
import '../services/firebase_service.dart';
import '../services/usage_service.dart';
import '../widgets/app_usage_card.dart';

class UsageStatsScreen extends StatefulWidget {
  const UsageStatsScreen({super.key});

  @override
  State<UsageStatsScreen> createState() =>
      _UsageStatsScreenState();
}

class _UsageStatsScreenState extends State<UsageStatsScreen>
    with WidgetsBindingObserver {
  final UsageService _usageService =
      UsageService.instance;

  final FirebaseService _firebaseService =
      FirebaseService.instance;

  bool _isLoading = true;
  bool _hasPermission = false;

  List<AppUsageModel> _apps = [];

  int _selectedDays = 1;

  final List<Map<String, dynamic>> _periods = [
    {
      'label': 'Daily',
      'days': 1,
    },
    {
      'label': 'Weekly',
      'days': 7,
    },
    {
      'label': 'Monthly',
      'days': 30,
    },
  ];

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addObserver(this);

    _loadUsage();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(
    AppLifecycleState state,
  ) {
    if (state == AppLifecycleState.resumed) {
      _loadUsage();
    }
  }

  // ==========================================================
  // LOAD REAL ANDROID USAGE
  // ==========================================================

  Future<void> _loadUsage() async {
    if (mounted) {
      setState(() {
        _isLoading = true;
      });
    }

    try {
      final permission =
          await _usageService.hasUsageAccess();

      if (!permission) {
        if (!mounted) return;

        setState(() {
          _hasPermission = false;
          _isLoading = false;
          _apps = [];
        });

        return;
      }

      final rawData =
          await _usageService.getUsageStats(
        days: _selectedDays,
      );

      final apps = rawData
          .map(
            (item) =>
                AppUsageModel.fromMap(item),
          )
          .where(
            (app) =>
                app.totalTimeInForeground > 0,
          )
          .toList();

      apps.sort(
        (a, b) =>
            b.totalTimeInForeground.compareTo(
          a.totalTimeInForeground,
        ),
      );

      if (!mounted) return;

      setState(() {
        _hasPermission = true;
        _isLoading = false;
        _apps = apps;
      });

      if (_selectedDays == 1) {
        await _saveDailyUsage();
      }
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _isLoading = false;
        _apps = [];
      });

      _showMessage(
        'Unable to load usage information.',
      );
    }
  }

  // ==========================================================
  // CHANGE PERIOD
  // ==========================================================

  Future<void> _changePeriod(
    int days,
  ) async {
    if (_selectedDays == days) {
      return;
    }

    setState(() {
      _selectedDays = days;
    });

    await _loadUsage();
  }

  // ==========================================================
  // SAVE TODAY'S DATA
  // ==========================================================

  Future<void> _saveDailyUsage() async {
    try {
      final now = DateTime.now();

      final date =
          '${now.year.toString().padLeft(4, '0')}-'
          '${now.month.toString().padLeft(2, '0')}-'
          '${now.day.toString().padLeft(2, '0')}';

      await _firebaseService.saveDailyUsage(
        date: date,
        totalScreenTime: _totalScreenTime,
        appsUsed: _apps.length,
        appLaunches: _totalLaunches,
        appUsage: _apps
            .map(
              (app) => app.toMap(),
            )
            .toList(),
      );
    } catch (_) {
      // Firebase saving must not break this screen.
    }
  }

  // ==========================================================
  // OPEN USAGE ACCESS
  // ==========================================================

  Future<void> _openPermissionSettings() async {
    final result =
        await _usageService.openUsageAccessSettings();

    if (!result && mounted) {
      _showMessage(
        'Unable to open Usage Access settings.',
      );
      return;
    }

    await Future.delayed(
      const Duration(milliseconds: 600),
    );

    if (!mounted) return;

    await _loadUsage();
  }

  // ==========================================================
  // MESSAGE
  // ==========================================================

  void _showMessage(
    String message,
  ) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          behavior:
              SnackBarBehavior.floating,
          margin:
              const EdgeInsets.all(16),
          backgroundColor:
              const Color(0xFF2D2942),
          shape:
              RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(14),
          ),
        ),
      );
  }

  // ==========================================================
  // TOTALS
  // ==========================================================

  int get _totalScreenTime {
    return _apps.fold(
      0,
      (total, app) =>
          total +
          app.totalTimeInForeground,
    );
  }

  int get _totalLaunches {
    return _apps.fold(
      0,
      (total, app) =>
          total + app.launchCount,
    );
  }

  String get _screenTimeText {
    return _usageService.formatDuration(
      _totalScreenTime,
    );
  }

  // ==========================================================
  // CATEGORY TOTALS
  // ==========================================================

  Map<String, int> get _categoryTotals {
    return _usageService.getCategoryTotals(
      _apps.map(
        (app) => app.toMap(),
      ).toList(),
    );
  }

  // ==========================================================
  // CATEGORY ICON
  // ==========================================================

  IconData _categoryIcon(
    String category,
  ) {
    switch (category) {
      case 'Social Media':
        return Icons.people_alt_rounded;

      case 'Productivity':
        return Icons.work_rounded;

      case 'Entertainment':
        return Icons.movie_rounded;

      case 'Communication':
        return Icons.chat_rounded;

      case 'Web & Browsing':
        return Icons.language_rounded;

      default:
        return Icons.apps_rounded;
    }
  }

  // ==========================================================
  // CATEGORY COLOR
  // ==========================================================

  Color _categoryColor(
    String category,
  ) {
    switch (category) {
      case 'Social Media':
        return const Color(0xFFE96B9D);

      case 'Productivity':
        return const Color(0xFF5B8DEF);

      case 'Entertainment':
        return const Color(0xFF65B985);

      case 'Communication':
        return const Color(0xFF4CB7A5);

      case 'Web & Browsing':
        return const Color(0xFF8B72D9);

      default:
        return const Color(0xFFE5A64A);
    }
  }

  // ==========================================================
  // BUILD
  // ==========================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      backgroundColor:
          const Color(0xFFF7F5FF),

      appBar: AppBar(
        backgroundColor:
            const Color(0xFFF7F5FF),
        elevation: 0,
        scrolledUnderElevation: 0,

        leading: IconButton(
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            size: 19,
          ),
          color:
              const Color(0xFF302B42),
          onPressed: () {
            Navigator.pop(context);
          },
        ),

        title: const Text(
          'Usage Statistics',
          style: TextStyle(
            fontSize: 21,
            fontWeight:
                FontWeight.w800,
            color:
                Color(0xFF252238),
          ),
        ),

        actions: [
          IconButton(
            onPressed:
                _isLoading
                    ? null
                    : _loadUsage,
            icon: const Icon(
              Icons.refresh_rounded,
            ),
            color:
                const Color(0xFF7357D9),
          ),
        ],
      ),

      body: RefreshIndicator(
        color:
            const Color(0xFF7357D9),
        onRefresh: _loadUsage,
        child: _buildBody(),
      ),
    );
  }

  // ==========================================================
  // BODY
  // ==========================================================

  Widget _buildBody() {
    if (_isLoading) {
      return ListView(
        physics:
            const AlwaysScrollableScrollPhysics(),
        children: const [
          SizedBox(
            height: 300,
            child: Center(
              child:
                  CircularProgressIndicator(
                color:
                    Color(0xFF7357D9),
              ),
            ),
          ),
        ],
      );
    }

    if (!_hasPermission) {
      return ListView(
        physics:
            const AlwaysScrollableScrollPhysics(),
        padding:
            const EdgeInsets.fromLTRB(
          20,
          10,
          20,
          30,
        ),
        children: [
          _buildPermissionCard(),
        ],
      );
    }

    if (_apps.isEmpty) {
      return ListView(
        physics:
            const AlwaysScrollableScrollPhysics(),
        padding:
            const EdgeInsets.fromLTRB(
          20,
          10,
          20,
          30,
        ),
        children: [
          _buildPeriodTabs(),
          const SizedBox(height: 18),
          _buildEmptyState(),
        ],
      );
    }

    return ListView(
      physics:
          const AlwaysScrollableScrollPhysics(),
      padding:
          const EdgeInsets.fromLTRB(
        20,
        8,
        20,
        35,
      ),
      children: [
        _buildPeriodTabs(),

        const SizedBox(height: 18),

        _buildScreenTimeCard(),

        const SizedBox(height: 18),

        _buildUsageGraph(),

        const SizedBox(height: 18),

        _buildCategoryCard(),

        const SizedBox(height: 18),

        _buildAppUsageSection(),

        const SizedBox(height: 18),

        _buildTipCard(),
      ],
    );
  }

  // ==========================================================
  // PERIOD TABS
  // ==========================================================

  Widget _buildPeriodTabs() {
    return Container(
      height: 50,
      padding:
          const EdgeInsets.all(5),
      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(18),
        border: Border.all(
          color:
              const Color(0xFFEAE6F7),
        ),
      ),
      child: Row(
        children:
            _periods.map(
          (period) {
            final days =
                period['days'] as int;

            final selected =
                days == _selectedDays;

            return Expanded(
              child: GestureDetector(
                onTap: () {
                  _changePeriod(days);
                },
                child: AnimatedContainer(
                  duration:
                      const Duration(
                    milliseconds: 180,
                  ),
                  alignment:
                      Alignment.center,
                  decoration:
                      BoxDecoration(
                    color: selected
                        ? const Color(
                            0xFF7357D9,
                          )
                        : Colors.transparent,
                    borderRadius:
                        BorderRadius.circular(
                      14,
                    ),
                  ),
                  child: Text(
                    period['label']
                        as String,
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight:
                          FontWeight.w800,
                      color: selected
                          ? Colors.white
                          : const Color(
                              0xFF777185,
                            ),
                    ),
                  ),
                ),
              ),
            );
          },
        ).toList(),
      ),
    );
  }

  // ==========================================================
  // SCREEN TIME CARD
  // ==========================================================

  Widget _buildScreenTimeCard() {
    return Container(
      padding:
          const EdgeInsets.all(20),
      decoration:
          BoxDecoration(
        gradient:
            const LinearGradient(
          colors: [
            Color(0xFF7357D9),
            Color(0xFF917BE6),
          ],
          begin:
              Alignment.topLeft,
          end:
              Alignment.bottomRight,
        ),
        borderRadius:
            BorderRadius.circular(26),
        boxShadow: [
          BoxShadow(
            color:
                const Color(0xFF7357D9)
                    .withValues(
              alpha: 0.18,
            ),
            blurRadius: 20,
            offset:
                const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,
            decoration:
                BoxDecoration(
              color:
                  Colors.white.withValues(
                alpha: 0.16,
              ),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.access_time_rounded,
              color: Colors.white,
              size: 30,
            ),
          ),

          const SizedBox(width: 15),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                const Text(
                  'Screen Time',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 13,
                    fontWeight:
                        FontWeight.w600,
                  ),
                ),

                const SizedBox(height: 4),

                Text(
                  _screenTimeText,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 27,
                    fontWeight:
                        FontWeight.w900,
                  ),
                ),

                const SizedBox(height: 3),

                Text(
                  _selectedDays == 1
                      ? 'Today'
                      : '$_selectedDays-day total',
                  style: TextStyle(
                    color:
                        Colors.white.withValues(
                      alpha: 0.78,
                    ),
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),

          Container(
            padding:
                const EdgeInsets.symmetric(
              horizontal: 10,
              vertical: 8,
            ),
            decoration:
                BoxDecoration(
              color:
                  Colors.white.withValues(
                alpha: 0.14,
              ),
              borderRadius:
                  BorderRadius.circular(14),
            ),
            child: Column(
              children: [
                const Icon(
                  Icons.calendar_today_rounded,
                  color: Colors.white,
                  size: 17,
                ),
                const SizedBox(height: 4),
                Text(
                  _selectedDays == 1
                      ? '1D'
                      : '${_selectedDays}D',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight:
                        FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // USAGE GRAPH
  // ==========================================================

  Widget _buildUsageGraph() {
    final graphApps =
        _apps.take(7).toList();

    final maxUsage =
        graphApps.fold<int>(
      0,
      (max, app) =>
          math.max(
        max,
        app.totalTimeInForeground,
      ),
    );

    return Container(
      padding:
          const EdgeInsets.fromLTRB(
        18,
        18,
        18,
        16,
      ),
      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(24),
        border: Border.all(
          color:
              const Color(0xFFEAE6F7),
        ),
        boxShadow: [
          BoxShadow(
            color:
                const Color(0xFF7357D9)
                    .withValues(
              alpha: 0.05,
            ),
            blurRadius: 16,
            offset:
                const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Usage Breakdown',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight:
                        FontWeight.w800,
                    color:
                        Color(0xFF252238),
                  ),
                ),
              ),
              Text(
                'Top ${graphApps.length}',
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight:
                      FontWeight.w700,
                  color:
                      Color(0xFF8E889A),
                ),
              ),
            ],
          ),

          const SizedBox(height: 5),

          Text(
            'Screen time by app',
            style: TextStyle(
              fontSize: 12,
              color:
                  Colors.grey.shade600,
            ),
          ),

          const SizedBox(height: 20),

          if (maxUsage <= 0)
            const SizedBox(
              height: 120,
              child: Center(
                child: Text(
                  'No graph data available',
                ),
              ),
            )
          else
            ...graphApps.map(
              (app) {
                final ratio =
                    app.totalTimeInForeground /
                        maxUsage;

                return Padding(
                  padding:
                      const EdgeInsets.only(
                    bottom: 14,
                  ),
                  child: Row(
                    children: [
                      _smallIcon(app),

                      const SizedBox(
                        width: 10,
                      ),

                      SizedBox(
                        width: 70,
                        child: Text(
                          app.appName,
                          maxLines: 1,
                          overflow:
                              TextOverflow.ellipsis,
                          style:
                              const TextStyle(
                            fontSize: 11,
                            fontWeight:
                                FontWeight.w700,
                            color:
                                Color(0xFF403B52),
                          ),
                        ),
                      ),

                      const SizedBox(
                        width: 8,
                      ),

                      Expanded(
                        child:
                            Stack(
                          children: [
                            Container(
                              height: 10,
                              decoration:
                                  BoxDecoration(
                                color:
                                    const Color(
                                  0xFFF0ECFF,
                                ),
                                borderRadius:
                                    BorderRadius
                                        .circular(
                                  10,
                                ),
                              ),
                            ),

                            FractionallySizedBox(
                              widthFactor:
                                  ratio.clamp(
                                0.03,
                                1.0,
                              ),
                              child:
                                  Container(
                                height: 10,
                                decoration:
                                    BoxDecoration(
                                  color:
                                      const Color(
                                    0xFF7357D9,
                                  ),
                                  borderRadius:
                                      BorderRadius
                                          .circular(
                                    10,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      const SizedBox(
                        width: 8,
                      ),

                      SizedBox(
                        width: 43,
                        child: Text(
                          _usageService
                              .formatDuration(
                            app
                                .totalTimeInForeground,
                          ),
                          textAlign:
                              TextAlign.right,
                          style:
                              const TextStyle(
                            fontSize: 10,
                            fontWeight:
                                FontWeight.w800,
                            color:
                                Color(0xFF7357D9),
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  // ==========================================================
  // CATEGORY CARD
  // ==========================================================

  Widget _buildCategoryCard() {
    final entries =
        _categoryTotals.entries
            .where(
              (entry) =>
                  entry.value > 0,
            )
            .toList()
          ..sort(
            (a, b) =>
                b.value.compareTo(
              a.value,
            ),
          );

    if (entries.isEmpty) {
      return const SizedBox.shrink();
    }

    return Container(
      padding:
          const EdgeInsets.all(20),
      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(24),
        border: Border.all(
          color:
              const Color(0xFFEAE6F7),
        ),
        boxShadow: [
          BoxShadow(
            color:
                const Color(0xFF7357D9)
                    .withValues(
              alpha: 0.05,
            ),
            blurRadius: 16,
            offset:
                const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          const Text(
            'App Categories',
            style: TextStyle(
              fontSize: 18,
              fontWeight:
                  FontWeight.w800,
              color:
                  Color(0xFF252238),
            ),
          ),

          const SizedBox(height: 5),

          Text(
            'How your screen time is distributed',
            style: TextStyle(
              fontSize: 12,
              color:
                  Colors.grey.shade600,
            ),
          ),

          const SizedBox(height: 18),

          ...entries.map(
            (entry) {
              final percentage =
                  _totalScreenTime <= 0
                      ? 0.0
                      : entry.value /
                          _totalScreenTime;

              final percentageText =
                  (percentage * 100)
                      .round();

              final color =
                  _categoryColor(
                entry.key,
              );

              return Padding(
                padding:
                    const EdgeInsets.only(
                  bottom: 17,
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 38,
                          height: 38,
                          decoration:
                              BoxDecoration(
                            color:
                                color.withValues(
                              alpha: 0.12,
                            ),
                            borderRadius:
                                BorderRadius
                                    .circular(
                              12,
                            ),
                          ),
                          child: Icon(
                            _categoryIcon(
                              entry.key,
                            ),
                            color: color,
                            size: 19,
                          ),
                        ),

                        const SizedBox(
                          width: 11,
                        ),

                        Expanded(
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment
                                    .start,
                            children: [
                              Text(
                                entry.key,
                                style:
                                    const TextStyle(
                                  fontSize: 13,
                                  fontWeight:
                                      FontWeight.w800,
                                  color:
                                      Color(
                                    0xFF403B52,
                                  ),
                                ),
                              ),

                              const SizedBox(
                                height: 3,
                              ),

                              Text(
                                _usageService
                                    .formatDuration(
                                  entry.value,
                                ),
                                style:
                                    TextStyle(
                                  fontSize: 11,
                                  color:
                                      Colors.grey
                                          .shade600,
                                ),
                              ),
                            ],
                          ),
                        ),

                        Text(
                          '$percentageText%',
                          style:
                              TextStyle(
                            fontSize: 13,
                            fontWeight:
                                FontWeight.w900,
                            color: color,
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(
                      height: 9,
                    ),

                    ClipRRect(
                      borderRadius:
                          BorderRadius.circular(
                        10,
                      ),
                      child:
                          LinearProgressIndicator(
                        value:
                            percentage
                                .clamp(
                          0.0,
                          1.0,
                        ),
                        minHeight: 7,
                        backgroundColor:
                            color.withValues(
                          alpha: 0.10,
                        ),
                        valueColor:
                            AlwaysStoppedAnimation<
                                Color>(
                          color,
                        ),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // APP USAGE
  // ==========================================================

  Widget _buildAppUsageSection() {
    final visibleApps =
        _apps.take(10).toList();

    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        const Padding(
          padding:
              EdgeInsets.symmetric(
            horizontal: 2,
          ),
          child: Text(
            'App Usage',
            style: TextStyle(
              fontSize: 19,
              fontWeight:
                  FontWeight.w800,
              color:
                  Color(0xFF252238),
            ),
          ),
        ),

        const SizedBox(height: 12),

        ...visibleApps.map(
          (app) {
            return AppUsageCard(
              app: app,
            );
          },
        ),
      ],
    );
  }

  // ==========================================================
  // SMALL REAL APP ICON
  // ==========================================================

  Widget _smallIcon(
    AppUsageModel app,
  ) {
    if (app.iconBytes != null &&
        app.iconBytes!.isNotEmpty) {
      return Container(
        width: 30,
        height: 30,
        decoration:
            BoxDecoration(
          color:
              const Color(0xFFF4F1FF),
          borderRadius:
              BorderRadius.circular(8),
        ),
        clipBehavior:
            Clip.antiAlias,
        child: Image.memory(
          app.iconBytes!,
          fit: BoxFit.contain,
          errorBuilder:
              (
            context,
            error,
            stackTrace,
          ) {
            return const Icon(
              Icons.apps_rounded,
              size: 17,
              color:
                  Color(0xFF7357D9),
            );
          },
        ),
      );
    }

    return Container(
      width: 30,
      height: 30,
      decoration:
          BoxDecoration(
        color:
            const Color(0xFFF0ECFF),
        borderRadius:
            BorderRadius.circular(8),
      ),
      child: const Icon(
        Icons.apps_rounded,
        size: 17,
        color:
            Color(0xFF7357D9),
      ),
    );
  }

  // ==========================================================
  // PERMISSION CARD
  // ==========================================================

  Widget _buildPermissionCard() {
    return Container(
      margin:
          const EdgeInsets.only(
        top: 25,
      ),
      padding:
          const EdgeInsets.all(24),
      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(26),
        border: Border.all(
          color:
              const Color(0xFFEAE6F7),
        ),
      ),
      child: Column(
        children: [
          Container(
            width: 76,
            height: 76,
            decoration:
                const BoxDecoration(
              color:
                  Color(0xFFF0ECFF),
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.bar_chart_rounded,
              size: 38,
              color:
                  Color(0xFF7357D9),
            ),
          ),

          const SizedBox(height: 18),

          const Text(
            'Usage Access Required',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 20,
              fontWeight:
                  FontWeight.w800,
              color:
                  Color(0xFF252238),
            ),
          ),

          const SizedBox(height: 8),

          Text(
            'Allow MindfulAI to access your device usage so your real screen-time statistics and app usage can be displayed.',
            textAlign:
                TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              height: 1.5,
              color:
                  Colors.grey.shade600,
            ),
          ),

          const SizedBox(height: 20),

          SizedBox(
            width: double.infinity,
            height: 50,
            child: ElevatedButton.icon(
              onPressed:
                  _openPermissionSettings,
              icon: const Icon(
                Icons.settings_rounded,
                size: 19,
              ),
              label: const Text(
                'Open Usage Access',
              ),
              style:
                  ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(
                  0xFF7357D9,
                ),
                foregroundColor:
                    Colors.white,
                elevation: 0,
                shape:
                    RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(
                    15,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // EMPTY
  // ==========================================================

  Widget _buildEmptyState() {
    return Container(
      padding:
          const EdgeInsets.all(26),
      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(24),
        border: Border.all(
          color:
              const Color(0xFFEAE6F7),
        ),
      ),
      child: Column(
        children: [
          const Icon(
            Icons.hourglass_empty_rounded,
            size: 45,
            color:
                Color(0xFFAAA4B8),
          ),

          const SizedBox(height: 12),

          const Text(
            'No usage data available',
            style: TextStyle(
              fontSize: 17,
              fontWeight:
                  FontWeight.w800,
              color:
                  Color(0xFF252238),
            ),
          ),

          const SizedBox(height: 6),

          Text(
            'Use your phone normally and refresh this screen later.',
            textAlign:
                TextAlign.center,
            style: TextStyle(
              fontSize: 13,
              color:
                  Colors.grey.shade600,
            ),
          ),

          const SizedBox(height: 16),

          OutlinedButton.icon(
            onPressed: _loadUsage,
            icon: const Icon(
              Icons.refresh_rounded,
            ),
            label: const Text(
              'Refresh',
            ),
            style:
                OutlinedButton.styleFrom(
              foregroundColor:
                  const Color(
                0xFF7357D9,
              ),
              side:
                  const BorderSide(
                color:
                    Color(0xFF7357D9),
              ),
              shape:
                  RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(
                  14,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // TIP
  // ==========================================================

  Widget _buildTipCard() {
    return Container(
      padding:
          const EdgeInsets.all(18),
      decoration:
          BoxDecoration(
        color:
            const Color(0xFFF0ECFF),
        borderRadius:
            BorderRadius.circular(20),
      ),
      child: Row(
        children: [
          Container(
            width: 44,
            height: 44,
            decoration:
                const BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),
            child: const Icon(
              Icons.lightbulb_rounded,
              color:
                  Color(0xFF7357D9),
              size: 23,
            ),
          ),

          const SizedBox(width: 12),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                const Text(
                  'Mindful Tip',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight:
                        FontWeight.w800,
                    color:
                        Color(0xFF403B52),
                  ),
                ),

                const SizedBox(height: 4),

                Text(
                  _totalScreenTime >
                          const Duration(
                            hours: 6,
                          ).inMilliseconds
                      ? 'Try taking short breaks and reducing unnecessary screen time.'
                      : 'Your screen time is within a mindful range. Keep building healthy habits.',
                  style: const TextStyle(
                    fontSize: 12,
                    height: 1.4,
                    color:
                        Color(0xFF716B7F),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}