import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class FocusStatisticsScreen extends StatefulWidget {
  const FocusStatisticsScreen({super.key});

  @override
  State<FocusStatisticsScreen> createState() =>
      _FocusStatisticsScreenState();
}

class _FocusStatisticsScreenState
    extends State<FocusStatisticsScreen> {
  static const String _focusHistoryKey =
      'focus_session_history';

  bool _isLoading = true;

  List<Map<String, dynamic>> _sessions = [];

  int _totalSessions = 0;
  int _totalMinutes = 0;
  int _todayMinutes = 0;

  @override
  void initState() {
    super.initState();
    _loadFocusStatistics();
  }

  Future<void> _loadFocusStatistics() async {
    try {
      final prefs =
          await SharedPreferences.getInstance();

      final savedSessions =
          prefs.getStringList(
                _focusHistoryKey,
              ) ??
              [];

      final sessions =
          <Map<String, dynamic>>[];

      for (final item in savedSessions) {
        try {
          final decoded = jsonDecode(item);

          if (decoded is Map) {
            sessions.add(
              Map<String, dynamic>.from(
                decoded,
              ),
            );
          }
        } catch (_) {
          // Ignore invalid history entries.
        }
      }

      sessions.sort(
        (a, b) {
          final dateA =
              DateTime.tryParse(
                    a['completedAt']
                            ?.toString() ??
                        '',
                  ) ??
                  DateTime(2000);

          final dateB =
              DateTime.tryParse(
                    b['completedAt']
                            ?.toString() ??
                        '',
                  ) ??
                  DateTime(2000);

          return dateB.compareTo(dateA);
        },
      );

      int totalMinutes = 0;
      int todayMinutes = 0;

      final now = DateTime.now();

      for (final session in sessions) {
        final duration =
            int.tryParse(
                  session['duration']
                          ?.toString() ??
                      '0',
                ) ??
                0;

        totalMinutes += duration;

        final completedAt =
            DateTime.tryParse(
          session['completedAt']
                  ?.toString() ??
              '',
        );

        if (completedAt != null &&
            completedAt.year == now.year &&
            completedAt.month == now.month &&
            completedAt.day == now.day) {
          todayMinutes += duration;
        }
      }

      if (!mounted) return;

      setState(() {
        _sessions = sessions;
        _totalSessions = sessions.length;
        _totalMinutes = totalMinutes;
        _todayMinutes = todayMinutes;
        _isLoading = false;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _isLoading = false;
      });
    }
  }

  String _formatMinutes(int minutes) {
    if (minutes < 60) {
      return '$minutes min';
    }

    final hours = minutes ~/ 60;
    final remaining = minutes % 60;

    if (remaining == 0) {
      return '${hours}h';
    }

    return '${hours}h ${remaining}m';
  }

  String _formatDateTime(String? value) {
    if (value == null || value.isEmpty) {
      return 'Unknown date';
    }

    final date = DateTime.tryParse(value);

    if (date == null) {
      return 'Unknown date';
    }

    final hour =
        date.hour % 12 == 0
            ? 12
            : date.hour % 12;

    final minute =
        date.minute
            .toString()
            .padLeft(2, '0');

    final period =
        date.hour >= 12
            ? 'PM'
            : 'AM';

    final day = date.day
        .toString()
        .padLeft(2, '0');

    final month = date.month
        .toString()
        .padLeft(2, '0');

    return '$day/$month/${date.year} • '
        '$hour:$minute $period';
  }

  double get _progress {
    const dailyTarget = 60;

    if (_todayMinutes <= 0) {
      return 0;
    }

    return (_todayMinutes / dailyTarget)
        .clamp(0.0, 1.0);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:
          const Color(0xFFF7F5FF),
      appBar: AppBar(
        backgroundColor:
            const Color(0xFFF7F5FF),
        elevation: 0,
        scrolledUnderElevation: 0,
        leading: TextButton(
          onPressed: () =>
              Navigator.maybePop(context),
          child: const Text(
            '‹',
            style: TextStyle(
              fontSize: 38,
              height: .8,
              fontWeight:
                  FontWeight.w300,
              color:
                  Color(0xFF252238),
            ),
          ),
        ),
        title: const Text(
          'Focus Statistics',
          style: TextStyle(
            color:
                Color(0xFF252238),
            fontSize: 20,
            fontWeight:
                FontWeight.w800,
          ),
        ),
      ),
      body: _isLoading
          ? const Center(
              child:
                  CircularProgressIndicator(
                color:
                    Color(0xFF7357D9),
              ),
            )
          : RefreshIndicator(
              onRefresh:
                  _loadFocusStatistics,
              color:
                  const Color(0xFF7357D9),
              child: ListView(
                physics:
                    const AlwaysScrollableScrollPhysics(),
                padding:
                    const EdgeInsets.fromLTRB(
                  20,
                  8,
                  20,
                  30,
                ),
                children: [
                  _buildHero(),
                  const SizedBox(
                    height: 18,
                  ),
                  _buildSummaryCards(),
                  const SizedBox(
                    height: 18,
                  ),
                  _buildTodayProgress(),
                  const SizedBox(
                    height: 18,
                  ),
                  _buildRecentSessions(),
                ],
              ),
            ),
    );
  }

  // ============================================================
  // HERO
  // ============================================================

  Widget _buildHero() {
    return Container(
      height: 145,
      padding:
          const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient:
            const LinearGradient(
          colors: [
            Color(0xFFE8E1FF),
            Color(0xFFF2EEFF),
          ],
          begin:
              Alignment.topLeft,
          end:
              Alignment.bottomRight,
        ),
        borderRadius:
            BorderRadius.circular(27),
      ),
      child: Stack(
        children: [
          Positioned(
            right: 10,
            top: 5,
            child: Container(
              width: 90,
              height: 90,
              decoration:
                  BoxDecoration(
                color: Colors.white
                    .withValues(
                  alpha: .45,
                ),
                shape:
                    BoxShape.circle,
              ),
            ),
          ),
          const Positioned(
            right: 28,
            top: 22,
            child: Text(
              '📈',
              style: TextStyle(
                fontSize: 34,
              ),
            ),
          ),
          const Positioned(
            right: 65,
            bottom: 8,
            child: Text(
              '🎯',
              style: TextStyle(
                fontSize: 50,
              ),
            ),
          ),
          const Align(
            alignment:
                Alignment.centerLeft,
            child: Column(
              mainAxisAlignment:
                  MainAxisAlignment.center,
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  'Focus Progress',
                  style: TextStyle(
                    fontSize: 22,
                    fontWeight:
                        FontWeight.w900,
                    color:
                        Color(0xFF252238),
                  ),
                ),
                SizedBox(
                  height: 5,
                ),
                Text(
                  'Track your completed focus sessions.',
                  style: TextStyle(
                    fontSize: 12.5,
                    color:
                        Color(0xFF62587B),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // SUMMARY
  // ============================================================

  Widget _buildSummaryCards() {
    return Row(
      children: [
        Expanded(
          child: _summaryCard(
            icon: '🎯',
            title: 'Sessions',
            value:
                '$_totalSessions',
          ),
        ),
        const SizedBox(
          width: 12,
        ),
        Expanded(
          child: _summaryCard(
            icon: '⏱️',
            title: 'Total Focus',
            value:
                _formatMinutes(
              _totalMinutes,
            ),
          ),
        ),
      ],
    );
  }

  Widget _summaryCard({
    required String icon,
    required String title,
    required String value,
  }) {
    return Container(
      padding:
          const EdgeInsets.all(17),
      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(22),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Container(
            width: 42,
            height: 42,
            decoration:
                BoxDecoration(
              color:
                  const Color(0xFFF0ECFF),
              borderRadius:
                  BorderRadius.circular(13),
            ),
            child: Center(
              child: Text(
                icon,
                style:
                    const TextStyle(
                  fontSize: 20,
                ),
              ),
            ),
          ),
          const SizedBox(
            height: 12,
          ),
          Text(
            title,
            style:
                const TextStyle(
              fontSize: 11,
              color:
                  Color(0xFF8B849E),
            ),
          ),
          const SizedBox(
            height: 4,
          ),
          Text(
            value,
            style:
                const TextStyle(
              fontSize: 19,
              fontWeight:
                  FontWeight.w900,
              color:
                  Color(0xFF252238),
            ),
          ),
        ],
      ),
    );
  }

  // ============================================================
  // TODAY PROGRESS
  // ============================================================

  Widget _buildTodayProgress() {
    const dailyTarget = 60;

    final percentage =
        (_todayMinutes /
                dailyTarget *
                100)
            .clamp(0, 100)
            .round();

    return Container(
      padding:
          const EdgeInsets.all(20),
      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(23),
        boxShadow: [
          BoxShadow(
            color:
                const Color(0xFF7357D9)
                    .withValues(
              alpha: .05,
            ),
            blurRadius: 15,
            offset:
                const Offset(0, 6),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Today\'s Focus',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight:
                        FontWeight.w800,
                    color:
                        Color(0xFF252238),
                  ),
                ),
              ),
              Text(
                '$percentage%',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight:
                      FontWeight.w900,
                  color:
                      Color(0xFF7357D9),
                ),
              ),
            ],
          ),
          const SizedBox(
            height: 8,
          ),
          Text(
            '${_formatMinutes(_todayMinutes)} focused today',
            style: const TextStyle(
              fontSize: 12,
              color:
                  Color(0xFF8B849E),
            ),
          ),
          const SizedBox(
            height: 15,
          ),
          ClipRRect(
            borderRadius:
                BorderRadius.circular(10),
            child:
                LinearProgressIndicator(
              value: _progress,
              minHeight: 9,
              backgroundColor:
                  const Color(0xFFEDE9FB),
              valueColor:
                  const AlwaysStoppedAnimation<
                      Color>(
                Color(0xFF7357D9),
              ),
            ),
          ),
          const SizedBox(
            height: 10,
          ),
          Row(
            mainAxisAlignment:
                MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Daily target',
                style: TextStyle(
                  fontSize: 11,
                  color:
                      Color(0xFF8B849E),
                ),
              ),
              Text(
                _formatMinutes(dailyTarget),
                style: const TextStyle(
                  fontSize: 11,
                  fontWeight:
                      FontWeight.w700,
                  color:
                      Color(0xFF62587B),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ============================================================
  // RECENT SESSIONS
  // ============================================================

  Widget _buildRecentSessions() {
    return Container(
      padding:
          const EdgeInsets.all(18),
      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(23),
      ),
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,
        children: [
          const Text(
            'Recent Focus Sessions',
            style: TextStyle(
              fontSize: 16,
              fontWeight:
                  FontWeight.w800,
              color:
                  Color(0xFF252238),
            ),
          ),
          const SizedBox(
            height: 14,
          ),
          if (_sessions.isEmpty)
            _buildEmptyState()
          else
            ..._sessions
                .take(10)
                .map(
              (session) {
                final duration =
                    int.tryParse(
                          session['duration']
                                  ?.toString() ??
                              '0',
                        ) ??
                        0;

                final completedAt =
                    session['completedAt']
                        ?.toString();

                return _sessionRow(
                  duration: duration,
                  completedAt:
                      completedAt,
                );
              },
            ),
        ],
      ),
    );
  }

  Widget _sessionRow({
    required int duration,
    required String? completedAt,
  }) {
    return Container(
      margin:
          const EdgeInsets.only(
        bottom: 10,
      ),
      padding:
          const EdgeInsets.all(13),
      decoration:
          BoxDecoration(
        color:
            const Color(0xFFF7F5FF),
        borderRadius:
            BorderRadius.circular(15),
      ),
      child: Row(
        children: [
          Container(
            width: 42,
            height: 42,
            decoration:
                BoxDecoration(
              color:
                  const Color(0xFFE8E1FF),
              borderRadius:
                  BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.check_circle_outline,
              color:
                  Color(0xFF7357D9),
              size: 22,
            ),
          ),
          const SizedBox(
            width: 12,
          ),
          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,
              children: [
                Text(
                  '$duration minute focus session',
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight:
                        FontWeight.w700,
                    color:
                        Color(0xFF403B52),
                  ),
                ),
                const SizedBox(
                  height: 4,
                ),
                Text(
                  _formatDateTime(
                    completedAt,
                  ),
                  style:
                      const TextStyle(
                    fontSize: 10.5,
                    color:
                        Color(0xFF8B849E),
                  ),
                ),
              ],
            ),
          ),
          const Icon(
            Icons.done_rounded,
            size: 20,
            color:
                Color(0xFF48A878),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Container(
      width: double.infinity,
      padding:
          const EdgeInsets.symmetric(
        vertical: 25,
        horizontal: 15,
      ),
      child: const Column(
        children: [
          Text(
            '🎯',
            style: TextStyle(
              fontSize: 35,
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Text(
            'No completed sessions yet',
            style: TextStyle(
              fontSize: 14,
              fontWeight:
                  FontWeight.w700,
              color:
                  Color(0xFF403B52),
            ),
          ),
          SizedBox(
            height: 5,
          ),
          Text(
            'Complete a Focus Mode session to see your progress here.',
            textAlign:
                TextAlign.center,
            style: TextStyle(
              fontSize: 11,
              color:
                  Color(0xFF8B849E),
            ),
          ),
        ],
      ),
    );
  }
}