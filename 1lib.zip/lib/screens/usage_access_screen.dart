import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../services/usage_service.dart';

class UsageAccessScreen extends StatefulWidget {
  const UsageAccessScreen({super.key});

  @override
  State<UsageAccessScreen> createState() =>
      _UsageAccessScreenState();
}

class _UsageAccessScreenState
    extends State<UsageAccessScreen>
    with WidgetsBindingObserver {
  final UsageService _usageService =
      UsageService.instance;

  bool _hasPermission = false;
  bool _isLoading = true;
  bool _isFetching = false;

  int _selectedDays = 1;

  List<Map<String, dynamic>> _usageData = [];

  int _totalUsageMilliseconds = 0;

  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addObserver(this);

    _checkPermission();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(
    AppLifecycleState state,
  ) {
    if (state == AppLifecycleState.resumed) {
      _checkPermission();
    }
  }

  // ==========================================================
  // PERMISSION
  // ==========================================================

  Future<void> _checkPermission() async {
    try {
      final result =
          await _usageService.hasUsageAccess();

      if (!mounted) return;

      setState(() {
        _hasPermission = result;
        _isLoading = false;
      });

      if (result) {
        await _loadUsageData();
      }
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _hasPermission = false;
        _isLoading = false;
      });
    }
  }

  // ==========================================================
  // OPEN SETTINGS
  // ==========================================================

  Future<void> _openUsageSettings() async {
    final success =
        await _usageService
            .openUsageAccessSettings();

    if (!success && mounted) {
      _showMessage(
        'Unable to open Usage Access settings.',
      );
    }
  }

  // ==========================================================
  // LOAD REAL USAGE
  // ==========================================================

  Future<void> _loadUsageData() async {
    if (!_hasPermission) return;

    if (mounted) {
      setState(() {
        _isFetching = true;
      });
    }

    try {
      final data =
          await _usageService.getUsageStats(
        days: _selectedDays,
      );

      final filtered = data
          .where((item) {
            final value =
                (item['totalTimeInForeground'] ??
                        0) as num;

            return value > 0;
          })
          .toList();

      filtered.sort((a, b) {
        final aTime =
            (a['totalTimeInForeground'] ??
                    0) as num;

        final bTime =
            (b['totalTimeInForeground'] ??
                    0) as num;

        return bTime.compareTo(aTime);
      });

      int total = 0;

      for (final item in filtered) {
        total +=
            ((item['totalTimeInForeground'] ??
                        0) as num)
                .toInt();
      }

      if (!mounted) return;

      setState(() {
        _usageData = filtered;
        _totalUsageMilliseconds = total;
        _isFetching = false;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _isFetching = false;
      });

      _showMessage(
        'Unable to load usage data.',
      );
    }
  }

  // ==========================================================
  // PERIOD CHANGE
  // ==========================================================

  Future<void> _changePeriod(
    int days,
  ) async {
    if (_selectedDays == days) return;

    setState(() {
      _selectedDays = days;
    });

    await _loadUsageData();
  }

  // ==========================================================
  // FORMAT DURATION
  // ==========================================================

  String _formatDuration(
    int milliseconds,
  ) {
    final duration =
        Duration(
      milliseconds: milliseconds,
    );

    final hours =
        duration.inHours;

    final minutes =
        duration.inMinutes
            .remainder(60);

    if (hours > 0) {
      return '${hours}h ${minutes}m';
    }

    if (minutes > 0) {
      return '${minutes}m';
    }

    return '<1m';
  }

  // ==========================================================
  // APP ICON
  // ==========================================================

  Uint8List? _getIcon(
    Map<String, dynamic> item,
  ) {
    final raw = item['iconBytes'];

    if (raw is Uint8List) {
      return raw;
    }

    if (raw is List) {
      try {
        return Uint8List.fromList(
          raw
              .map(
                (value) =>
                    (value as num).toInt(),
              )
              .toList(),
        );
      } catch (_) {
        return null;
      }
    }

    return null;
  }

  // ==========================================================
  // APP INITIAL FALLBACK
  // ==========================================================

  String _appInitial(
    String name,
  ) {
    final value = name.trim();

    if (value.isEmpty) {
      return '?';
    }

    return value
        .substring(0, 1)
        .toUpperCase();
  }

  // ==========================================================
  // APP COLOR
  // ==========================================================

  Color _appColor(
    int index,
  ) {
    const colors = [
      Color(0xFF7357D9),
      Color(0xFF5B8DEF),
      Color(0xFF46B7A8),
      Color(0xFFE49B42),
      Color(0xFFD86B91),
    ];

    return colors[
        index % colors.length];
  }

  // ==========================================================
  // PERCENTAGE
  // ==========================================================

  int _percentage(
    int milliseconds,
  ) {
    if (_totalUsageMilliseconds <= 0) {
      return 0;
    }

    return ((milliseconds /
                _totalUsageMilliseconds) *
            100)
        .round();
  }

  // ==========================================================
  // MESSAGE
  // ==========================================================

  void _showMessage(
    String message,
  ) {
    if (!mounted) return;

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content:
              Text(message),
          behavior:
              SnackBarBehavior.floating,
          margin:
              const EdgeInsets.all(16),
          backgroundColor:
              const Color(0xFF2D2942),
          shape:
              RoundedRectangleBorder(
            borderRadius:
                BorderRadius.circular(
              14,
            ),
          ),
        ),
      );
  }

  // ==========================================================
  // BUILD
  // ==========================================================

  @override
  Widget build(
    BuildContext context,
  ) {
    return Scaffold(
      backgroundColor:
          const Color(0xFFF7F5FF),

      appBar: AppBar(
        backgroundColor:
            const Color(0xFFF7F5FF),
        elevation: 0,
        scrolledUnderElevation: 0,

        leading: IconButton(
          onPressed: () {
            Navigator.maybePop(
              context,
            );
          },
          icon: const Icon(
            Icons.arrow_back_ios_new_rounded,
            size: 19,
          ),
          color:
              const Color(0xFF302B42),
        ),

        title: const Text(
          'Usage Access',
          style: TextStyle(
            fontSize: 21,
            fontWeight:
                FontWeight.w800,
            color:
                Color(0xFF252238),
          ),
        ),

        actions: [
          IconButton(
            onPressed:
                _isFetching
                    ? null
                    : _loadUsageData,
            icon: const Icon(
              Icons.refresh_rounded,
            ),
            color:
                const Color(0xFF7357D9),
          ),
        ],
      ),

      body: _isLoading
          ? const Center(
              child:
                  CircularProgressIndicator(
                color:
                    Color(0xFF7357D9),
              ),
            )
          : RefreshIndicator(
              color:
                  const Color(0xFF7357D9),

              onRefresh:
                  _checkPermission,

              child: ListView(
                physics:
                    const AlwaysScrollableScrollPhysics(),

                padding:
                    const EdgeInsets.fromLTRB(
                  20,
                  8,
                  20,
                  35,
                ),

                children: [
                  _buildPermissionCard(),

                  const SizedBox(
                    height: 18,
                  ),

                  if (_hasPermission) ...[
                    _buildPeriodTabs(),

                    const SizedBox(
                      height: 18,
                    ),

                    _buildTotalCard(),

                    const SizedBox(
                      height: 22,
                    ),

                    _buildAppUsageHeader(),

                    const SizedBox(
                      height: 12,
                    ),

                    if (_isFetching)
                      const Padding(
                        padding:
                            EdgeInsets.all(35),
                        child: Center(
                          child:
                              CircularProgressIndicator(
                            color:
                                Color(0xFF7357D9),
                          ),
                        ),
                      )
                    else if (_usageData.isEmpty)
                      _buildEmptyState()
                    else
                      ..._buildUsageCards(),

                    const SizedBox(
                      height: 8,
                    ),

                    _buildHealthyChoice(),
                  ],
                ],
              ),
            ),
    );
  }

  // ==========================================================
  // PERMISSION CARD
  // ==========================================================

  Widget _buildPermissionCard() {
    if (_hasPermission) {
      return Container(
        padding:
            const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 13,
        ),

        decoration:
            BoxDecoration(
          color:
              const Color(0xFFEAF8F2),
          borderRadius:
              BorderRadius.circular(17),
          border: Border.all(
            color:
                const Color(0xFFCBEBDD),
          ),
        ),

        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,

              decoration:
                  const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),

              child: const Icon(
                Icons.check_rounded,
                color:
                    Color(0xFF35A979),
                size: 22,
              ),
            ),

            const SizedBox(
              width: 11,
            ),

            const Expanded(
              child: Text(
                'Usage Access enabled',
                style: TextStyle(
                  fontSize: 13,
                  fontWeight:
                      FontWeight.w800,
                  color:
                      Color(0xFF287A59),
                ),
              ),
            ),

            const Icon(
              Icons.verified_rounded,
              color:
                  Color(0xFF35A979),
              size: 20,
            ),
          ],
        ),
      );
    }

    return Container(
      padding:
          const EdgeInsets.all(20),

      decoration:
          BoxDecoration(
        gradient:
            const LinearGradient(
          colors: [
            Color(0xFFECE8FF),
            Color(0xFFF6F4FF),
          ],
        ),

        borderRadius:
            BorderRadius.circular(24),

        border: Border.all(
          color:
              const Color(0xFFDCD5FF),
        ),
      ),

      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          Row(
            children: [
              Container(
                width: 50,
                height: 50,

                decoration:
                    BoxDecoration(
                  color: Colors.white,
                  borderRadius:
                      BorderRadius.circular(
                    16,
                  ),
                ),

                child: const Icon(
                  Icons.bar_chart_rounded,
                  color:
                      Color(0xFF7357D9),
                  size: 28,
                ),
              ),

              const SizedBox(
                width: 13,
              ),

              const Expanded(
                child: Text(
                  'Usage Access',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight:
                        FontWeight.w800,
                    color:
                        Color(0xFF252238),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(
            height: 12,
          ),

          Text(
            'Allow MindfulAI to read your device usage so it can show your real screen time and app statistics.',
            style: TextStyle(
              fontSize: 12,
              height: 1.5,
              color:
                  Colors.grey.shade700,
            ),
          ),

          const SizedBox(
            height: 16,
          ),

          SizedBox(
            width: double.infinity,
            height: 48,

            child:
                ElevatedButton.icon(
              onPressed:
                  _openUsageSettings,

              icon: const Icon(
                Icons.settings_rounded,
                size: 18,
              ),

              label: const Text(
                'Open Usage Access',
                style: TextStyle(
                  fontWeight:
                      FontWeight.w800,
                ),
              ),

              style:
                  ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(
                  0xFF7357D9,
                ),
                foregroundColor:
                    Colors.white,
                elevation: 0,
                shape:
                    RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(
                    14,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // PERIOD TABS
  // ==========================================================

  Widget _buildPeriodTabs() {
    return Container(
      height: 50,

      padding:
          const EdgeInsets.all(5),

      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(18),
        border: Border.all(
          color:
              const Color(0xFFEAE6F7),
        ),
      ),

      child: Row(
        children: [
          _periodButton(
            label: 'Today',
            days: 1,
          ),

          _periodButton(
            label: '7 Days',
            days: 7,
          ),

          _periodButton(
            label: '30 Days',
            days: 30,
          ),
        ],
      ),
    );
  }

  Widget _periodButton({
    required String label,
    required int days,
  }) {
    final selected =
        _selectedDays == days;

    return Expanded(
      child: GestureDetector(
        onTap: () {
          _changePeriod(days);
        },

        child: AnimatedContainer(
          duration:
              const Duration(
            milliseconds: 180,
          ),

          alignment:
              Alignment.center,

          decoration:
              BoxDecoration(
            color: selected
                ? const Color(
                    0xFF7357D9,
                  )
                : Colors.transparent,

            borderRadius:
                BorderRadius.circular(
              14,
            ),
          ),

          child: Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight:
                  FontWeight.w800,
              color: selected
                  ? Colors.white
                  : const Color(
                      0xFF777185,
                    ),
            ),
          ),
        ),
      ),
    );
  }

  // ==========================================================
  // TOTAL SCREEN TIME
  // ==========================================================

  Widget _buildTotalCard() {
    final periodText =
        _selectedDays == 1
            ? 'today'
            : 'in the last $_selectedDays days';

    return Container(
      padding:
          const EdgeInsets.all(20),

      decoration:
          BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(24),

        border: Border.all(
          color:
              const Color(0xFFEAE6F7),
        ),

        boxShadow: [
          BoxShadow(
            color:
                const Color(0xFF7357D9)
                    .withValues(
              alpha: 0.06,
            ),
            blurRadius: 15,
            offset:
                const Offset(0, 6),
          ),
        ],
      ),

      child: Row(
        children: [
          Container(
            width: 58,
            height: 58,

            decoration:
                BoxDecoration(
              color:
                  const Color(0xFFF0ECFF),
              borderRadius:
                  BorderRadius.circular(
                18,
              ),
            ),

            child: const Icon(
              Icons.access_time_filled_rounded,
              color:
                  Color(0xFF7357D9),
              size: 28,
            ),
          ),

          const SizedBox(
            width: 15,
          ),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [
                Text(
                  'Total Screen Time',
                  style: TextStyle(
                    fontSize: 12,
                    color:
                        Colors.grey.shade600,
                    fontWeight:
                        FontWeight.w600,
                  ),
                ),

                const SizedBox(
                  height: 4,
                ),

                Text(
                  _formatDuration(
                    _totalUsageMilliseconds,
                  ),
                  style:
                      const TextStyle(
                    fontSize: 26,
                    fontWeight:
                        FontWeight.w900,
                    color:
                        Color(0xFF252238),
                  ),
                ),

                const SizedBox(
                  height: 3,
                ),

                Text(
                  'Recorded $periodText',
                  style: TextStyle(
                    fontSize: 10,
                    color:
                        Colors.grey.shade500,
                  ),
                ),
              ],
            ),
          ),

          Container(
            width: 42,
            height: 42,

            decoration:
                BoxDecoration(
              color:
                  const Color(0xFFF8F6FF),
              shape: BoxShape.circle,
            ),

            child: const Icon(
              Icons.phone_android_rounded,
              color:
                  Color(0xFF7357D9),
              size: 21,
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // APP USAGE HEADER
  // ==========================================================

  Widget _buildAppUsageHeader() {
    return Row(
      children: [
        const Expanded(
          child: Text(
            'App Usage',
            style: TextStyle(
              fontSize: 19,
              fontWeight:
                  FontWeight.w800,
              color:
                  Color(0xFF252238),
            ),
          ),
        ),

        Text(
          '${_usageData.length} apps',
          style: TextStyle(
            fontSize: 12,
            fontWeight:
                FontWeight.w700,
            color:
                Colors.grey.shade600,
          ),
        ),
      ],
    );
  }

  // ==========================================================
  // APP CARDS
  // ==========================================================

  List<Widget> _buildUsageCards() {
    final visibleApps =
        _usageData.take(15).toList();

    return List.generate(
      visibleApps.length,
      (index) {
        final item =
            visibleApps[index];

        return _buildAppUsageCard(
          item: item,
          index: index,
        );
      },
    );
  }

  Widget _buildAppUsageCard({
    required Map<String, dynamic> item,
    required int index,
  }) {
    final appName =
        (item['appName'] ??
                'Unknown App')
            .toString();

    final packageName =
        (item['packageName'] ??
                '')
            .toString();

    final duration =
        ((item[
                    'totalTimeInForeground'] ??
                0) as num)
            .toInt();

    final launches =
        ((item['launchCount'] ??
                0) as num)
            .toInt();

    final icon =
        _getIcon(item);

    final percentage =
        _percentage(duration);

    final color =
        _appColor(index);

    return Container(
      margin:
          const EdgeInsets.only(
        bottom: 11,
      ),

      padding:
          const EdgeInsets.all(14),

      decoration:
          BoxDecoration(
        color: Colors.white,

        borderRadius:
            BorderRadius.circular(19),

        border: Border.all(
          color:
              const Color(0xFFEAE6F7),
        ),

        boxShadow: [
          BoxShadow(
            color:
                const Color(0xFF7357D9)
                    .withValues(
              alpha: 0.035,
            ),
            blurRadius: 10,
            offset:
                const Offset(0, 4),
          ),
        ],
      ),

      child: Row(
        children: [
          _buildRealIcon(
            icon: icon,
            appName: appName,
            color: color,
          ),

          const SizedBox(
            width: 13,
          ),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        appName,
                        maxLines: 1,
                        overflow:
                            TextOverflow.ellipsis,
                        style:
                            const TextStyle(
                          fontSize: 14,
                          fontWeight:
                              FontWeight.w800,
                          color:
                              Color(0xFF252238),
                        ),
                      ),
                    ),

                    Text(
                      '$percentage%',
                      style:
                          TextStyle(
                        fontSize: 11,
                        fontWeight:
                            FontWeight.w800,
                        color: color,
                      ),
                    ),
                  ],
                ),

                const SizedBox(
                  height: 4,
                ),

                Text(
                  _formatDuration(
                    duration,
                  ),
                  style:
                      const TextStyle(
                    fontSize: 12,
                    fontWeight:
                        FontWeight.w700,
                    color:
                        Color(0xFF7357D9),
                  ),
                ),

                const SizedBox(
                  height: 8,
                ),

                ClipRRect(
                  borderRadius:
                      BorderRadius.circular(
                    10,
                  ),

                  child:
                      LinearProgressIndicator(
                    value:
                        (_totalUsageMilliseconds >
                                0)
                            ? (duration /
                                    _totalUsageMilliseconds)
                                .clamp(
                                0.01,
                                1.0,
                              )
                            : 0.01,

                    minHeight: 5,

                    backgroundColor:
                        const Color(
                      0xFFF0ECFF,
                    ),

                    valueColor:
                        AlwaysStoppedAnimation<
                            Color>(
                      color,
                    ),
                  ),
                ),

                const SizedBox(
                  height: 7,
                ),

                Row(
                  children: [
                    Icon(
                      Icons
                          .open_in_new_rounded,
                      size: 12,
                      color:
                          Colors.grey.shade500,
                    ),

                    const SizedBox(
                      width: 4,
                    ),

                    Text(
                      '$launches opens',
                      style: TextStyle(
                        fontSize: 10,
                        color:
                            Colors.grey.shade600,
                      ),
                    ),

                    if (packageName
                        .isNotEmpty) ...[
                      const SizedBox(
                        width: 9,
                      ),
                      Flexible(
                        child: Text(
                          packageName,
                          maxLines: 1,
                          overflow:
                              TextOverflow
                                  .ellipsis,
                          style:
                              TextStyle(
                            fontSize: 8,
                            color: Colors
                                .grey
                                .shade400,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // REAL APP ICON
  // ==========================================================

  Widget _buildRealIcon({
    required Uint8List? icon,
    required String appName,
    required Color color,
  }) {
    if (icon != null &&
        icon.isNotEmpty) {
      return Container(
        width: 52,
        height: 52,

        decoration:
            BoxDecoration(
          color:
              const Color(0xFFF5F2FF),
          borderRadius:
              BorderRadius.circular(15),
        ),

        clipBehavior:
            Clip.antiAlias,

        child: Image.memory(
          icon,
          width: 52,
          height: 52,
          fit: BoxFit.contain,
          gaplessPlayback: true,

          errorBuilder:
              (
            context,
            error,
            stackTrace,
          ) {
            return _fallbackIcon(
              appName,
              color,
            );
          },
        ),
      );
    }

    return _fallbackIcon(
      appName,
      color,
    );
  }

  Widget _fallbackIcon(
    String appName,
    Color color,
  ) {
    return Container(
      width: 52,
      height: 52,

      decoration:
          BoxDecoration(
        color:
            color.withValues(
          alpha: 0.10,
        ),
        borderRadius:
            BorderRadius.circular(15),
      ),

      alignment:
          Alignment.center,

      child: Text(
        _appInitial(appName),
        style: TextStyle(
          fontSize: 19,
          fontWeight:
              FontWeight.w900,
          color: color,
        ),
      ),
    );
  }

  // ==========================================================
  // HEALTHY CHOICE
  // ==========================================================

  Widget _buildHealthyChoice() {
    final underSixHours =
        _totalUsageMilliseconds <
            const Duration(
              hours: 6,
            ).inMilliseconds;

    return Container(
      padding:
          const EdgeInsets.all(17),

      decoration:
          BoxDecoration(
        color:
            const Color(0xFFEFF9F4),
        borderRadius:
            BorderRadius.circular(20),
        border: Border.all(
          color:
              const Color(0xFFD5EDE1),
        ),
      ),

      child: Row(
        crossAxisAlignment:
            CrossAxisAlignment.start,

        children: [
          Container(
            width: 43,
            height: 43,

            decoration:
                const BoxDecoration(
              color: Colors.white,
              shape: BoxShape.circle,
            ),

            child: Icon(
              underSixHours
                  ? Icons.eco_rounded
                  : Icons.self_improvement_rounded,
              color:
                  const Color(0xFF38A879),
              size: 23,
            ),
          ),

          const SizedBox(
            width: 12,
          ),

          Expanded(
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment.start,

              children: [
                const Text(
                  'Healthy Choice',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight:
                        FontWeight.w800,
                    color:
                        Color(0xFF287A59),
                  ),
                ),

                const SizedBox(
                  height: 4,
                ),

                Text(
                  underSixHours
                      ? 'Your screen time is under 6 hours. Keep building mindful digital habits!'
                      : 'Consider taking a short break and reducing unnecessary screen time.',
                  style: const TextStyle(
                    fontSize: 11,
                    height: 1.45,
                    color:
                        Color(0xFF5B7D6D),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // EMPTY STATE
  // ==========================================================

  Widget _buildEmptyState() {
    return Container(
      padding:
          const EdgeInsets.all(28),

      decoration:
          BoxDecoration(
        color: Colors.white,
        borderRadius:
            BorderRadius.circular(22),
        border: Border.all(
          color:
              const Color(0xFFEAE6F7),
        ),
      ),

      child: Column(
        children: [
          Container(
            width: 68,
            height: 68,

            decoration:
                const BoxDecoration(
              color:
                  Color(0xFFF0ECFF),
              shape: BoxShape.circle,
            ),

            child: const Icon(
              Icons.analytics_outlined,
              color:
                  Color(0xFF7357D9),
              size: 34,
            ),
          ),

          const SizedBox(
            height: 14,
          ),

          const Text(
            'No usage data yet',
            style: TextStyle(
              fontSize: 17,
              fontWeight:
                  FontWeight.w800,
              color:
                  Color(0xFF252238),
            ),
          ),

          const SizedBox(
            height: 7,
          ),

          Text(
            _selectedDays == 1
                ? 'Use some apps and refresh this page to see today\'s actual usage.'
                : 'No app usage was found for this selected period.',
            textAlign:
                TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              height: 1.5,
              color:
                  Colors.grey.shade600,
            ),
          ),

          const SizedBox(
            height: 16,
          ),

          OutlinedButton.icon(
            onPressed:
                _loadUsageData,

            icon: const Icon(
              Icons.refresh_rounded,
              size: 18,
            ),

            label: const Text(
              'Refresh',
            ),

            style:
                OutlinedButton.styleFrom(
              foregroundColor:
                  const Color(
                0xFF7357D9,
              ),
              side:
                  const BorderSide(
                color:
                    Color(0xFF7357D9),
              ),
              shape:
                  RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(
                  13,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}