import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../services/auth_service.dart';
import '../services/firebase_service.dart';
import 'login_screen.dart';
import 'notification_settings_screen.dart';
import 'usage_access_screen.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  final FirebaseService _firebaseService =
      FirebaseService.instance;

  bool _isLoading = true;

  String _name = 'Mindful User';
  String _email = '';

  bool _hasPasswordProvider = false;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  // ==========================================================
  // LOAD PROFILE
  // ==========================================================

  Future<void> _loadProfile() async {
    try {
      final user = _auth.currentUser;

      if (user == null) {
        if (!mounted) return;

        setState(() {
          _isLoading = false;
        });

        return;
      }

      String name = user.displayName?.trim() ?? '';
      String email = user.email?.trim() ?? '';

      try {
        final profile = await _firebaseService.getUserProfile();

        final firebaseName =
            profile?['name']?.toString().trim();

        final firebaseEmail =
            profile?['email']?.toString().trim();

        if (firebaseName != null &&
            firebaseName.isNotEmpty) {
          name = firebaseName;
        }

        if (email.isEmpty &&
            firebaseEmail != null &&
            firebaseEmail.isNotEmpty) {
          email = firebaseEmail;
        }
      } catch (_) {
        // Firebase profile is optional.
      }

      if (!mounted) return;

      setState(() {
        _name = name.isEmpty ? 'Mindful User' : name;
        _email = email;

        _hasPasswordProvider = user.providerData.any(
          (provider) => provider.providerId == 'password',
        );

        _isLoading = false;
      });
    } catch (_) {
      if (!mounted) return;

      setState(() {
        _isLoading = false;
      });
    }
  }

  // ==========================================================
  // BUILD
  // ==========================================================

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F5FF),
      appBar: AppBar(
        backgroundColor: const Color(0xFFF7F5FF),
        elevation: 0,
        scrolledUnderElevation: 0,
        title: const Text(
          'Profile',
          style: TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.w800,
            color: Color(0xFF252238),
          ),
        ),
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(
                color: Color(0xFF7357D9),
              ),
            )
          : RefreshIndicator(
              color: const Color(0xFF7357D9),
              onRefresh: _loadProfile,
              child: ListView(
                physics:
                    const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.fromLTRB(
                  20,
                  8,
                  20,
                  30,
                ),
                children: [
                  _buildProfileHeader(),
                  const SizedBox(height: 18),
                  _buildAccountSection(),
                  const SizedBox(height: 18),
                  _buildAppSection(),
                  const SizedBox(height: 18),
                  _buildLogoutButton(),
                  const SizedBox(height: 15),
                  const Center(
                    child: Text(
                      'MindfulAI • Less Screen. More Life.',
                      style: TextStyle(
                        fontSize: 10,
                        color: Color(0xFFAAA4B8),
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  // ==========================================================
  // PROFILE HEADER
  // ==========================================================

  Widget _buildProfileHeader() {
    final initial = _name.isNotEmpty
        ? _name[0].toUpperCase()
        : 'M';

    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(
          color: const Color(0xFFEAE6F7),
        ),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF7357D9).withValues(
              alpha: 0.06,
            ),
            blurRadius: 20,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 70,
                height: 70,
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [
                      Color(0xFF7357D9),
                      Color(0xFF9A82EA),
                    ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    initial,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 27,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    Text(
                      _name,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF252238),
                      ),
                    ),
                    const SizedBox(height: 5),
                    Text(
                      _email.isEmpty
                          ? 'No email available'
                          : _email,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 11,
                        color: Color(0xFF817B8D),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 17),
          SizedBox(
            width: double.infinity,
            height: 46,
            child: OutlinedButton.icon(
              onPressed: _showEditProfileDialog,
              icon: const Icon(
                Icons.edit_rounded,
                size: 17,
              ),
              label: const Text('Edit Profile'),
              style: OutlinedButton.styleFrom(
                foregroundColor:
                    const Color(0xFF7357D9),
                side: const BorderSide(
                  color: Color(0xFFD9D0F5),
                ),
                shape: RoundedRectangleBorder(
                  borderRadius:
                      BorderRadius.circular(14),
                ),
                textStyle: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // ACCOUNT SECTION
  // ==========================================================

  Widget _buildAccountSection() {
    final items = <Widget>[
      _menuItem(
        icon: Icons.person_outline_rounded,
        title: 'My Account',
        subtitle: 'View your account information',
        onTap: _showAccountDialog,
      ),
    ];

    if (!_hasPasswordProvider) {
      items.add(
        _menuItem(
          icon: Icons.lock_outline_rounded,
          title: 'Set Password',
          subtitle: 'Add a password to your account',
          onTap: _showSetPasswordDialog,
        ),
      );
    }

    items.add(
      _menuItem(
        icon: Icons.notifications_none_rounded,
        title: 'Notification Settings',
        subtitle: 'Manage focus reminders',
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) =>
                  const NotificationSettingsScreen(),
            ),
          );
        },
      ),
    );

    items.add(
      _menuItem(
        icon: Icons.security_rounded,
        title: 'Privacy & Security',
        subtitle: 'Understand how your data is used',
        onTap: _showPrivacyDialog,
      ),
    );

    items.add(
      _menuItem(
        icon: Icons.help_outline_rounded,
        title: 'Help & Support',
        subtitle: 'Get help with MindfulAI',
        onTap: _showHelpDialog,
        last: true,
      ),
    );

    return _buildSection(
      title: 'Account',
      children: items,
    );
  }

  // ==========================================================
  // APP SECTION
  // ==========================================================

  Widget _buildAppSection() {
    return _buildSection(
      title: 'MindfulAI',
      children: [
        _menuItem(
          icon: Icons.bar_chart_rounded,
          title: 'Usage Access',
          subtitle: 'View your real device usage',
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) =>
                    const UsageAccessScreen(),
              ),
            );
          },
        ),
        _menuItem(
          icon: Icons.info_outline_rounded,
          title: 'About MindfulAI',
          subtitle: 'Learn more about the app',
          onTap: _showAboutDialog,
          last: true,
        ),
      ],
    );
  }

  // ==========================================================
  // SECTION
  // ==========================================================

  Widget _buildSection({
    required String title,
    required List<Widget> children,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(
            left: 3,
            bottom: 9,
          ),
          child: Text(
            title,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: Color(0xFF777286),
            ),
          ),
        ),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(23),
            border: Border.all(
              color: const Color(0xFFEAE6F7),
            ),
            boxShadow: [
              BoxShadow(
                color: const Color(0xFF7357D9)
                    .withValues(alpha: 0.035),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(children: children),
        ),
      ],
    );
  }

  // ==========================================================
  // MENU ITEM
  // ==========================================================

  Widget _menuItem({
    required IconData icon,
    required String title,
    required String subtitle,
    required VoidCallback onTap,
    bool last = false,
  }) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.vertical(
          top: const Radius.circular(23),
          bottom: Radius.circular(last ? 23 : 0),
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(
                horizontal: 15,
                vertical: 13,
              ),
              child: Row(
                children: [
                  Container(
                    width: 42,
                    height: 42,
                    decoration: BoxDecoration(
                      color: const Color(0xFFF0ECFF),
                      borderRadius:
                          BorderRadius.circular(13),
                    ),
                    child: Icon(
                      icon,
                      color: const Color(0xFF7357D9),
                      size: 21,
                    ),
                  ),
                  const SizedBox(width: 13),
                  Expanded(
                    child: Column(
                      crossAxisAlignment:
                          CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: const TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: Color(0xFF403B52),
                          ),
                        ),
                        const SizedBox(height: 3),
                        Text(
                          subtitle,
                          maxLines: 1,
                          overflow:
                              TextOverflow.ellipsis,
                          style: const TextStyle(
                            fontSize: 9.5,
                            color: Color(0xFF9791A3),
                          ),
                        ),
                      ],
                    ),
                  ),
                  const Icon(
                    Icons.chevron_right_rounded,
                    size: 23,
                    color: Color(0xFFA9A3B5),
                  ),
                ],
              ),
            ),
            if (!last)
              const Divider(
                height: 1,
                indent: 70,
                endIndent: 15,
                color: Color(0xFFF0EDF5),
              ),
          ],
        ),
      ),
    );
  }

  // ==========================================================
  // EDIT PROFILE
  // ==========================================================

  Future<void> _showEditProfileDialog() async {
    final controller = TextEditingController(
      text: _name == 'Mindful User' ? '' : _name,
    );

    bool saving = false;

    await showDialog<void>(
      context: context,
      barrierDismissible: !saving,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (
            dialogBuilderContext,
            setDialogState,
          ) {
            return AlertDialog(
              backgroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(24),
              ),
              title: const Text(
                'Edit Profile',
                style: TextStyle(
                  fontSize: 19,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF252238),
                ),
              ),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Full Name',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF5D576A),
                    ),
                  ),
                  const SizedBox(height: 7),
                  TextField(
                    controller: controller,
                    textCapitalization:
                        TextCapitalization.words,
                    decoration: InputDecoration(
                      hintText: 'Enter your name',
                      prefixIcon: const Icon(
                        Icons.person_outline_rounded,
                        color: Color(0xFF7357D9),
                      ),
                      filled: true,
                      fillColor: const Color(0xFFF7F5FF),
                      border: OutlineInputBorder(
                        borderRadius:
                            BorderRadius.circular(14),
                        borderSide: BorderSide.none,
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius:
                            BorderRadius.circular(14),
                        borderSide: const BorderSide(
                          color: Color(0xFF7357D9),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),
                  const Text(
                    'Email address cannot be changed here.',
                    style: TextStyle(
                      fontSize: 10,
                      color: Color(0xFF9993A5),
                    ),
                  ),
                ],
              ),
              actionsPadding:
                  const EdgeInsets.fromLTRB(
                18,
                0,
                18,
                16,
              ),
              actions: [
                TextButton(
                  onPressed: saving
                      ? null
                      : () {
                          Navigator.pop(dialogContext);
                        },
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: saving
                      ? null
                      : () async {
                          final newName =
                              controller.text.trim();

                          if (newName.isEmpty) {
                            _showMessage(
                              'Please enter your name.',
                            );
                            return;
                          }

                          if (newName.length < 2) {
                            _showMessage(
                              'Name must contain at least 2 characters.',
                            );
                            return;
                          }

                          setDialogState(() {
                            saving = true;
                          });

                          try {
                            final user =
                                _auth.currentUser;

                            if (user == null) {
                              throw FirebaseAuthException(
                                code: 'no-current-user',
                                message:
                                    'Please login again.',
                              );
                            }

                            await user.updateDisplayName(
                              newName,
                            );

                            await user.reload();

                            await _firebaseService
                                .saveUserProfile(
                              name: newName,
                              email:
                                  user.email ?? _email,
                            );

                            if (!mounted) {
                              return;
                            }

                            setState(() {
                              _name = newName;
                            });

                            if (!dialogContext.mounted) {
                              return;
                            }

                            Navigator.pop(
                              dialogContext,
                            );

                            _showMessage(
                              'Profile updated successfully.',
                            );
                          } on FirebaseAuthException catch (e) {
                            if (!dialogContext.mounted) {
                              return;
                            }

                            setDialogState(() {
                              saving = false;
                            });

                            _showMessage(
                              e.message ??
                                  'Unable to update profile.',
                            );
                          } catch (_) {
                            if (!dialogContext.mounted) {
                              return;
                            }

                            setDialogState(() {
                              saving = false;
                            });

                            _showMessage(
                              'Unable to update profile. Please try again.',
                            );
                          }
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        const Color(0xFF7357D9),
                    foregroundColor: Colors.white,
                    elevation: 0,
                    shape: RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.circular(12),
                    ),
                  ),
                  child: saving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child:
                              CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Text(
                          'Save',
                          style: TextStyle(
                            fontWeight: FontWeight.w800,
                          ),
                        ),
                ),
              ],
            );
          },
        );
      },
    );

    controller.dispose();
  }

  // ==========================================================
  // MY ACCOUNT
  // ==========================================================

  void _showAccountDialog() {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
        ),
        title: const Text(
          'My Account',
          style: TextStyle(
            fontWeight: FontWeight.w800,
          ),
        ),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment:
              CrossAxisAlignment.start,
          children: [
            _accountInfo('Name', _name),
            const SizedBox(height: 12),
            _accountInfo(
              'Email',
              _email.isEmpty
                  ? 'Not available'
                  : _email,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Widget _accountInfo(
    String title,
    String value,
  ) {
    return Column(
      crossAxisAlignment:
          CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 10,
            fontWeight: FontWeight.w700,
            color: Color(0xFF817B8D),
          ),
        ),
        const SizedBox(height: 3),
        Text(
          value,
          style: const TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w700,
            color: Color(0xFF302B42),
          ),
        ),
      ],
    );
  }

  // ==========================================================
  // SET PASSWORD
  // ==========================================================

  Future<void> _showSetPasswordDialog() async {
    final passwordController =
        TextEditingController();

    final confirmController =
        TextEditingController();

    bool obscurePassword = true;
    bool obscureConfirm = true;
    bool saving = false;

    await showDialog<void>(
      context: context,
      barrierDismissible: !saving,
      builder: (dialogContext) {
        return StatefulBuilder(
          builder: (
            dialogBuilderContext,
            setDialogState,
          ) {
            return AlertDialog(
              shape: RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(24),
              ),
              title: const Text(
                'Set Password',
                style: TextStyle(
                  fontWeight: FontWeight.w800,
                ),
              ),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: passwordController,
                      obscureText: obscurePassword,
                      decoration: InputDecoration(
                        labelText: 'Password',
                        prefixIcon: const Icon(
                          Icons.lock_outline_rounded,
                        ),
                        suffixIcon: IconButton(
                          onPressed: () {
                            setDialogState(() {
                              obscurePassword =
                                  !obscurePassword;
                            });
                          },
                          icon: Icon(
                            obscurePassword
                                ? Icons
                                    .visibility_off_outlined
                                : Icons
                                    .visibility_outlined,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: confirmController,
                      obscureText: obscureConfirm,
                      decoration: InputDecoration(
                        labelText: 'Confirm Password',
                        prefixIcon: const Icon(
                          Icons.lock_reset_rounded,
                        ),
                        suffixIcon: IconButton(
                          onPressed: () {
                            setDialogState(() {
                              obscureConfirm =
                                  !obscureConfirm;
                            });
                          },
                          icon: Icon(
                            obscureConfirm
                                ? Icons
                                    .visibility_off_outlined
                                : Icons
                                    .visibility_outlined,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: saving
                      ? null
                      : () {
                          Navigator.pop(dialogContext);
                        },
                  child: const Text('Cancel'),
                ),
                ElevatedButton(
                  onPressed: saving
                      ? null
                      : () async {
                          final password =
                              passwordController.text;

                          final confirm =
                              confirmController.text;

                          if (password.length < 6) {
                            _showMessage(
                              'Password must contain at least 6 characters.',
                            );
                            return;
                          }

                          if (password != confirm) {
                            _showMessage(
                              'Passwords do not match.',
                            );
                            return;
                          }

                          final user =
                              _auth.currentUser;

                          if (user == null) {
                            _showMessage(
                              'Please login again.',
                            );
                            return;
                          }

                          if (_email.isEmpty) {
                            _showMessage(
                              'Email address is not available.',
                            );
                            return;
                          }

                          setDialogState(() {
                            saving = true;
                          });

                          try {
                            await AuthService
                                .instance
                                .linkEmailPassword(
                              email: _email,
                              password: password,
                            );

                            if (!mounted) {
                              return;
                            }

                            setState(() {
                              _hasPasswordProvider = true;
                            });

                            if (!dialogContext.mounted) {
                              return;
                            }

                            Navigator.pop(
                              dialogContext,
                            );

                            _showMessage(
                              'Password added successfully.',
                            );
                          } on FirebaseAuthException catch (e) {
                            if (!dialogContext.mounted) {
                              return;
                            }

                            setDialogState(() {
                              saving = false;
                            });

                            _showMessage(
                              e.message ??
                                  'Unable to set password.',
                            );
                          } catch (_) {
                            if (!dialogContext.mounted) {
                              return;
                            }

                            setDialogState(() {
                              saving = false;
                            });

                            _showMessage(
                              'Unable to set password. Please try again.',
                            );
                          }
                        },
                  style: ElevatedButton.styleFrom(
                    backgroundColor:
                        const Color(0xFF7357D9),
                    foregroundColor: Colors.white,
                    elevation: 0,
                  ),
                  child: saving
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child:
                              CircularProgressIndicator(
                            strokeWidth: 2,
                            color: Colors.white,
                          ),
                        )
                      : const Text('Save Password'),
                ),
              ],
            );
          },
        );
      },
    );

    passwordController.dispose();
    confirmController.dispose();
  }

  // ==========================================================
  // PRIVACY
  // ==========================================================

  void _showPrivacyDialog() {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
        ),
        title: const Text(
          'Privacy & Security',
          style: TextStyle(
            fontWeight: FontWeight.w800,
          ),
        ),
        content: const Text(
          'MindfulAI uses your device usage information to calculate digital wellbeing insights. Your app usage is accessed only after you grant Android Usage Access permission.',
          style: TextStyle(
            fontSize: 13,
            height: 1.5,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // HELP
  // ==========================================================

  void _showHelpDialog() {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
        ),
        title: const Text(
          'Help & Support',
          style: TextStyle(
            fontWeight: FontWeight.w800,
          ),
        ),
        content: const Text(
          'If your usage information is not appearing, open Usage Access from your Profile and make sure MindfulAI has been enabled.',
          style: TextStyle(
            fontSize: 13,
            height: 1.5,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // ABOUT
  // ==========================================================

  void _showAboutDialog() {
    showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(22),
        ),
        title: const Text(
          'About MindfulAI',
          style: TextStyle(
            fontWeight: FontWeight.w800,
          ),
        ),
        content: const Text(
          'MindfulAI helps you understand your digital habits and build healthier screen-time routines.\n\nLess Screen. More Life.',
          style: TextStyle(
            fontSize: 13,
            height: 1.5,
          ),
        ),
        actions: [
          TextButton(
            onPressed: () =>
                Navigator.pop(context),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  // ==========================================================
  // LOGOUT BUTTON
  // ==========================================================

  Widget _buildLogoutButton() {
    return SizedBox(
      width: double.infinity,
      height: 53,
      child: ElevatedButton.icon(
        onPressed: _confirmLogout,
        icon: const Icon(
          Icons.logout_rounded,
          size: 19,
        ),
        label: const Text(
          'Logout',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.w800,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFFFFE8E6),
          foregroundColor: const Color(0xFFD95851),
          elevation: 0,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(17),
          ),
        ),
      ),
    );
  }

  // ==========================================================
  // CONFIRM LOGOUT
  // ==========================================================

  Future<void> _confirmLogout() async {
    final shouldLogout = await showDialog<bool>(
      context: context,
      builder: (dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(22),
          ),
          title: const Text(
            'Logout',
            style: TextStyle(
              fontWeight: FontWeight.w800,
            ),
          ),
          content: const Text(
            'Are you sure you want to logout?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  false,
                );
              },
              child: const Text('Cancel'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(
                  dialogContext,
                  true,
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor:
                    const Color(0xFF7357D9),
                foregroundColor: Colors.white,
                elevation: 0,
              ),
              child: const Text('Logout'),
            ),
          ],
        );
      },
    );

    if (shouldLogout != true) {
      return;
    }

    try {
      await AuthService.instance.logout();

      if (!mounted) {
        return;
      }

      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(
          builder: (_) => const LoginScreen(),
        ),
        (route) => false,
      );
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;

      _showMessage(
        e.message ??
            'Logout failed. Please try again.',
      );
    } catch (_) {
      if (!mounted) return;

      _showMessage(
        'Unable to logout. Please try again.',
      );
    }
  }

  // ==========================================================
  // MESSAGE
  // ==========================================================

  void _showMessage(String message) {
    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          content: Text(message),
          behavior: SnackBarBehavior.floating,
          margin: const EdgeInsets.all(16),
          backgroundColor: const Color(0xFF2D2942),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
        ),
      );
  }
}